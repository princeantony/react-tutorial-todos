/*eslint-disable import/default */
/* React libraries */
import "babel-polyfill";
import React from "react";
import {render} from "react-dom";
import {browserHistory} from "react-router";

/* LoanApp libraries */
import configureStore from "./store/configureStore";

/* Child components libraries */
import Root from "./containers/Root";

/* Constant components */
import {APP_CONSTANT} from "./constants/ApplicationConstants";

const store = configureStore();
let mountNode = document.getElementById(APP_CONSTANT.APP);

render(<Root history={browserHistory}  store={store} />, mountNode);