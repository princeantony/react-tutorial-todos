﻿var InitialData = React.createClass({   
    getInitialState: function () {
        return { InitialLoadData: this.props.LoadData };
    },
    render: function() {
        return (
          <div> </div>        
     );
    }
});



