import axios from 'axios'

let LoanAppApi = function()
{
    return {    
        getDataByUrl: function(url) 
        {
            var apiResult = null; 
            axios.get(url)
                    .then(function (response) {
                        apiResult = response.data;
                    })
                    .catch(function (error) {
                        apiResult = error;
                    });
            return  apiResult;
        }
    };
};


module.exports = LoanAppApi;
