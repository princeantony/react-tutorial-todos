﻿/*eslint-disable no-undef */
import React, {Component, PropTypes} from "react";
import {bindActionCreators} from "redux";
import {connect} from "react-redux";
import {GUARANTOR_CONSTANT, POSITION, VALIDATION_CONSTANT} from "../constants/ApplicationConstants";
import {SearchLegalEntities} from "../actions/searchAction";
import {APPLICATION_URL} from "../constants/ApplicationURL";
import SearchCriteriaPage from "./child-components/search/SearchCriteriaPage";
import {isSearchCriteriaValid} from "../utils/Validation";
import {showError} from "../utils/Functions";

class GuarantorSearchCriteriaPage extends Component {
    constructor(props, context) {
        super(props, context);
        this.state={
            searching: false
        };
    }

    redirect(){
        this.setState({searching: false});
        this.context.router.push(APPLICATION_URL.SEARCH+ this.props.params.id);
    }

    _redirectToSearchPage(){
        this.setState({searching: true});
        let _errors = isSearchCriteriaValid("TINSSN", "CUSTOMER_NAME");
        if (Object.keys(_errors).length == 0)
        {
            let tinNo= document.getElementById("TINSSN").value;
            let customerName= document.getElementById("CUSTOMER_NAME").value;
            this.props.actions.SearchLegalEntities(tinNo, customerName, borrowerID)
            .then(() => {this.redirect();})
            .catch(error => {
                this.setState({searching: false});
                console.log(error.response.data.ExceptionMessage);
            });
        }
        else if(_errors._ssnTinEin)
        {
            showError(VALIDATION_CONSTANT.SSN_TIN_EIN_ERROR);
            this.setState({searching: false});
         }
        else if(_errors.requiredOneField)
        {
            showError(VALIDATION_CONSTANT.GUARANTOR_SEARCH_ERROR);
            this.setState({searching: false});
         }
    }
    
    onKeyDown(e)
    {
        if(e.keyCode==13)
        {
            this._redirectToSearchPage();
        }
    }

    onFieldChange(e){
       
    }

    _resetSearchCriteria(){
        document.getElementById("TINSSN").value="";
        document.getElementById("CUSTOMER_NAME").value="";
    }

    _renderSearchCriteria(){
        let vertical=POSITION.VERTICAL;
        return(
            <div>
                <SearchCriteriaPage onFieldChange={this.onFieldChange.bind(this)} onKeyDown={this.onKeyDown.bind(this)} isDisabled={this.state.searching} onResetClick={this._resetSearchCriteria.bind(this)} onSearchClick={this._redirectToSearchPage.bind(this)} />
            </div>);
                }

    render() {
        return(<div>{this._renderSearchCriteria()}</div>);
    }
}

GuarantorSearchCriteriaPage.contextTypes = {
    router: PropTypes.object
};

let mapStateToProps = (state) => {
    return {
        searchResults:state.loanAppReducer.SearchResults,
        borrowerID: state.loanAppReducer.LoanApplication.Borrower.Id
    }
}

function mapDispatchToProps(dispatch) {
    return  {actions: bindActionCreators({SearchLegalEntities}, dispatch)};
}

export default connect(mapStateToProps,mapDispatchToProps)(GuarantorSearchCriteriaPage);


