﻿import React, { PropTypes, Component } from 'react';
import {BORROWER_CONSTANT, POSITION} from '../constants/ApplicationConstants';
import {renderHyperLink} from './form-components/Form';
import FormField from './form-components/FormField';

class NewAddress extends Component{
    constructor(props, context) {
        super(props, context);
        this.state = {
            isEditClicked: false
        }
    }

    onEditClick(e)
    {
        this.setState({isEditClicked:true});
    }
    render(){
        let vertical=POSITION.VERTICAL;
        let horizontal=POSITION.HORIZONTAL;
        let displayText = this.props.addressType;
        return(<div>
                <span className="fa-pull-right mar-r-50px mar-t-m-5px label-color cursor-pointer" onClick={this.onEditClick.bind(this)}>Edit</span>
                <div className="row">
                    {(this.state.isEditClicked)?(
                        <FormField columnSize="4" orientation={vertical}
                                   type="textarea" displayText={displayText} displayValue={''} />):('')}
                </div>
            </div>
        )
    }
}

export default NewAddress;
