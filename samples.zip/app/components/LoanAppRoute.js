﻿/* React libraries */
import React, {Component, PropTypes} from "react";

/* Constant components */
import {APPLICATION_URL} from "../constants/ApplicationURL";

/* LoanApp libraries */
import {renderSpinner} from "./form-components/Form";

class BlankComponent extends Component {

    /* component lifecycle methods start */
    componentWillMount()
    {
        let index=this.props.params.id;
        switch (this.props.params.case) {
            case "1": 
                this.context.router.push(APPLICATION_URL.BORROWER_URL + index); /// navigate to borrower page
                    break;
                    
            case "2":
                this.context.router.push(APPLICATION_URL.BORROWER_OWNER + index); /// navigate to borrower-owner page
                break;

            case "3":
                this.context.router.push(APPLICATION_URL.PRODUCT_REQUEST_URL + index); /// navigate to product request page
                break;

            case "4":
                this.context.router.push(APPLICATION_URL.BORROWER_OWNER_SEARCH_CRITERIA + index); /// navigate to owner search criteria page
                break;

            case "5" : this.context.router.push(APPLICATION_URL.GUARANTOR_SEARCH_CRITERIA_PAGE + index); /// navigate to guarantor search criteria page
                break;

            case "6" : this.context.router.push(APPLICATION_URL.GUARANTOR + index); /// navigate to guarantor page
                break;


            case "7" : this.context.router.push(APPLICATION_URL.GUARANTOR_OWNER_SEARCH_CRITERIA + this.props.params.parentId + '/' + index); /// navigate to guarantor owner search criteria page
                break;

            case "8" : this.context.router.push(APPLICATION_URL.GUARANTOR_OWNER + this.props.params.parentId + '/' + index); /// navigate to guarantor-owner page
                break;

            case "9" : this.context.router.push(APPLICATION_URL.COLLATERAL + index); /// navigate to collateral page
                break;

            case "10" : this.context.router.push(APPLICATION_URL.CARDHOLDER + index); /// navigate to cardholder page
                break;

            case "11":  this.context.router.push(APPLICATION_URL.ADDITIONAL_INFORMATION); /// navigate to cardholder page
                break;

        }
    }
    /* component lifecycle methods end */

    render(){
        return(renderSpinner());
    }
}

BlankComponent.contextTypes = {
    router: PropTypes.object
};


export default BlankComponent;
