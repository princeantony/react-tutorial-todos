/* React libraries */
import React, { PropTypes } from "react";

/* Child components libraries */
import FormField from "./form-components/FormField";
import {renderAppSection} from "./form-components/Form";

/* Constant components */
import {APPLICATIONSUMMARY_CONSTANT, POSITION} from "../constants/ApplicationConstants";

const ApplicationSummary =({applicationsummary, confirmationDetails})=>{
    let vertical=POSITION.VERTICAL;
    return(
        <div>
            {renderAppSection((APPLICATIONSUMMARY_CONSTANT.APPLICATION_SUMMARY),"panel","pnl-sub-header-green width-17-per pad-4px font-size-14px bold mar-l-5px","",
                ([<div>
                    <div className=" mar-t-m-5px">
                        <div className="col-lg-12 pad-0px mar-0px">
                            <div className="row mar-l-5px mar-r-5px pad-b-0px pad-t-0px pnl-brd-darkgray bg-clr-lightgray">
                                {(applicationsummary.LoggedInUserSecurityRole=="Retail Manager")?
                                    (
                                           <fieldset className="brd-radius-3px pad-b-0px pad-t-0px">
                                            <div className="col-lg-12  pad-0px">
                                                <div className="row pad-0px">
                                                    <FormField columnSize={2} orientation={vertical} cssLabelClass="bold" cssLabelValueClass="font-size-15px" type="label-group" displayText={APPLICATIONSUMMARY_CONSTANT.EMPLOYEE_NUMBER} displayValue={applicationsummary.EmployeeId} />
						    <FormField columnSize={3} orientation={vertical} cssLabelClass="bold" cssLabelValueClass="font-size-15px" type="label-group" displayText={APPLICATIONSUMMARY_CONSTANT.APPLICATION_ID} displayValue={(((confirmationDetails.BLCCreditRequestId==0)?(""):(confirmationDetails.BLCCreditRequestId + " (BLC)")) + ((confirmationDetails.BLCCreditRequestId!=0 && confirmationDetails.BCCCreditRequestId!=0)?(", "):("")) + ((confirmationDetails.BCCCreditRequestId==0)?(""):(confirmationDetails.BCCCreditRequestId + " (BCC)")))} />
					<FormField columnSize={3} orientation={vertical} cssLabelClass="bold" cssLabelValueClass="font-size-15px" type="label-group" displayText={APPLICATIONSUMMARY_CONSTANT.REFERRED_BY_EMPLOYEE_ID} displayValue={applicationsummary.ReferredByEmployeeId} />
						    <FormField columnSize={4} orientation={vertical} cssLabelClass="bold" cssLabelValueClass="font-size-15px" type="label-group" displayText={APPLICATIONSUMMARY_CONSTANT.FINANCIAL_CENTER_NAME_FC} displayValue={applicationsummary.BankCenterName + " (" + applicationsummary.BankCenterNumber + ")"} />
						    </div>
                                                </div>
                                                <div className="col-lg-12 pad-l-0px pad-r-0px">
                                                    <div className="row pad-0px">
						    <FormField columnSize={2} orientation={vertical} cssLabelClass="bold" cssLabelValueClass="font-size-15px" type="label-group" displayText={APPLICATIONSUMMARY_CONSTANT.EMPLOYEE_NAME} displayValue={applicationsummary.EmployeeName} />
						    	    <FormField columnSize={3} orientation={vertical} cssLabelClass="bold" cssLabelValueClass="font-size-15px" type="label-group" displayText={APPLICATIONSUMMARY_CONSTANT.REGION} displayValue={applicationsummary.AffiliateAcro} />
						    
 					            <FormField columnSize={3} orientation={vertical} cssLabelClass="bold" cssLabelValueClass="font-size-15px" type="label-group" displayText={APPLICATIONSUMMARY_CONSTANT.COST_CENTER_NUMBER} displayValue={applicationsummary.CostCenterNo} />
                                                    </div>

                                                </div>
                                            </fieldset>
                                        ):(
                                        <fieldset className="brd-radius-3px pad-b-0px pad-t-0px">
                                            <div className="col-lg-12 pad-0px">
                                                <div className="row pad-b-0px pad-t-0px">
                                                    <FormField columnSize={2} orientation={vertical} cssLabelClass="bold" cssLabelValueClass="font-size-15px" type="label-group" displayText={APPLICATIONSUMMARY_CONSTANT.EMPLOYEE_NAME} displayValue={applicationsummary.EmployeeName} />
                                                    <FormField columnSize={2} orientation={vertical} cssLabelClass="bold" cssLabelValueClass="font-size-15px" type="label-group" displayText={APPLICATIONSUMMARY_CONSTANT.EMPLOYEE_NUMBER} displayValue={applicationsummary.EmployeeId} />
                                                    <FormField columnSize={3} orientation={vertical} cssLabelClass="bold" cssLabelValueClass="font-size-15px" type="label-group" displayText={APPLICATIONSUMMARY_CONSTANT.REGION} displayValue={applicationsummary.AffiliateAcro} />
                                                    <FormField columnSize={4} orientation={vertical} cssLabelClass="bold" cssLabelValueClass="font-size-15px" type="label-group" displayText={APPLICATIONSUMMARY_CONSTANT.FINANCIAL_CENTER_NAME_BB_PB_OFFICER} displayValue={applicationsummary.BankCenterName + " (" + applicationsummary.OffcrNbr + ")"} />
                                                </div>
                                            </div>
                                            <div className="col-lg-12 pad-0px">
                                                <div className="row pad-b-0px pad-t-0px">
                                                    <FormField columnSize={4} orientation={vertical} cssLabelClass="bold" cssLabelValueClass="font-size-15px" type="label-group" displayText={APPLICATIONSUMMARY_CONSTANT.APPLICATION_ID} displayValue={(((confirmationDetails.BLCCreditRequestId==0)?(""):(confirmationDetails.BLCCreditRequestId + " (BLC)")) + ((confirmationDetails.BLCCreditRequestId!=0 && confirmationDetails.BCCCreditRequestId!=0)?(", "):("")) + ((confirmationDetails.BCCCreditRequestId==0)?(""):(confirmationDetails.BCCCreditRequestId + " (BCC)")))} />
                                                    <FormField columnSize={3} orientation={vertical} cssLabelClass="bold" cssLabelValueClass="font-size-15px" type="label-group" displayText={APPLICATIONSUMMARY_CONSTANT.REFERRED_BY_EMPLOYEE_ID} displayValue={applicationsummary.ReferredByEmployeeId} />
                                                </div>
                                            </div>
                                        </fieldset>
                                    )}
                                </div>
                            </div>
                        </div></div>]))}
            </div>
        );
}

ApplicationSummary.propTypes = {
    applicationsummary:PropTypes.object.isRequired
}

export default ApplicationSummary;
