/* React libraries */
import React, {Component} from "react";

/* Constant components */
import {HEADER_CONSTANT, POSITION, URL_CONSTANT} from "../constants/ApplicationConstants";

/* Child components libraries */
import {renderTooltip} from "./form-components/Tooltip";
import {renderHyperLink, renderIcon} from "./form-components/Form";

class Header extends Component {
    render() {
        const {employeeName}= this.props;
        return (
            <div className="row mar-l-0px mar-r-0px mar-t-0px">
                <div className="col-lg-12 pad-10px br-t-darkgray grad-blue">
                    <div className="col-lg-4 pad-l-0px wid-20-per-md wid-100-per-xs text-center-xs logo-sm headr-md headr-md wid-100-per-xs">
                        <div className="logo text-center-xs mar-l-36-per-xs mar-l-24-per-msm mar-l-20-per-sms" />
                    </div>
                    <div className="col-lg-5 wid-38-per wid-60-per-md wid-100-per-xs text-center-xs headr-md mar-t-20px-md wid-100-per-xs">
                        <h3 className="header_title txt-aln-c mar-t-10px-xs  mar-b-0px-sm mar-t-20px mar-t-5px-sm">
                            {HEADER_CONSTANT.HEADER_TEXT}
                        </h3>
                    </div>
                    <div className="col-lg-3 pad-r-0px mar-t-25px wid-10-per-md wid-100-per-xs text-center-xs pull-right txt-aln-r mar-t-0px-xs usr-sm mar-t-20px-md wid-100-per-xs">
                    <span className="header-links mar-t-0px-md text-cntr-ms">
                        <ul className="txt-aln-r links font-11px  pad-t-0px-ls">
                            <li>
                                {renderTooltip("userGuideTooltip",HEADER_CONSTANT.HELP_TEXT,POSITION.BOTTOM,(renderIcon("fa fa-lg fa-question-circle pad-r-5px cursor-help")))}
                                {renderHyperLink("lnkUserGuide", HEADER_CONSTANT.USER_GUIDE_TEXT, URL_CONSTANT.USERGUIDE_URL,"")}

                            </li>
                            <li className="clr-red bold">
                                {(IsTestMode?"Application is in Test Mode":"")}

                            </li>
                        </ul>
                    </span>

                    </div>

                </div>
                <div className="navbar navbar-inverse-blue nav-pos-fixed ht-25px pad-l-0px pad-r-0px  col-lg-12">
                    <p className="ht-16px txt-aln-center-mds text-right normal font-15px txt-clr-white mar-r-10px">
                        <span className="font-11px bold">Welcome {employeeName}</span>
                    </p>
                </div>
            </div>

        );
    }
}

export default Header;
