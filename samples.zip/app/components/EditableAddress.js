﻿import React, { PropTypes, Component } from 'react';
import {LEGALENITITY_COMMON_CONSTANT, POSITION, MESSAGE_CONSTANT} from '../constants/ApplicationConstants';
import FormField from './form-components/FormField';

let AddressType=[{"Key": false,"Value": "Domestic"},{"Key": false,"Value": "International"}];

class EditableAddress extends Component{
    constructor(props, context) {
        super(props, context);
        this.state = {
            isInternational: (props.addressInformation)?(props.addressInformation.IsInternational):false
            //addressInformationData:Object.assign({}, props.addressInformation)
        }
    }

    onFieldChange(e){
        this.props.onFieldChange(e); 
    }
    onCancelClick(e){
        this.props.onCancelClick(e);
    }
    onClearClick(e){
        this.props.onClearClick(e);
    }
    onUpdateClick(e){
        this.props.onUpdateClick(e);
    }
    onAddressTypeClick(e){
        this.setState({isInternational:!this.state.isInternational});
        this.props.onAddressTypeClick(!this.state.isInternational);
    }

    render(){
        const{ commonData, onFieldChange, name, disabled, addressType, type, addressInformation, isInternational, isCollateralAddress, onFieldBlur,isCardHolderAddress, isDomesticAddress, hasError, doValidate}=this.props;
        let vertical=POSITION.VERTICAL;
        let horizontal=POSITION.HORIZONTAL;       
        let required=false;
        if(!this.state.isInternational){ 
            AddressType[0].Key =false;
            AddressType[1].Key =true;
        }
        else{
            AddressType[0].Key =true;
            AddressType[1].Key =false; 
        }

        (addressType=="ReadOnlyAddressType")?(required=false):(required=true);

        return(<div className={disabled?"disabled":"" } name={name} id={type+"_Editable"}>
         
        {(isDomesticAddress)?(''):(
            <div className="row">
                <FormField columnSize={4} orientation={horizontal} id="rdoisEditableAddres" type="radio"
            width="500" name={type+"_"+addressType} displayText={LEGALENITITY_COMMON_CONSTANT.ADDRESS_TYPE}
            displayValue={AddressType} onFieldChange={this.onAddressTypeClick.bind(this)} />
        </div>
            )}
            <div className="row">
                <FormField columnSize={4} orientation={vertical}  name="Line1" type="text" id={type+"_line1"}
                displayText={LEGALENITITY_COMMON_CONSTANT.ADDRESS_Line1}  displayValue={addressType=="InputAddressType"?'':addressInformation.Line1} isRequired={required}  onFieldBlur={onFieldBlur}  hasError={hasError} doValidate={doValidate}/>
            <FormField columnSize={4} orientation={vertical}  name="Line2" type="text"
            displayText={LEGALENITITY_COMMON_CONSTANT.ADDRESS_Line2} displayValue={addressType=="InputAddressType"?'':addressInformation.Line2} />
            <FormField columnSize={4} orientation={vertical}  name="City" type="text" id={type+"_city"}
            displayText={LEGALENITITY_COMMON_CONSTANT.CITY}
            displayValue={addressType=="InputAddressType"?'':addressInformation.City} isRequired={required}  hasError={hasError} doValidate={doValidate}/>
</div>
<div className="row">
            {this.state.isInternational?(
    <div>
        <FormField columnSize={4} orientation={vertical} id={addressType=="InputAddressType"?'':addressInformation.CountryId}
        type="select-single" displayText={LEGALENITITY_COMMON_CONSTANT.COUNTRY} displayValue={commonData.Countries}
            name="CountryId" isRequired={required} dataValueField="Id" id={type+"_country"}
            dataTextField="Name" defaultSelectValue={addressType=="InputAddressType"?'':addressInformation.CountryId} hasError={hasError} doValidate={doValidate}/>
            <FormField columnSize={4} orientation={vertical} name="Province" type="text"
            displayText={LEGALENITITY_COMMON_CONSTANT.REGION_PROVINCE} displayValue={addressType=="InputAddressType"?'':addressInformation.Province}/>
        </div>
             ):(
                <div>
                {(isCardHolderAddress)?(''):(
                    <FormField columnSize={4} orientation={vertical}  name="County" type="text" id={type+"_county"}
                    displayText={LEGALENITITY_COMMON_CONSTANT.COUNTY} displayValue={addressType=="InputAddressType"?'':addressInformation.County} isRequired={isCollateralAddress?false:required} hasError={hasError} doValidate={doValidate}/>
                    )}
                    <FormField columnSize={4} orientation={vertical} name="State" id={type+"_state"}
                        type="select-single"
                        dataValueField="StateAbbrevation" dataTextField="StateName"
                        defaultSelectValue={addressType=="InputAddressType"?'':addressInformation.State}
                        displayText={LEGALENITITY_COMMON_CONSTANT.STATE} displayValue={commonData.States} isRequired={required} hasError={hasError} doValidate={doValidate}/>
                    </div>
             )}
             <FormField columnSize={4} orientation={vertical}  name="ZipCode" type="text" maxLength={5} id={type+"_zipcode"}
             displayText={LEGALENITITY_COMMON_CONSTANT.ZIP_POSTAL_CODE} displayValue={addressType=="InputAddressType"?'':addressInformation.ZipCode} isRequired={(this.state.isInternational)?false:true} isNumberFormat={true} digitLength={5} hasError={hasError} doValidate={doValidate}/>

             {(addressType=="EditableAddressType" && !isDomesticAddress)?(
        <div className="pull-right mar-r-43px mar-t-15px">
            <input type="button" id="btnUpdate"  name={type+"_Update"} className="btn btn-primary" onClick={this.onUpdateClick.bind(this)}  value="Update" />
            <input type="button" id="btnClear"  name={type +"_Clear"} className="btn btn-primary mar-l-15px"  value="Clear" onClick={this.onClearClick.bind(this)}/>
                <input type="button" id="btnCancel" name={type+"_Cancel"} onClick={this.onCancelClick.bind(this)} className="btn btn-primary mar-l-15px"  value="Cancel" />
        </div>
                ):''}
            </div>
        </div>)
            }
}
EditableAddress.propTypes = {
    addressInformation:PropTypes.object.isRequired,
    commonData:PropTypes.object.isRequired,
    onFieldChange:PropTypes.func,
}
export default EditableAddress;
