import React, {PropTypes, Component} from 'react';
import {LEGALENITITY_COMMON_CONSTANT, POSITION, VALIDATION_CONSTANT} from '../constants/ApplicationConstants';
import FormField from './form-components/FormField';
import _ from "lodash";

let e ={};
class MultipleAddress extends Component {
    constructor(props, context) {
        super(props, context);
        this.state = {
            error:{},
        };
    }

    onMismatchClick(e) {
        this.setState({error: {} });
        this.props.onMismatchClick(e.target.name, e.target.value);
    }

    getFormattedAddress(address, line) {
        return (line == '1') ? [address.Line1, address.Line2, address.Province].filter(val => val).join(', ')
            : [address.City, address.County, address.State, address.Country, address.ZipCode].filter(val => val).join(', ')
    }

    render() {
        const {existingAddress, newAddress, onMismatchClick, name, addressCount, defaultOption, isCollateralAddress, doValidate, hasError}=this.props;        
        let vertical = POSITION.VERTICAL;
        let horizontal = POSITION.HORIZONTAL;
        if(doValidate && defaultOption == 0 && addressCount > 1)
        {
            this.state.error[name] = VALIDATION_CONSTANT.ADRESS_FIELD_ERROR;
            e.name=name;
            if(this.props.hasError)
                this.props.hasError(this.state.error, e);
        }
        else{
            this.state.error={};
        }
        return (
            <div className="row pad-5px">
                {(addressCount > 1 && !isCollateralAddress) ? (<div
                    className="pad-l-15px italic">{LEGALENITITY_COMMON_CONSTANT.ADDRESS_MISMATCH_MESSAGE}</div>) : ("")}
                {(existingAddress != null) ?
                    (<div className="row col-sm-6">
                        {(addressCount > 1) ?
                            (<FormField columnSize={12} orientation={horizontal} name={name} className={_.size(this.state.error)>0?"radio-error":""}
                                        type="radio" onFieldChange={this.onMismatchClick.bind(this)}
                                        displayValue={[{"Key": 1, "Value": "Use this address"}]}
                                        defaultOption={defaultOption}/>) : ("")}
                        <div className="row border-div pad-l-15px col-sm-12 font-size-15px">
                            <div className="mar-t-5px">{this.getFormattedAddress(existingAddress, '1')}</div>
                            <div>{this.getFormattedAddress(existingAddress, '2')}</div>
                        </div>
                    </div>) : ""}
                {(newAddress != null) ?
                    (<div className="row col-sm-6">
                        {(addressCount > 1) ?
                            (<FormField columnSize={12} orientation={horizontal} name={name} className={_.size(this.state.error)>0?"radio-error":""}
                                        type="radio" onFieldChange={this.onMismatchClick.bind(this)}
                                        displayValue={[{"Key": 2, "Value": "Use this address"}]}
                                        defaultOption={defaultOption}/>) : ("")}
                        <div className="row border-div pad-l-15px col-sm-12 font-size-15px">
                            <div className="mar-t-5px">{this.getFormattedAddress(newAddress, '1')}</div>
                            <div>{this.getFormattedAddress(newAddress, '2')}</div>
                        </div>
                    </div>) : ""}

            </div>)
    }
}
MultipleAddress.propTypes = {
    existingAddress: PropTypes.object.isRequired,
    newAddress: PropTypes.object.isRequired,
}
export default MultipleAddress;
