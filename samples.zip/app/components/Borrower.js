/* React libraries */
import React, {Component, PropTypes} from "react";

/* LoanApp libraries */
import {renderAccordion, renderSection, renderSpinner} from "./form-components/Form";
import FormField from "./form-components/FormField";

/* Child components libraries */
import BusinessInformation from "./child-components/BusinessInformation";
import PhoneNumbers from "./child-components/PhoneNumbers";
import OtherInformation from "./child-components/OtherInformation";

/* Address components */
import Facilities from "./FacilityInformation";
import MultipleAddress from "./MultipleAddress";

/* Constant components */
import {LEGALENITITY_COMMON_CONSTANT,BORROWER_CONSTANT, POSITION, LEGEND_CONSTANT} from "../constants/ApplicationConstants";


class Borrower extends Component {
    onDoneClick(){
        if(this.props.onNextButtonClick)
            this.props.onNextButtonClick(this);
    }
    
    render() {
        const {onFieldChange, data, doValidate, commonData, isNextButtonDisable, hasError, onEntityChange, onMismatchClick, isEntityStructureDisable, bfnaData, initialData, affiliateCode, isIndividual, entityStructureLLCs, borrowerAction, businessAddressIndex, homeAddressIndex} = this.props;
        return (
            <div>
                {renderSection((BORROWER_CONSTANT.BORROWER_BUSINESS_INFORMATION), "panel", "pnl-sub-header-green width-40-per pad-4px font-size-14px bold mar-l-5px", "",
                    ([<div>
                        <form method="post" action="" key="borrowerForm" name="borrowerForm" id="borrowerForm" ref="borrowerForm">
                              
                              {(isNextButtonDisable?renderSpinner():"")} 

                            <fieldset className="brd-radius-3px mar-t-m-5px">
                                <div className="col-lg-12 pad-0px mar-0px">
                                    <div className="mar-l-5px mar-r-5px pnl-brd-darkgray brd-radius-10px pad-b-0px pad-t-0px">
                                        <div className="pad-b-0px pad-t-0px"><FormField type="legend"
                                                                        displayText={LEGEND_CONSTANT.REQUIRED_FIELD}/>
                                        </div>
                                        
                                        {!isIndividual && <div><FormField type="legend"
                                                                        cssClass="clr-lbl font-size-11px italic"
                                                                        displayText={LEGEND_CONSTANT.NON_INDIVIDUAL_MESSAGE}/>
                                        </div>}
                                        <div className="pad-b-5px pad-l-5px pad-r-5px font-size-11px">
                                            {/* Basic business information section */}
                                            <BusinessInformation entityStructure={entityStructureLLCs} customerLabel="Borrower"
                                                                 isEntityStructureDisable={isEntityStructureDisable}
                                                                 onEntityChange={onEntityChange}
                                                                 isIndividual={isIndividual} isBorrower={true}
                                                                 initialData={initialData}
                                                                 data={data}
                                                                 onFieldChange={onFieldChange}
                                                                 hasError={hasError} doValidate={doValidate}/>
                                            {/* Borrower Address part start here*/}
                                            {(isIndividual && data.HomeAddressCount > 0) ?
                                                (renderAccordion('fa fa-address-card', (LEGALENITITY_COMMON_CONSTANT.HOME_ADDRESS), "panel accordion-brd-color font-size-12px", "accordion-panel pad-4px bold", "", "",
                                                    <div>
                                                        <MultipleAddress
                                                            onMismatchClick={onMismatchClick}
                                                            name={"HomeIndividual_" + isIndividual}
                                                            existingAddress={_.find(data.Addresses, {'AddressTypeId': 'E'})}
                                                            newAddress={(borrowerAction == "add" || data.SecondaryAddress) ? _.find(bfnaData.Addresses, {'Type': 'Home'}) : null}
                                                            addressCount={data.HomeAddressCount}
                                                            defaultOption={homeAddressIndex} hasError={hasError} doValidate={doValidate} />
                                                        <div><Facilities facilityInformation={data.FacilityInformation[0]} type= "Home" facilities={commonData.Facilities} paramId={borrowerAction} hasError={hasError} doValidate={doValidate}/></div>
                                                    </div>
                                                )) : ("")}
                                            {(data.BusinessAddressCount > 0) ?
                                                (renderAccordion('fa fa-address-card', (LEGALENITITY_COMMON_CONSTANT.BUSINESS_ADDRESS), "panel accordion-brd-color font-size-12px", "accordion-panel pad-4px bold", "", "",
                                                    <div>
                                                        <MultipleAddress
                                                            onMismatchClick={onMismatchClick}
                                                            name={"BusinessIndividual_" + isIndividual}                                                           
                                                            existingAddress={_.find(data.Addresses, {'AddressTypeId': (isIndividual ? 'B':'E')})}
                                                            newAddress={(borrowerAction == "add" || data.PrimaryAddress) ? _.find(bfnaData.Addresses, {'Type': 'Business'}) : null}
                                                            addressCount={data.BusinessAddressCount}
                                                            defaultOption={businessAddressIndex} hasError={hasError} doValidate={doValidate} />
                                                        <div>
                                                            <Facilities facilityInformation={data.FacilityInformation[1]} type = "Business" paramId={borrowerAction}
                                                            facilities={commonData.Facilities} hasError={hasError} doValidate={doValidate}/>
                                                    </div>
                                                </div>
                                                )) : ("")}
    {/* Borrower Address part ends here*/}
    {/* Phone number section */}
    <PhoneNumbers data={data} initialData={initialData} hasError={hasError} doValidate={doValidate}/>
    {/* Other details section */}
    <OtherInformation isIndividual={isIndividual} isBorrower={true}  paramId={borrowerAction}
        initialData={initialData} data={data} customerLabel="Borrower"
        onFieldChange={onFieldChange} statesList={commonData.States}
        affiliate = {commonData.Affilliates}
        affiliateDefault = {(borrowerAction == "add"? affiliateCode:data.Affiliate.Code)}
        hasError={hasError} doValidate={doValidate}/>
    </div>
         <div className={(isNextButtonDisable?"pull-right pad-r-5px mar-r-5px btn-primary bg-btn-clr-navy text-center-xs pull-left-xs disabled":"pull-right pad-r-5px mar-r-5px btn-primary bg-btn-clr-navy text-center-xs pull-left-xs")}>
                           		             <span className=" fa fa-lg fa-floppy-o" aria-hidden="true"></span>
						                    <input type="button" className="bg-clr-transparent br-none wid-55px pad-l-7px"  value="Save" onClick={this.onDoneClick.bind(this)} disabled={isNextButtonDisable} />
                                        </div>
                                    </div>
                                </div>
                            </fieldset>
                            <div className={(isNextButtonDisable?"overlay-div":"")}> &nbsp; </div>
                        </form>
                    </div>]))}
            </div>);
    }
}
export default Borrower;
