﻿/* React libraries */
import React, { PropTypes, Component } from "react";

/* Constant components */
import {CARDHOLDER_CONSTANT, POSITION, VALIDATION_CONSTANT, LEGEND_CONSTANT, FORMAT_CONSTANT} from "../constants/ApplicationConstants";

/* Child components libraries */
import {renderAccordion, renderSection} from "./form-components/Form";
import FormField from "./form-components/FormField";
import EditableAddress from "./EditableAddress";


/* variable declaration start */
let vertical=POSITION.VERTICAL;
let horizontal=POSITION.HORIZONTAL;
/* variable declaration end */

class Cardholder extends Component
{
    constructor(props,context){
        super(props,context);
    }

    onDoneClick(){
        if(this.props.onNextButtonClick)
        {
            this.props.onNextButtonClick(this);
        }
    }
    
    render(){
        
        const {onFieldChange, index, data, commonData, isNextButtonDisable, onNextButtonClick, doValidate, hasError, onFieldBlur, displayName}= this.props;
        return(<div>
                    {renderSection(("Cardholder "+ (parseInt(displayName)) + " Information"),'panel','pnl-sub-header-green width-30-per pad-4px font-size-14px bold mar-l-5px','',
                    ([<div>
                        <form method="post" action="" key="cardholderForm" name="cardholderForm" id="cardholderForm" ref="cardholderForm" >
                            <fieldset className="brd-radius-3px mar-t-m-5px">
                                <div className="col-lg-12 pad-0px mar-0px">
                                    <div className="mar-l-5px mar-r-5px pnl-brd-darkgray brd-radius-10px pad-14px pad-t-0px pad-b-0px">
                                         <FormField type="legend" displayText={LEGEND_CONSTANT.REQUIRED_FIELD} />
                                         <FormField type="legend" cssClass="clr-lbl font-size-11px italic" displayText={CARDHOLDER_CONSTANT.RENDER_TOOLTIP_MESSAGE} />
                                         <div className="pad-b-5px pad-l-5px pad-r-5px font-size-11px">
                                            <div id="legalEntityDetails">
                                            {renderAccordion('fa fa-user-circle', (CARDHOLDER_CONSTANT.BASIC_BUSINESS_INFORMATION), 'panel accordion-brd-color font-size-12px', 'accordion-panel pad-4px bold', '', '',
                                                (
                                                 <div>
                                                 <div className="row ">
                                                    <FormField columnSize={4} orientation={vertical} key="LegalName" name="LegalName" type="text"  displayText={CARDHOLDER_CONSTANT.LEGAL_NAME} displayValue={data.LegalName} maxLength="26" onFieldBlur={onFieldBlur} />
                                                    <FormField columnSize={4} orientation={vertical} key="FirstName"  name="FirstName" type="text" displayText={CARDHOLDER_CONSTANT.FIRST_NAME} displayValue={data.FirstName} isRequired={true} hasError={hasError} doValidate={doValidate} onFieldBlur={onFieldBlur} />
                                                    <FormField columnSize={4} orientation={vertical} key="MiddleName"  name="MiddleName" type="text" displayText={CARDHOLDER_CONSTANT.MIDDLE_NAME} displayValue={data.MiddleName} onFieldBlur={onFieldBlur}  />
                                                </div>
                                                    <div className="row">
                                                        <FormField columnSize={4} orientation={vertical} key="LastName"  name="LastName" type="text"  displayText={CARDHOLDER_CONSTANT.LAST_NAME}  displayValue={data.LastName} isRequired={true} hasError={hasError} doValidate={doValidate} onFieldBlur={onFieldBlur}  />
                                                        <FormField columnSize={4} orientation={vertical} key="NameSuffix"  name="NameSuffix"  type="text" displayText={CARDHOLDER_CONSTANT.NAMESUFFIX}  displayValue={data.NameSuffix} onFieldBlur={onFieldBlur}  />
                                                        <FormField columnSize={4} orientation={vertical} key="SocialSecurityNumber"  name="SocialSecurityNumber"  type="text" displayText={CARDHOLDER_CONSTANT.SSN_TIN_EIN}  displayValue={data.SocialSecurityNumber} isRequired={true}  isNumberFormat={true} digitLength={9} errorMessage ={VALIDATION_CONSTANT.SSN_TIN_EIN_ERROR} hasError={hasError} doValidate={doValidate}  maxLength={9} onFieldBlur={onFieldBlur} />
                                                    </div>
                                                    <div className="row">
                                                        <FormField columnSize={4} orientation={vertical} key="DateOfBirth"  name="DateOfBirth" type="date" displayText={CARDHOLDER_CONSTANT.DOB}  displayValue={((data.DateOfBirth)?(new Date(data.DateOfBirth)):(''))} onFieldChange={onFieldChange} isRequired={true} minDate={new Date('01/01/1900').toISOString()} hasError={hasError} doValidate={doValidate}/>
                                                    </div>
                                                    </div>)
                                            )}
                                            </div>
                                                        <div id="addressDetails">
                                                        {renderAccordion('fa fa-address-card', 'Address Information', 'panel accordion-brd-color font-size-12px', 'accordion-panel pad-4px bold', '', '',
                                                            <EditableAddress addressType={(data.Addresses!=undefined && data.Addresses.length>0)?"EditableAddressType":"InputAddressType"} 
                                                            disabled={false}  name={"InputAddress"} type={"Home"} 
                                                            addressInformation={(data.Addresses!=undefined)?(data.Addresses[0]):({})}
                                                            commonData={commonData} isCardHolderAddress={true} isInternational={false} isDomesticAddress={true}
                                                            onFieldBlur={this.props.onFieldBlur.bind(this)} 
                                                            hasError={hasError} doValidate={doValidate} onFieldChange={onFieldChange} />
                                                        )}
                                                        </div>

                                                            </div>
                                                                <div className="pull-right pad-r-5px mar-r-5px btn-primary bg-btn-clr-navy">
                           		                                 <span className=" fa fa-lg fa-floppy-o" aria-hidden="true"></span>
						                                            <input type="button" className="bg-clr-transparent br-none wid-55px pad-l-7px"  value="Save" onClick={this.onDoneClick.bind(this)} disabled={isNextButtonDisable} />
                                                            </div>
                                                        </div>
                                                    </div>
                                                </fieldset>
                                            </form>
                                        </div>]))}
               </div>);
            }
}


export default Cardholder;