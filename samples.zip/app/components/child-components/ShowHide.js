﻿/*eslint-disable import/default */
import React, { PropTypes, Component } from 'react';
import {renderSpan} from '../form-components/Form';
import _ from "lodash";
import { Link } from 'react-router';

let indexes=0;let pathNameIndex="";
class ShowHide extends Component {
    removeList(e)
    {
        this.props.removeList(e);
    }
    getCurrentItems()
    {  
        return(  <div> 
            {               
                this.props.displayValue.map((item, index) => {
                    indexes=index+1;
                    pathNameIndex=this.props.pathName+indexes;
                    return <div id={'container'+indexes} className={ (location.pathname === pathNameIndex)? "pad-t-10px mar-t-5px pad-b-10px bg-clr-green":"pad-t-10px mar-t-5px pad-b-10px"}><div className="text-dec"><Link className='pad-t-5px white' to={pathNameIndex}>{ renderSpan((location.pathname === pathNameIndex)?'pad-t-5px white':'pad-t-5px black','',''+this.props.displayText+' '+indexes+'')}</Link></div>{(index>0)?(<span id={'span'+index} onClick={this.removeList.bind(this)} className="fa icon-remove-sign fa-lg clr-black pull-right mar-r-5px mar-t-m-5px cursor-pointer" aria-hidden="true"></span>):(<span></span>)}</div>
                })
            }
            </div>
        );
    }
    render() {
        const{ displayValue, pathName, displayText }=this.props;
        return (<div>{this.getCurrentItems()}</div>);
    }
}
ShowHide.propTypes = {
    displayValue:PropTypes.object.isRequired

}
export default ShowHide;
