﻿/* React libraries */
import React, { PropTypes, Component } from "react";

/* plugin libraries */
import _ from "lodash";

/* Constant components */
import {LEGALENITITY_COMMON_CONSTANT, FORMAT_CONSTANT, POSITION} from "../../constants/ApplicationConstants";

/* Child components libraries */
import {renderAccordion} from "../form-components/Form";
import FormField from "../form-components/FormField";


class PhoneNumbers extends Component{

    render(){
        let vertical=POSITION.VERTICAL;
        const {data, initialData, doValidate, hasError}=this.props;
    return(
        <div>
            {renderAccordion('fa fa-phone', (LEGALENITITY_COMMON_CONSTANT.PHONE_NUMBERS), "panel accordion-brd-color font-size-12px","accordion-panel pad-4px bold","","",
               ([<div>
                       <div className="row">
                            <FormField columnSize={4} orientation={vertical} key="HomePhone" name="HomePhone" dataMask={FORMAT_CONSTANT.US_PHONE_NUMBER_MASK} faClass="fa-phone label-color" type="phone"  displayText={LEGALENITITY_COMMON_CONSTANT.BUSINESS} displayValue={data.HomePhone} isDisabled={((_.trim(initialData.HomePhone) && _.trim(initialData.HomePhone).length==10)?(true):(false))} isRequired={((initialData.HomePhone)?(false):(true))} isPhoneNumber={true} hasError={hasError} doValidate={doValidate}/>
                            <FormField columnSize={4} orientation={vertical} key="MobilePhone" name="MobilePhone" dataMask={FORMAT_CONSTANT.US_PHONE_NUMBER_MASK} faClass="fa-mobile label-color font-size-14px bold" type="phone" displayText={LEGALENITITY_COMMON_CONSTANT.HOME} displayValue={data.MobilePhone} isDisabled={((_.trim(initialData.MobilePhone) && _.trim(initialData.MobilePhone).length==10)?(true):(false))} isPhoneNumber={true} hasError={hasError} doValidate={doValidate}/>
                            <FormField columnSize={4} orientation={vertical} key="OtherPhone" name="OtherPhone" dataMask={FORMAT_CONSTANT.US_PHONE_NUMBER_MASK} faClass="fa-phone label-color" type="phone" displayText={LEGALENITITY_COMMON_CONSTANT.OTHER}  displayValue={data.OtherPhone} isDisabled={((_.trim(initialData.OtherPhone) && _.trim(initialData.OtherPhone).length==10)?(true):(false))} isPhoneNumber={true} hasError={hasError} doValidate={doValidate}/>
                       </div>
              </div>]))}
            </div>
        );
                       }
}
export default PhoneNumbers;
