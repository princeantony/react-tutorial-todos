/* React libraries */
import React, {Component, PropTypes} from "react";

/* Constant components */
import {APPLICATION_URL} from "../../constants/ApplicationURL";

class  LeftNavItems extends Component {
    onRemoveClick(index,_from)
    {
        if(this.props.onRemoveClick)
            this.props.onRemoveClick(index,_from,"");
    }

    onGuarantorOwnerRemove(index, ownerIndex)
    {
        if(this.props.onOwnerRemoveClick)
            this.props.onRemoveClick(index, "Guarantor",ownerIndex);
    }

    onGuarantorOwnerClick(Id, index)
    {
        if(this.props.onGuarantorOwnerClick)
            this.props.onGuarantorOwnerClick(Id, index);
    }

    onLeftMenuItemClick(linkUrl, pindex, parentIndex, displayText)
    {
        if(this.props.onLeftMenuClick){
            this.props.onLeftMenuClick(linkUrl, pindex, parentIndex, displayText);
        }
    }
    onFieldClick(displayText)
    {
        if(this.props.onFieldClick)
            this.props.onFieldClick(displayText);
    }
    render(){
        const {id,
               disabled,
               collapsed,
               displayValue,
               displayText,
               url,
               onFieldClick,
               groupLabelText,
               addNewUrl,
               addNewUrlParam,
               onRemoveClick,
               showControls,
               addNewLinkText,
               onGuarantorOwnerClick,
               isOwner,
               onOwnerRemoveClick,
               showOwnerControls,
               isRemove,
               onLeftMenuClick,
               saveStatus,
               ownerStatus,
               activeTab, 
               imgClassName,
               parentImgClassName}=this.props;


        return(
            <div>
                <div className={(disabled)?"disabled pad-t-0px br-b-gray mar-b-m-8px pad-b-0px":"pad-t-0px br-b-gray mar-b-m-8px pad-b-0px"} id={id}>
                  <div className={"left-submenu  pad-t-5px mar-t-3px pad-b-6px mar-b-m-6px "+(activeTab == displayText?"left-nav-header":"" )}  onClick={this.onFieldClick.bind(this,displayText)}> <span className={collapsed? 'fa fa-caret-right pad-l-5px pad-r-8px float-l cursor-pointer font-18px':'fa fa-caret-down font-18px float-l pad-l-5px pad-r-8px cursor-pointer'}></span>
                   <span className="pad-l-5px bold cursor-pointer"> <span className={"fa "+parentImgClassName+" pull-left pad-l-10px pad-t-2px"} aria-hidden="true"></span><span>{groupLabelText}</span></span>
                   <span className={(saveStatus ? "fa fa-check clr-green cursor-pointer mar-r-5px pull-right " : "fa fa-exclamation-triangle fa-lg clr-orange mar-r-5px pull-right cursor-pointer")} aria-hidden="true"></span>
                   </div>

                   {((!collapsed)?
                       (<div>
                           {displayValue && displayValue.map((data, index) => {
                               return (<div className="pad-t-0px pad-b-1px mar-b-m-10px mar-t-0px  br-t-gray">
                                           <div className={"left-submenu pad-t-6px pad-b-6px "+ (activeTab == (displayText + (index+1)) ?"left-nav-header":"" )}>
                                               <span className={"fa "+imgClassName+" mar-r-8px pad-l-36px pad-t-2px "+(displayText=="Owner"?" mar-l-45px":" mar-l-30px")} aria-hidden="true"></span>
                                               <span>
                                                   <span onClick={this.onLeftMenuItemClick.bind(this, url, index, 0,displayText + (index+1))} className="pad-t-5px ">
                                                       <span>
                                                           <span>{displayText}</span>&nbsp;
                                                           <span>{index+1}</span>
                                                       </span>
                                                   </span>
                                               </span>
                               {((showControls && ((isRemove)?(isRemove):(displayValue.length>1)))?(<span className="fa fa-times fa-lg  pull-right mar-r-5px cursor-pointer clr-red" aria-hidden="true" onClick={this.onRemoveClick.bind(this, index,groupLabelText)}></span>):(<span></span>))}
                               </div>

                            {/*Owner Section*/}
                            {((isOwner && data.RelatedEntity.Id!=0 && data.RelatedEntity.EntityStructure!=undefined && data.RelatedEntity.EntityStructure.StructureCode!=="" && data.RelatedEntity.EntityStructure.StructureCode!=="I")?(
                                 <div><div className={(data.RelatedEntity.Id!=0 && data.RelatedEntity.IsNew==false)?"left-submenu pad-t-6px pad-b-6px mar-b-m-8px br-t-gray mar-l-0px ":"disabled left-submenu pad-t-6px br-t-gray mar-l-0px"} id={id}>{data.isCollapsed}
                                    <span className={(data.isCollapsed!=undefined && !data.isCollapsed)?"fa fa-caret-down pad-l-35px pad-r-8px cursor-pointer font-18px":"fa fa-caret-right font-18px pad-l-35px pad-r-8px float-l cursor-pointer"} onClick={this.onGuarantorOwnerClick.bind(this, data.RelatedEntity.Id, index)}></span>
                                    <span className="pad-l-5px bold cursor-pointer" onClick={this.onGuarantorOwnerClick.bind(this, data.RelatedEntity.Id, index)}><span className={"fa fa-users mar-r-8px pad-l-10px pad-t-2px"} aria-hidden="true"></span><span>Guarantor Owner(s)</span></span>
                                    <span className={(ownerStatus ? "fa fa-check clr-green cursor-pointer mar-r-5px pull-right" : "fa fa-exclamation-triangle fa-lg clr-orange mar-r-5px pull-right cursor-pointer")} aria-hidden="true"></span>
                                 </div><div>  {(!data.isCollapsed)?(<div className="mar-l-0px">
                            {data.RelatedEntity.OwnershipTies && data.RelatedEntity.OwnershipTies.map((ownerData, ownerIndex) => {
                                return (<div className={"left-submenu br-t-gray pad-t-10px pad-b-10px mar-l-0px mar-b-m-8px "+ (activeTab == (displayText + index+1) ?"left-nav-header":"" )}>
                                            <span><span onClick={this.onLeftMenuItemClick.bind(this, APPLICATION_URL.GUARANTOR_OWNER, ownerIndex, index)} ><span className="pad-t-10px pad-b-10px "><span className="pad-l-90px"> <span className="fa fa-user pad-r-5px" aria-hidden="true"></span>Owner</span>&nbsp;<span>{ownerIndex+1}</span></span></span></span>
                                            {((data.isShowControls)?(<span className="fa fa-times fa-lg pull-right mar-r-5px cursor-pointer clr-red" aria-hidden="true"  onClick={this.onGuarantorOwnerRemove.bind(this, index, ownerIndex)}></span>):(<span></span>))}
                            </div>);
                        })}

                                            </div>):(<div></div>)}
                </div>{((!data.isShowControls)?(""):((!data.isCollapsed)?(<div className="left-submenu br-t-gray pad-t-6px pad-b-6px mar-t-0px "><span onClick={this.onLeftMenuItemClick.bind(this, APPLICATION_URL.GUARANTOR_OWNER_SEARCH_CRITERIA, "GO", index)}><span><span className="mar-l-35px"><i className="fa fa-plus-circle mar-r-5px" aria-hidden="true"></i></span><span >Add New Owner</span></span></span></div>):""))}</div>
                ):(<div></div>))}
    {/*End Owner Section*/}
</div>);
    })}
    {((showControls)?(<div className={"left-submenu br-t-gray pad-t-6px pad-b-6px mar-t-5px mar-b-m-6px "+ (activeTab == addNewLinkText ?"left-nav-header":"" )}><span onClick={this.onLeftMenuItemClick.bind(this, addNewUrl, ((addNewUrlParam)?(addNewUrlParam):((displayValue!=null)?(displayValue.length):(0))), 0,addNewLinkText)}  className="pad-l-35px"><span><span><i className="fa fa-plus-circle  mar-r-5px" aria-hidden="true"></i></span><span>{addNewLinkText}</span></span></span></div>):(""))}
               </div>): (<div></div>))}
              </div>
            </div>
        );
              }
}

LeftNavItems.defaultProps = {
    showControls:true,
    showControlsForGuarantor:true
};
export default LeftNavItems;

