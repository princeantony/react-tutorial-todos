/*eslint-disable no-undef */
/* React libraries */
import React, {PropTypes, Component} from "react";

/* plugin libraries */
import moment from 'moment';
import _ from "lodash";

/* Constant components */
import {
    BORROWER_CONSTANT,
    GUARANTOR_CONSTANT,
    LEGALENITITY_COMMON_CONSTANT,
    POSITION,
    VALIDATION_CONSTANT,
    URL_CONSTANT
} from "../../constants/ApplicationConstants";

/* Child components libraries */
import {renderAccordion, renderHyperLink} from "../form-components/Form";
import FormField from "../form-components/FormField";

import {isEmptyOrNullOrUndefined} from "../../utils/Functions";

class OtherInformation extends Component {
    constructor(props){
        super(props);
        this.state={
            IsSeparateMaintainanceIncomeOrExpense:false,
            IsSeparateMaintainanceIncomeOrExpenseValue: (props.data.IsSeparateMaintainanceIncomeOrExpense!=undefined && props.data.IsSeparateMaintainanceIncomeOrExpense!=null)?props.data.IsSeparateMaintainanceIncomeOrExpense:""
        };
    }

    onFieldBlur(e){
        if(e.target.name=="SeparateMaintainance"){
            if(e.target.value!=''){
                this.setState({IsSeparateMaintainanceIncomeOrExpense:true});
            }
            else{
                this.setState({IsSeparateMaintainanceIncomeOrExpense:false});
            }
        }
    }

    render() {
        const {isIndividual, isBorrower, initialData, data, onFieldChange, statesList, doValidate, hasError, affiliate, affiliateDefault, customerLabel, paramId, onFieldBlur}=this.props;
        let stateOfOrganization="";
        let RadioGroupValues = [{"Key": "Y", "Value": "Yes"}, {"Key": "N", "Value": "No"}];
        let MonthlySeparateMaintainance = [{"Key": 1, "Value": "Income"} , {"Key": 2, "Value":"Expense"}];
        let naicsUrl= URL_CONSTANT.NAICS_CODE_URL;
        if(initialData.StateOfOrganization!=undefined && initialData.StateOfOrganization!=null && initialData.StateOfOrganization!="" && initialData.StateOfOrganization!=0 && initialData.StateOfOrganization!=-1)
        {
            if(_.some(statesList, ['StateAbbrevation', initialData.StateOfOrganization]))
            {
                stateOfOrganization = _.find(statesList, ['StateAbbrevation', initialData.StateOfOrganization]).StateName;
            }
        }

        let vertical = POSITION.VERTICAL;
        let horizontal = POSITION.HORIZONTAL;
        return (<div>
            {
                renderAccordion('fa fa-newspaper-o', (LEGALENITITY_COMMON_CONSTANT.OTHER_DETAILS), 'panel accordion-brd-color font-size-12px', 'accordion-panel pad-4px bold', '', '',
                    ([
                        <div>
                            <div>{((!isIndividual) ? (<div><div className="row">
                                <FormField columnSize={4} orientation={vertical} key="PresentManagementSince"
                                           name="PresentManagementSince" displayValue={data.PresentManagementSince}
                                           type="date"
                                           displayText={LEGALENITITY_COMMON_CONSTANT.PRESENT_MANAGEMENT_SINCE}
                                           onFieldChange={onFieldChange} minDate={new Date('01/01/1400').toISOString()}
                                           maxDate={moment()}/>
                                <FormField columnSize={4} orientation={vertical} key="NumberOfEmployees"
                                           name="NumberOfEmployees" type="number" faClass="fa-users label-color"
                                           displayText={LEGALENITITY_COMMON_CONSTANT.TOTAL_NUMBER_OF_EMPLOYEES}
                                           displayValue={data.NumberOfEmployees} isNumberFormat={true} hasError={hasError} doValidate={doValidate}
                                           digitLength={false} maxValue={VALIDATION_CONSTANT.TOTAL_NUMBER_OF_EMPLOYEE}
                                           errorMessage={VALIDATION_CONSTANT.NUMBEROFEMPLOYEE_MESSAGE}/>
                                <FormField columnSize={4} orientation={vertical} key="StateOfOrganization"
                                name="StateOfOrganization" pleaseSelectValue={0}
                                dataTextField="StateName" dataValueField="StateAbbrevation"
                                type={((stateOfOrganization)?("label-group"):("select-single"))}
                                           displayText={LEGALENITITY_COMMON_CONSTANT.FORMATION_STATE}
                                               
                                           displayValue={((stateOfOrganization)?(stateOfOrganization):(statesList))}/>
                            </div>
                            <div>{((isBorrower==false)?(<div className="row"><FormField columnSize={4} orientation={vertical} key="Title"  name="Title" type="text" displayText={LEGALENITITY_COMMON_CONSTANT.TITLE} displayValue=" " help="This is the title the guarantor has with the business (i.e. CEO, CIO, President, etc.)" /></div>):(''))}</div>
                            <div className="row">
                            <FormField columnSize={5} orientation={horizontal}
                                key="PrivateEquityGroup" name="PrivateEquityGroup" type="radio"
                                                                displayText={LEGALENITITY_COMMON_CONSTANT.PRIVATE_EQUITY_GROUP}
                                                                onFieldChange={onFieldChange} displayValue={RadioGroupValues}
                                                                defaultOption={isEmptyOrNullOrUndefined(data.PrivateEquityGroup)?"N":data.PrivateEquityGroup} isRequired={true} hasError={hasError} doValidate={doValidate}/>

                            </div></div>) : (''))}</div>
                            <div>{((isIndividual) ? (
                                <div className="row"><FormField columnSize={5} orientation={horizontal}
                                key="Is53Employee" name="Is53Employee" type="radio"
                                                                displayText={"Is the "+ customerLabel +" a Fifth Third employee?"}
                                                                onFieldChange={onFieldChange} displayValue={RadioGroupValues}
                                                                defaultOption={isEmptyOrNullOrUndefined(data.Is53Employee)?"N":data.Is53Employee} isRequired={true} hasError={hasError} doValidate={doValidate}/>
                                </div>) : (''))}</div>
                            <div className="row">
                                {((isBorrower) ? (
                                    <FormField columnSize={4} orientation={vertical} key="Email" name="Email"
                                               faClass="fa-envelope label-color" type="email"
                                               displayText={LEGALENITITY_COMMON_CONSTANT.BUSINESS_EMAIL_ADDRESS}
                                               displayValue={data.Email} hasError={hasError} doValidate={doValidate}
                                               errorMessage={VALIDATION_CONSTANT.EMAIL_MESSAGE}/>) : (
                                               <div>
                                    {((isIndividual)?(
                                    <div className="row">
                                        <div className="col-md-4"><label className="clr-lbl font-size-12px">{GUARANTOR_CONSTANT.SEPERATE_MAINTAINANCE}</label></div>
                                        <div className="col-md-4">
                                                                   <FormField orientation={vertical} key="SeparateMaintainance"
                                        name="SeparateMaintainance"  type="currency" dollarFormat={true}
                                        faClass="fa-usd label-color font-size-14px bold" onFieldBlur={this.onFieldBlur.bind(this)}
                                        hasError={hasError} doValidate={doValidate} displayValue={data.SeparateMaintainance}/>
                                 </div>
                                        {(this.state.IsSeparateMaintainanceIncomeOrExpense)?(<div className="col-md-4">
                                        <FormField orientation={vertical} key="IsSeparateMaintainanceIncomeOrExpense" isRequired={(this.state.IsSeparateMaintainanceIncomeOrExpense)?true:false} hasError={hasError} doValidate={doValidate}
                                        name="IsSeparateMaintainanceIncomeOrExpense" type="radio" defaultOption={this.state.IsSeparateMaintainanceIncomeOrExpenseValue}
                                            displayValue={MonthlySeparateMaintainance} onFieldChange={onFieldChange} /> 
                                                </div>):(<div></div>)}
                                        </div>):('') )} </div>))}
                                            {((isBorrower && isIndividual)?(
                                            <FormField columnSize={6} orientation={vertical} key="GrossAnnualRevenue"
                                            name="GrossAnnualRevenue"
                                            faClass="fa-usd label-color font-size-14px bold" type="currency"
                                                isRequired={true} isZeroNotAllowed={true}
                                               displayText={LEGALENITITY_COMMON_CONSTANT.PERSONAL_GROSS_ANNUAL_INCOME}
                                               displayValue={data.GrossAnnualRevenue}
                                               dollarFormat={true} minValue={false} hasError={hasError} doValidate={doValidate}
                                               maxValue={VALIDATION_CONSTANT.GROSS_REVENUE_AMOUNT}
                                               errorMessage={VALIDATION_CONSTANT.GROSSREVENUE_MESSAGE}/>) : (''))}
                                    {(((data.Is53Employee!="Y") && (!isIndividual)) ? (
                                    <FormField columnSize={6} orientation={vertical} key="GrossRevenue"
                                               name="GrossRevenue" faClass="fa-usd label-color font-size-14px bold"
                                               type="currency" isRequired={true} isZeroNotAllowed={true}
                                               displayText={LEGALENITITY_COMMON_CONSTANT.GROSS_ANNUAL_REVENUE}
                                               displayValue={data.GrossRevenue}
                                               help="Gross Annual Revenue must be less than $1 billion"
                                               dollarFormat={true} minValue={false} hasError={hasError} doValidate={doValidate}
                                               maxValue={VALIDATION_CONSTANT.GROSS_REVENUE_AMOUNT}
                                               errorMessage={VALIDATION_CONSTANT.GROSSREVENUE_MESSAGE}/>) : (''))}
                            </div>
                            <div>{((isIndividual) ? (
                                <div className="row"><FormField columnSize={5} orientation={horizontal}
                                                                key="IsUSCitizen" name="IsUSCitizen" type="radio"
                                                                displayText={"Is " + customerLabel + " US Citizen?"}
                                                                defaultOption={paramId=="add"? null:(isEmptyOrNullOrUndefined(data.IsUSCitizen)?data.IsUSCitizen:true)}
                                                                onFieldChange={onFieldChange} isRequired={true} hasError={hasError} doValidate={doValidate}/>
                                </div>) : (''))}</div>
                            <div className="row"><FormField columnSize={5} orientation={horizontal}
                                                            key="IsMortgageLender" name="IsMortgageLender" type="radio"
                                                            displayText={"Is " + customerLabel + " a Mortgage Lender?"} 
                                                            defaultOption={paramId=="add"? null : (isEmptyOrNullOrUndefined(data.IsMortgageLender)?"N":data.IsMortgageLender)} displayValue={RadioGroupValues}
                                                            onFieldChange={onFieldChange} isRequired={true} hasError={hasError} doValidate={doValidate}/></div>

                              <div className="row"><FormField columnSize={5} orientation={horizontal}
                                                                key="RegO" name="RegO" type="radio"
                                                                displayText={LEGALENITITY_COMMON_CONSTANT.REG_O}
                                                                defaultOption={paramId=="add"?null:(isEmptyOrNullOrUndefined(data.RegO)?"N":data.RegO)}
                                                                displayValue={RadioGroupValues}
                                                                onFieldChange={onFieldChange} isRequired={true} hasError={hasError} doValidate={doValidate}/>
                                </div>
                                {affiliate !=undefined && affiliate!= null?(
                                <div className="row"><FormField columnSize={4} orientation={horizontal}
                                                                key="Affiliate" name="Affiliate" type="select-single"
                                                                displayText={LEGALENITITY_COMMON_CONSTANT.REGION}
                                                                defaultSelectValue={(affiliateDefault == null || affiliateDefault == undefined ? -1:affiliateDefault)}
                                                                dataValueField="Id" dataTextField="Name"
                                                                displayValue={affiliate}
                                                                isRequired={true} hasError={hasError} doValidate={doValidate}
                                                                errorMessage={VALIDATION_CONSTANT.LOAN_TYPE_ERROR}/>
                                </div>):''}
                              {((isBorrower) ? (
                            <div className="row">
                         <FormField columnSize={12} orientation={vertical}
                                        name="CompanyManagementHistory" type="textarea" rows="3" cols="15"
                                         displayText={LEGALENITITY_COMMON_CONSTANT.COMPANY_MANAGEMENT_HISTORY}
                                          displayValue={data.CompanyManagementHistory} />
                                         </div>):(''))}
                                <div className="row">
                                    <FormField columnSize={4} orientation={vertical} key="Attribute"
                                            name="NAICSCode.Attribute"
                                            help={"NAICS Search hyperlink linking to " + urlNaicsCode}
                                            type={((initialData.NAICSCode.Attribute == null || initialData.NAICSCode.Attribute == '' || initialData.NAICSCode.Attribute == "000000"  || _.trim(initialData.NAICSCode.Attribute).length!=6)?("number"):("label-group"))}
                                           displayText={LEGALENITITY_COMMON_CONSTANT.NAICS_CODE}
                                           displayValue={data.NAICSCode.Attribute} node={[<div
                                    className="pad-t-5px font-size-11px">{renderHyperLink('lnkNaicsCode', 'NAICS Code Lookup', naicsUrl, 'normal')}</div>]}
                                           isRequired={((initialData.NAICSCode.Attribute == '' || initialData.NAICSCode.Attribute == "000000" || initialData.NAICSCode.Attribute == null) ? true : false)}
                                           isNumberFormat={true} digitLength={6} hasError={hasError} doValidate={doValidate}
                                           errorMessage={VALIDATION_CONSTANT.NAICS_CODE_ERROR} maxLength={6}/>
                                <FormField columnSize={8} orientation={vertical} key="Description"
                                           name="NAICSCode.Description" type="label-group"
                                           displayText={LEGALENITITY_COMMON_CONSTANT.NAICS_CODE_DESCRIPTION}
                                           displayValue={data.NAICSCode.Description}/>
                            </div>
                        </div>
                    ]))
            }
        </div>);
    }
}
export default OtherInformation;
