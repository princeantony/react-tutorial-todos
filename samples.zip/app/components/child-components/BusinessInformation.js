/* React libraries */
import React, {PropTypes, Component} from "react";

/* Constant components */
import {LEGALENITITY_COMMON_CONSTANT, BORROWER_CONSTANT, POSITION, VALIDATION_CONSTANT} from "../../constants/ApplicationConstants";

/* Child components libraries */
import {renderAccordion} from "../form-components/Form";
import FormField from "../form-components/FormField";

import {getFormattedDate} from "../../utils/Functions";

class BusinessInformation extends Component
{
    render(){
        const {isIndividual, entityStructure, onEntityChange, isBorrower, initialData, data, isEditable, onFieldChange, isEntityStructureDisable, hasError, doValidate, customerLabel}= this.props;
        let vertical=POSITION.VERTICAL;
        if(isBorrower)
        {
            return(
                <div>
                    {
                        renderAccordion('fa fa-user-circle', (customerLabel + " Information"), 'panel accordion-brd-color font-size-12px', 'accordion-panel pad-4px bold', '', '',
                            (<div>
                                <div className="row">
                                    {(isIndividual || entityStructure.length == 0)?(<FormField columnSize={5} key="EntityStructures.StructureCode"  name="EntityStructure.StructureCode" orientation={vertical} type="label-group" displayText={LEGALENITITY_COMMON_CONSTANT.ENTITY_STRUCTURE} displayValue={data.EntityStructure.Desc} />):(
                                                <FormField columnSize={4} orientation={vertical} type="select-single" key="EntityStructure.StructureCode" name="EntityStructure.StructureCode" isDisabled={isEntityStructureDisable}        
                                                dataValueField="StructureCode" dataTextField="Desc" defaultSelectValue={entityStructure[0].StructureCode}
                                                help={isEntityStructureDisable?"Entity Structure cannot be updated. If you still want to update it, please cancel this application and start a new one":null} 
                                                displayText={LEGALENITITY_COMMON_CONSTANT.ENTITY_STRUCTURE} displayValue={entityStructure} onFieldChange={onEntityChange} />)}
                                   </div>
                                                {((!isIndividual)?(<div className="row"><FormField columnSize={3} key="LegalName"  name="LegalName" orientation={vertical} type="text" displayText={LEGALENITITY_COMMON_CONSTANT.BUSINESS_NAME} displayValue={data.LegalName} isRequired={true} hasError={hasError} doValidate={doValidate} /></div>):(<div className="row">
            <FormField columnSize={3} orientation={vertical} key="NameSuffix"  name="NameSuffix" type="text" displayText={LEGALENITITY_COMMON_CONSTANT.NAME_SUFFIX} displayValue={data.NameSuffix} />
            <FormField columnSize={3} orientation={vertical} key="FirstName"  name="FirstName" type="text" displayText={LEGALENITITY_COMMON_CONSTANT.FIRST_NAME} displayValue={data.FirstName} isRequired={true} hasError={hasError} doValidate={doValidate} />
            <FormField columnSize={3} orientation={vertical} key="MiddleName"  name="MiddleName" type="text" displayText={LEGALENITITY_COMMON_CONSTANT.MIDDLE_NAME} displayValue={data.MiddleName} />
            <FormField columnSize={3} orientation={vertical} key="LastName"  name="LastName" type="text" displayText={LEGALENITITY_COMMON_CONSTANT.LAST_NAME} displayValue={data.LastName} isRequired={true} hasError={hasError} doValidate={doValidate} /></div>))}
            <div className="row">
            <FormField columnSize={3} orientation={vertical} key={((!isIndividual)?("TaxId"):("SocialSecurityNumber"))}  name={((!isIndividual)?("TaxId"):("SocialSecurityNumber"))} type="label-group" displayText={LEGALENITITY_COMMON_CONSTANT.SSN_ITIN_OR_EIN} displayValue={((!isIndividual)?(data.TaxId):(data.SocialSecurityNumber))} />
            <FormField columnSize={3} orientation={vertical} key="BusinessStartedDate"  name="BusinessStartedDate" type={((initialData.BusinessStartedDate)?("label-group"):("date"))} displayText={LEGALENITITY_COMMON_CONSTANT.DATE_BUSINESS_STARTED} displayValue={getFormattedDate(data.BusinessStartedDate)} onFieldChange={onFieldChange} minDate={new Date('01/01/1400').toISOString()}  />
            </div></div>))}
                </div>);
        }
        else{
            return(
                <div>
                       {
                        renderAccordion('fa fa-user-circle', (customerLabel + " Information"), 'panel accordion-brd-color font-size-12px', 'accordion-panel pad-4px bold', '', '',
                            (<div className="row">
                                {((!isIndividual)?(<div>
                                    {(entityStructure.length == 0)?(<FormField columnSize={3} key="EntityStructures.StructureCode"  name="EntityStructure.StructureCode" orientation={vertical} type="label-group" displayText={LEGALENITITY_COMMON_CONSTANT.ENTITY_STRUCTURE} displayValue={data.EntityStructure.Desc} />):(
                                            <FormField columnSize={4} orientation={vertical}  key="EntityStructures.StructureCode" dataTextField="Desc" dataValueField="StructureCode"  name="EntityStructures.StructureCode"  type="select-single" displayText={LEGALENITITY_COMMON_CONSTANT.ENTITY_STRUCTURE} displayValue={entityStructure} onFieldChange={onEntityChange} hasError={hasError} doValidate={doValidate}/>)}
                                    <FormField columnSize={4} orientation={vertical} key="LegalName"  name="LegalName"  type={((isEditable)?("text"):("label-group"))} displayText={LEGALENITITY_COMMON_CONSTANT.BUSINESS_NAME} displayValue={data.LegalName} isRequired={((isEditable)?(true):(false))} hasError={hasError} doValidate={doValidate}/>
                                    <FormField columnSize={4} orientation={vertical} key="EIN" name="EIN" type={((isEditable)?("text"):("label-group"))} displayText={LEGALENITITY_COMMON_CONSTANT.EIN} displayValue={data.TaxId} isRequired={((isEditable)?(true):(false))} isNumberFormat={true} digitLength={9} errorMessage ={VALIDATION_CONSTANT.SSN_TIN_EIN_ERROR} hasError={hasError} doValidate={doValidate}/>
                                    
                                </div>):(<div>
                                    <div className="row"><FormField columnSize={4} orientation={vertical} key="NameSuffix"  name="NameSuffix" type={((isEditable)?("text"):("label-group"))} displayText={LEGALENITITY_COMMON_CONSTANT.NAME_SUFFIX} displayValue={data.NameSuffix} /></div>
                                    <div className="row"><FormField columnSize={4} orientation={vertical} key="FirstName"  name="FirstName" type={((isEditable)?("text"):("label-group"))} displayText={LEGALENITITY_COMMON_CONSTANT.FIRST_NAME} displayValue={data.FirstName} isRequired={((isEditable)?(true):(false))} hasError={hasError} doValidate={doValidate} />
                                    <FormField columnSize={4} orientation={vertical} key="MiddleName"  name="MiddleName" type={((isEditable)?("text"):("label-group"))} displayText={LEGALENITITY_COMMON_CONSTANT.MIDDLE_NAME} displayValue={data.MiddleName}  />
                                    <FormField columnSize={4} orientation={vertical} key="LastName"  name="LastName" type={((isEditable)?("text"):("label-group"))} displayText={LEGALENITITY_COMMON_CONSTANT.LAST_NAME} displayValue={data.LastName} isRequired={((isEditable)?(true):(false))} hasError={hasError} doValidate={doValidate}/></div>
                                    <div className="row"><FormField columnSize={4} orientation={vertical} key="SocialSecurityNumber"  name="SocialSecurityNumber" type={((isEditable)?("text"):("label-group"))} displayText={LEGALENITITY_COMMON_CONSTANT.SSN_ITIN_OR_EIN} displayValue={data.SocialSecurityNumber} isRequired={((isEditable)?(true):(false))} isNumberFormat={true} digitLength={9} maxLength={9} errorMessage ={VALIDATION_CONSTANT.SSN_TIN_EIN_ERROR} hasError={hasError} doValidate={doValidate}/>
                                    <FormField columnSize={4} orientation={vertical} key="DateOfBirth"  name="DateOfBirth" type={((isEditable)?("date"):(((initialData.DateOfBirth)?("label-group"):("date"))))} displayText={LEGALENITITY_COMMON_CONSTANT.DATE_OF_BIRTH} displayValue={getFormattedDate(data.DateOfBirth)} onFieldChange={onFieldChange} minDate={new Date('01/01/1900').toISOString()}  /></div>
                                </div>))}
                            </div>))
                         }
                    </div>);
            }
    }
}

BusinessInformation.defaultProps = {
    isEditable:false
};

export default BusinessInformation;