﻿/* React libraries */
import React, {PropTypes, Component} from "react";

/* Constant components */
import {LEGALENITITY_COMMON_CONSTANT, BORROWER_CONSTANT, POSITION, VALIDATION_CONSTANT,OWNERSHIPTIE_CONSTANT} from "../../constants/ApplicationConstants";

/* Child components libraries */
import {renderAccordion} from "../form-components/Form";
import FormField from "../form-components/FormField";

let vertical=POSITION.VERTICAL;
let horizontal=POSITION.HORIZONTAL;
class OwnerTieInformation extends Component {
    constructor(props) {
        super(props);
        this.state={
            disabledOwner: (props.legalEntityDetails!=undefined && props.legalEntityDetails!=null)?((props.legalEntityDetails.EntityStructure.StructureCode=="LP" || props.legalEntityDetails.EntityStructure.StructureCode=="GP")?(1):(4)):("")
        };
    }

    render() {
        const{data, onFieldChange, onFieldBlur, onKeyDown, legalEntityDetails}=this.props;
        return(
            <div>
               {
                   renderAccordion('fa fa-handshake-o', OWNERSHIPTIE_CONSTANT.TIE_INFORMATION, 'panel accordion-brd-color font-size-12px', 'accordion-panel pad-4px bold', '', '',
                    ([
                        <div>
                            <div className="row"><FormField disabledOption={this.state.disabledOwner} columnSize={0} orientation={horizontal} key="AssignmentTypeId" name="AssignmentTypeId" type="radio" width="500" defaultOption={data.OwnershipType} displayValue={[{"Key":6,"Value":"Limited Partner"},{"Key":4,"Value":"General Partner"},{"Key":1,"Value":"Owner"}]} onFieldChange={onFieldChange} defaultOption={data.AssignmentTypeId} /></div>
                                {((data.AssignmentTypeId==1)?(<div className="row"><FormField columnSize={4} orientation={horizontal} key="DisplayPercentage"  name="DisplayPercentage" faClass="fa-percent label-color" type="text" help="Input the percentage of the business owned by this individual." displayValue={data.DisplayPercentage} displayText={OWNERSHIPTIE_CONSTANT.PERCENT_OWNERSHIP} onFieldBlur={onFieldBlur} /></div>):(<div></div>))}
                        </div>
                            ])
                   )
                            }
            </div>
        );
                            }
}

export default OwnerTieInformation;


