﻿/* React libraries */
import React, {PropTypes, Component} from "react";
import {connect} from "react-redux";

/* plugin libraries */
import _ from "lodash";

/* Child components libraries */
import {renderSection} from "../../form-components/Form";
import FormField from "../../form-components/FormField";
import {showError, getURLPath} from "../../../utils/Functions";

let legalEntityId;
class SearchGrid extends Component{
    isLEExist(legalEntity, legalEntityId){
        switch(legalEntity)
        {
            case 'Borrower Owner':return ((this.props.borrower.Id==legalEntityId)?("An entity cannot be assigned as an Owner to itself."):(_.some(this.props.borrowerOwnersList, ['RelatedEntity.Id', legalEntityId])?("You cannot add the selected entity as an Owner as it is already listed as an Owner of Borrower in the Application Navigator."):null));
            case 'Guarantor': return ((this.props.borrower.Id==legalEntityId)?("An entity cannot be assigned as an Guarantor to itself."):(_.some(this.props.guarantorsList, ['RelatedEntity.Id', legalEntityId])?("You cannot add the selected Guarantor as it is already in the list."):null));
            case 'Guarantor Owner': {   let _path = getURLPath(location.pathname);
                return ((this.props.borrower.Id==legalEntityId)?("Primary Borrower cannot be assigned as an Guarantor Owner."):((this.props.guarantorsList[_path[4]].RelatedEntity.Id==legalEntityId)?("An entity cannot be assigned as an Guarantor Owner to itself."):(_.some(this.props.guarantorsList[_path[4]].RelatedEntity.OwnershipTies, ['RelatedEntity.Id', legalEntityId])?("You cannot add the selected entity as an Owner as it is already listed as an Owner of Guarantor in the Application Navigator."):null)));
            }
            ///case 'Customer': return ((this.props.borrower.Id==legalEntityId)?true:(_.some(this.props.guarantorsList, ['RelatedEntity.Id', legalEntityId])));
            ///default: return false;
        }
    }

    onUseSelectedLEClick(){
        let errorMessage = this.isLEExist(this.props.addNewButtonDisplayText, legalEntityId);
        if(errorMessage==null)
        {
            if(this.props.onContinueButtonClick)
            {
                this.props.onContinueButtonClick();
            }
        }
        else
        {
            showError(errorMessage);   
        }
    }

    onRowSelect(row, isSelected){
        if(this.props.onRowSelect && isSelected)
        {
            legalEntityId= row.LegalEntityId;
            this.props.onRowSelect(row, isSelected);
        }
    }

    render(){
        let {searchcustomerPageHeaderText, displayValue, isHover, isSort, isSearch, selectType, onRowSelect, onAddButtonClick, onContinueButtonClick, SearchMoreResult, isContinueDisable, onSearchAgainClick, showErrorMessage, searchAgain, addNewButtonDisplayText, isAddNewBorrowerDisable}=this.props;
        return(
            <div>
                {renderSection((searchcustomerPageHeaderText), "panel", "pnl-sub-header-green width-20-per pad-4px font-size-14px bold mar-l-5px", "",
                    ([<div>
                        <fieldset className="brd-radius-3px mar-t-m-5px">
                            <div className="col-lg-12 pad-0px mar-0px">
                                <div className="row mar-l-5px mar-r-5px pnl-brd-darkgray brd-radius-10px bg-clr-white">
                                           {((showErrorMessage && displayValue.length>100)?(<div><div className="alert alert-danger mar-b-0px" role="alert"><div>Your search has returned more than 100 results. Please provide additional criteria to narrow your search.</div></div></div>):(''))}
                                           <FormField id="grdSearch" keyValue="LegalEntityId" type="grid"
                                                displayValue={displayValue} hover={isHover}
                                                sort={isSort}  addNewButtonDisplayText={addNewButtonDisplayText}
                                                search={isSearch} selectType={selectType} isAddNewBorrowerDisable={isAddNewBorrowerDisable}
                                                onRowSelect={this.onRowSelect.bind(this)} onAddButtonClick={onAddButtonClick}
                                                SearchMoreResult={SearchMoreResult}/>
                                            <div className="row">
                                                <div className="pad-r-40px pad-t-0px pad-b-0px pull-right mar-t-m-20px pad-r-0px-xs wid-100-per-xs text-center-xs">
                                                {((searchAgain)?(<div className="pull-left mar-r-10px">
                                                   <div className="btn-primary bg-btn-clr-navy">
                           		                    <span className="fa fa-search" aria-hidden="true"></span>
						                                <input type="button" className="bg-clr-transparent br-none  pad-l-7px"  value="Search Again" onClick={onSearchAgainClick} />
                                                   </div> </div>):(<div></div>))}
                                                    {/*(isAddNewBorrowerDisable || displayValue.length==0)?(''):(<div className="pull-left mar-r-10px btn-primary bg-btn-clr-navy">
                           		                <span className="fa fa-plus" aria-hidden="true"></span>
						                        <input type="button" className="bg-clr-transparent br-none  pad-l-7px" value={"Create New " + addNewButtonDisplayText}
                           		                    disabled={isAddNewBorrowerDisable} onClick={onAddButtonClick} />
                                        </div>)*/}
                                     {/*<div className={"pull-left mar-r-10px " + (isAddNewBorrowerDisable?"btn-disabled disabled":"btn-primary bg-btn-clr-navy")}>
                           		                <span className={"fa fa-plus" +(isAddNewBorrowerDisable?"disabled":"")} aria-hidden="true"></span>
						                        <input type="button" className="bg-clr-transparent br-none  pad-l-7px" value={"Create New " + addNewButtonDisplayText}
                                         disabled={isAddNewBorrowerDisable} onClick={onAddButtonClick} />
                             </div>*/}
                                        <div className={"pull-left mar-r-m-30px "  + (isContinueDisable?"btn-disabled disabled":"btn-primary bg-btn-clr-navy")}>
                           		 <span className={"fa fa-chevron-right " + (isContinueDisable?"disabled":"")} aria-hidden="true"></span>
						  <input type="button" className={"bg-clr-transparent br-none  pad-l-7px "+ (isContinueDisable?"disabled":"")}  value={"Use Selected " + addNewButtonDisplayText}
						  onClick={this.onUseSelectedLEClick.bind(this)}
                                                    disabled={isContinueDisable}/>
                                         </div>
                                     </div>
                                 </div>
                             </div>
                         </div>
                     </fieldset>
                 </div>]))}
            </div>
        );
                                                }
}

SearchGrid.defaultProps = {
    showErrorMessage:false,
    searchAgain:false,
};

let mapStateToProps = (state) => {
    return {
        borrower: state.loanAppReducer.LoanApplication.Borrower,
        borrowerOwnersList: state.loanAppReducer.LoanApplication.Borrower.OwnershipTies,
        guarantorsList: state.loanAppReducer.LoanApplication.Guarantors,
        collateralList: state.loanAppReducer.LoanApplication.Collaterals
    }
};

export default connect(mapStateToProps)(SearchGrid);
