﻿/* React libraries */
import React, {PropTypes, Component} from "react";

/* Constant components */
import {LEGALENITITY_COMMON_CONSTANT, SEARCH_CONSTANT, POSITION, VALIDATION_CONSTANT} from "../../../constants/ApplicationConstants";

/* Child components libraries */
import {renderSection, renderAccordion, renderSpinner} from "../../form-components/Form";
import FormField from "../../form-components/FormField";

class SearchCriteriaPage extends Component{
    render(){
        let {searchPageHeader, onKeyDown, isDisabled, onResetClick, onSearchClick}=this.props;
        let vertical=POSITION.VERTICAL;
        return(
            <div>
                {renderSection((searchPageHeader),"panel","pnl-sub-header-green width-30-per pad-4px font-size-14px bold mar-l-5px","",
                    ([<div>
                       <div className={(isDisabled?"overlay-div":"")}> &nbsp;
                                </div>
                                {(isDisabled?renderSpinner():"")}
                        <fieldset  className="brd-radius-3px mar-t-m-5px">
                            <div className="col-lg-12 pad-0px mar-0px">
                                <div className="row mar-l-5px mar-r-5px pnl-brd-darkgray brd-radius-10px bg-clr-white pad-b-0px">
                                    <div className="row pad-b-0px">
                                        {/* Search criteria section */}
                                    {renderAccordion('fa fa-search', (SEARCH_CONSTANT.SEARCH_CRITERIA), "panel accordion-brd-color font-size-12px", "accordion-panel pad-4px bold", "", "",
                        ([<div>
                            <div className="row pad-b-0px">
                                <FormField columnSize={4} orientation={vertical} key="TINSSN" name="TINSSN"  type="text"  displayText={LEGALENITITY_COMMON_CONSTANT.SSN_ITIN} onKeyDown={onKeyDown}  isNumberFormat={true} digitLength={9} errorMessage ={VALIDATION_CONSTANT.SSN_TIN_EIN_ERROR} />
                                <FormField columnSize={4} orientation={vertical} key="CUSTOMER_NAME" name="CUSTOMER_NAME"  type="text"  displayText={LEGALENITITY_COMMON_CONSTANT.CUSTOMER_NAME}  onKeyDown={onKeyDown} />
                            </div>
							 
                                          </div>])
                         )}
						  <div className="col-lg-12 mar-t-0px mar-b-15px pull-right pad-r-0px pad-l-0px wid-100-per-xs text-center-xs">
                    <div className="row">
                        <div className="pull-right pad-r-5px  btn-primary bg-btn-clr-navy">
                           		 <span className="fa fa-refresh" aria-hidden="true"></span>
						  <input type="button" className="bg-clr-transparent br-none wid-55px pad-l-7px" value="Reset" onClick={onResetClick} />
                        </div>
                        <div className="pull-right pull-left-xs pad-r-10px btn-primary bg-btn-clr-navy mar-r-10px">
						 <span className="fa fa-search" aria-hidden="true"></span>
                        <input type="button" className="bg-clr-transparent br-none wid-55px pad-l-7px" value="Search" onClick={onSearchClick} disabled={isDisabled} />
                        </div>
                    </div>
                </div>
                                    </div>
                                </div>
                            </div>
                        </fieldset>
                    </div>])
                )}
            </div>
        );
            }
}
export default SearchCriteriaPage;