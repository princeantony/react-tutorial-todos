﻿/* React libraries */
import React, { PropTypes, Component } from "react";

/* Constant components */
import {LEGALENITITY_COMMON_CONSTANT, VALIDATION_CONSTANT, POSITION, LEGEND_CONSTANT} from "../constants/ApplicationConstants";

/* LoanApp libraries */
import {showError} from "../utils/Functions";

/* Child components libraries */
import {renderAccordion, renderSection, renderSpinner} from "./form-components/Form";
import FormField from "./form-components/FormField";
import OwnerTieInformation from "./child-components/OwnerTieInformation";
import BusinessInformation from "./child-components/BusinessInformation";
import PhoneNumbers from "./child-components/PhoneNumbers";
import OtherInformation from "./child-components/OtherInformation";
import MultipleAddress from "./MultipleAddress";
import EditableAddress from "./EditableAddress";

/* Action components */
import {AddAddress } from "../utils/AddressFunctions";

/* variable declaration start */
let existingAddress = null;
let newBusinessAddressType = "T";
let newHomeAddressType = "S";
let _index=null;
let _isIndividual = null;
let _tempAddress = null;
let vertical=POSITION.VERTICAL;
let horizontal=POSITION.HORIZONTAL;
let errorCollection = {};
/* variable declaration end */

class Owner extends Component
{
    constructor(props, context) {
        super(props, context);
        this.state = {
            isAddressEditClicked: false,
            defaultAddressOptionFor: "",
            saveNewBusinessAddress: props.data.RelatedEntity.PrimaryAddress,    // To be one flag
            saveNewHomeAddress: props.data.RelatedEntity.SecondaryAddress,
            ownerAddressNew: null,
            isInternational: false,
            saveOwnerNewAddress: false,
            ownerAddressCount: 1,
            doValidateAddress: false
        };
    }

    onDoneClick(){
        if(this.props.onNextButtonClick)
        {
            let formData = null;
            let _addressType=null;

            if(_index == "add"){
                let _tempOwnerAddress = {};
                formData=$("#OwnerAddress_Editable :input").serializeArray();
                {formData && formData.map((data, index) => {
                    _.set(_tempOwnerAddress, data.name, data.value);
                })}
                _.set(_tempOwnerAddress,"AddressTypeId" , "E");
                _tempAddress = Object.assign({}, _tempOwnerAddress);
            }

            if(!this.state.isInternational)
                _.set(_tempAddress,"CountryId" , 223);

            if(this.state.saveOwnerNewAddress && this.state.ownerAddressNew)
                AddAddress(_tempAddress, this.state.ownerAddressNew, "T");

            if(this.state.saveOwnerNewAddress == false && _index!="add")
                _tempAddress = null;
            
            this.props.onNextButtonClick(this,_tempAddress);
        }
    }

    onEditClick(e){
        this.setState({isAddressEditClicked:true});
        if(this.state.ownerAddressNew == null){
            this.setState({ownerAddressNew: existingAddress});
        }
        this.setState({isInternational:existingAddress.IsInternational});
    }

    onCancelClick(e){
        if(this.state.ownerAddressCount == 1){
            this.setState({ownerAddressNew: null});
        }
        this.setState({isAddressEditClicked:false}); 
    }

    onClearClick(e){
        //need to implement
    }

    onAddressTypeClick(_isInternational){
        this.state.ownerAddressNew.IsInternational = _isInternational;
    }

    hasError(error, e, isOnBlur){
        let fieldName=e.name;
        if(e.id!=undefined && e.id!=null)
            fieldName = e.id;
        if(error[fieldName])
            _.set(errorCollection, fieldName, error[fieldName]);
        else
            _.unset(errorCollection, fieldName);
    }

    onUpdateClick(e){
        e.preventDefault();
        errorCollection = {};
        this.setState({doValidateAddress: true});
    }
    componentDidUpdate(prevProps, prevState){
        if(prevState.doValidateAddress != this.state.doValidateAddress)
        {
            this.state.doValidateAddress = false;
            if(_.size(errorCollection)>0)
            {
                if(this.props.isBorrowerOwner)
                {
                    showError(VALIDATION_CONSTANT.BORROWER_OWNER_ERROR_MESSAGE);
                }
                else
                {
                    showError(VALIDATION_CONSTANT.GUARANTOR_OWNER_ERROR_MESSAGE);
                }
            }
            else
            {
                if(this.state.isAddressEditClicked){
                    this.UpdateAddress();
                }
            }
        }
    }
    UpdateAddress(){
        this.setState({isAddressEditClicked:false});
        let formData=$("#OwnerAddress_Editable :input").serializeArray();
        let _tempOwnerAddress = Object.assign({}, this.state.ownerAddressNew);
        {formData && formData.map((data, index) => {
            _.set(_tempOwnerAddress, data.name, data.value);
        })}
        this.state.ownerAddressNew = Object.assign({}, _tempOwnerAddress);
        this.setState({
            saveOwnerNewAddress: true,
            defaultAddressOption: 2,
            ownerAddressCount: 2
        });
    }
    onMismatchClick(name, value) {
        if (name == "AddressIndividual_true" || name=="AddressIndividual_false" ) {
            this.state.saveOwnerNewAddress = value == "2"? true: false;                   
        }        
    }
    
    render(){
        const {initialData, onFieldChange, onFieldBlur, index, data, isNextButtonDisable, onNextButtonClick, mobileErrorMessage, entityStructure, isIndividual, isBorrowerOwner, legalEntitycommondata, displayName, hasError, doValidate, legalEntityDetails}= this.props;
        existingAddress = _.find(data.RelatedEntity.Addresses, {'AddressTypeId': this.state.saveNewBusinessAddress? "T": "E"});
        _index = index;
        _isIndividual = isIndividual;
        _tempAddress = data.RelatedEntity.Addresses;
        return(<div>
                    {renderSection(('Owner '+ parseInt(displayName)),'panel','pnl-sub-header-green width-30-per pad-4px font-size-14px bold mar-l-5px','',
                    (<div>
                        <form method="post" action="" key="ownerForm" name="ownerForm" id="ownerForm" ref="ownerForm" >
                                {(isNextButtonDisable?renderSpinner():"")}
                            <fieldset className="brd-radius-3px mar-t-m-5px">
                                <div className="col-lg-12 pad-0px mar-0px">
                                    <div className="mar-l-5px mar-r-5px pnl-brd-darkgray">
                                        <FormField type="legend" displayText={LEGEND_CONSTANT.REQUIRED_FIELD} />

                                        <div className="mar-t-20px pad-b-5px pad-l-5px pad-r-5px pad-t-25px font-size-11px">
                                            {/*Type Of  Owner*/}
                                            <div className="row mar-l-5px mar-r-5px brd-radius-1px">
                                               <div className="row">
                                                   <FormField columnSize={4} orientation={horizontal} name="EntityStructure.StructureCode" type="radio" displayText={LEGALENITITY_COMMON_CONSTANT.TYPE_OF_CUSTOMER}  defaultOption={(((data.RelatedEntity.EntityStructure.StructureCode!=null)?((data.RelatedEntity.EntityStructure.StructureCode.trim()!="I")?("C"):("I")):("")))} displayValue={[{"Key":"I","Value":"Individual"},{"Key":"C","Value":"Corporate"}]} onFieldChange={onFieldChange} isDisabled={(index!=="add")?true:false}  />
                                               </div>
                                           </div>
                                               {((data.RelatedEntity.EntityStructure.StructureCode!=null)?(<div>
                                                <div className={(data.IsExisting)?"disabled":""}><OwnerTieInformation data={data} onFieldChange={onFieldChange} onFieldBlur={onFieldBlur} legalEntityDetails={legalEntityDetails} /></div>
                                                <div id="ownershipTie" name="ownershipTie">
                                                    <div><BusinessInformation customerLabel="Owner" entityStructure={entityStructure} isIndividual={isIndividual} isBorrower={false} initialData={initialData.RelatedEntity} data={data.RelatedEntity} isEditable={((index=="add")?(true):(false))} onFieldChange={onFieldChange}  hasError={hasError} doValidate={doValidate}/></div>
                                                    <div>
                                                    {/* Owner Address part start here*/}
                                                    {(index =="add")?(
                                                     
                                                         (renderAccordion('fa fa-address-card', (isIndividual ? LEGALENITITY_COMMON_CONSTANT.HOME_ADDRESS : LEGALENITITY_COMMON_CONSTANT.BUSINESS_ADDRESS),"panel accordion-brd-color font-size-12px", "accordion-panel pad-4px bold", "","",
                                                         <div><EditableAddress addressType="InputAddressType" disabled={false}  name={"InputAddress"} type={isIndividual ? "OwnerAddress" : "Business"} 
                                                        commonData={legalEntitycommondata} onAddressTypeClick={this.onAddressTypeClick.bind(this)} 
                                                        isInternational={this.state.isInternational} 
                                                        onFieldBlur={this.props.onFieldBlur.bind(this)} 
                                                        hasError={hasError} doValidate={doValidate}/>
                                                            </div>
                                                              ))
                                                        
                                                    ):(<div>
                                                          
                                                          {(existingAddress != null && existingAddress != undefined) ?
                                                             (renderAccordion('fa fa-address-card', (isIndividual? LEGALENITITY_COMMON_CONSTANT.HOME_ADDRESS: LEGALENITITY_COMMON_CONSTANT.BUSINESS_ADDRESS),"panel accordion-brd-color font-size-12px", "accordion-panel pad-4px bold", "","",
                                                            <div>
                                                            {(!this.state.isAddressEditClicked)?(
                                                                <div>
                                                                        <MultipleAddress
                                                                            onMismatchClick={this.onMismatchClick.bind(this)}
                                                                            name={"AddressIndividual_" + isIndividual}
                                                                            existingAddress={existingAddress}
                                                                            newAddress={this.state.ownerAddressNew ? this.state.ownerAddressNew: null}
                                                                            addressCount={this.state.ownerAddressCount}
                                                                            defaultOption={this.state.defaultAddressOption}
                                                                            hasError={hasError} doValidate={doValidate} />
                                                                         
                                                                            <a name="OwnerAddress_Edit" className={(this.state.ownerAddressCount == 1)?("link pull-left mar-l-342px edit-link-style"):("link mar-r-20px pull-right edit-link-style")}
                                                                            onClick={this.onEditClick.bind(this)}>Edit</a>
                                                                 </div>
                                                             ):''}
                                                            {(this.state.isAddressEditClicked)?(
                                                                <EditableAddress addressType="EditableAddressType" disabled={false} name={"AddressIndividual_" + isIndividual} 
                                                                        addressInformation={this.state.ownerAddressNew} type={"OwnerAddress"} isInternational={this.state.isInternational}
                                                                        commonData={legalEntitycommondata}
                                                                        onCancelClick={this.onCancelClick.bind(this)}
                                                                        onUpdateClick={this.onUpdateClick.bind(this)}
                                                                        onClearClick={this.onClearClick.bind(this)} 
                                                                        onAddressTypeClick={this.onAddressTypeClick.bind(this)} 
                                                                        onFieldBlur={this.props.onFieldBlur.bind(this)}
                                                                        hasError={this.hasError.bind(this)} doValidate={this.state.doValidateAddress} />
                                                             ):''}
                                                       </div>
                                                    )):<div></div>}
                                                    </div>)}
                                                        {/* Owner Address part ends here*/}
                                                        </div>
                                                        <div><PhoneNumbers initialData={initialData.RelatedEntity} data={data.RelatedEntity} errorMessage={mobileErrorMessage}  hasError={hasError} doValidate={doValidate}/></div>
                                                        <div><OtherInformation customerLabel="Owner" isIndividual={isIndividual}
                                                        isBorrower={isBorrowerOwner} initialData={initialData.RelatedEntity}
                                                        data={data.RelatedEntity} onFieldChange={onFieldChange}
                                                        affiliate = {legalEntitycommondata.Affilliates} paramId={_index}
                                                        affiliateDefault = {((data.RelatedEntity.Affiliate==null || data.RelatedEntity.Affiliate==undefined)?(-1):(data.RelatedEntity.Affiliate.Code))}
                                                        statesList={legalEntitycommondata.States} 
                                                        hasError={hasError} doValidate={doValidate} /></div>
                                                </div>
                                                <div className={this.state.isAddressEditClicked?"disabled pull-right pad-r-5px mar-t-10px mar-r-5px btn-primary bg-btn-clr-navy":"pull-right pad-r-5px mar-t-10px mar-r-5px btn-primary bg-btn-clr-navy"}>
                           		                    <span className=" fa fa-lg fa-floppy-o" aria-hidden="true"></span>
						                            <input type="button" className="bg-clr-transparent br-none wid-55px pad-l-7px" value="Save" onClick={this.onDoneClick.bind(this)} disabled={isNextButtonDisable} />
                                                </div></div>):(<div></div>))}
                                        </div>
                                    </div>
                                 </div>
                         </fieldset>
                         <div className={(isNextButtonDisable?"overlay-div":"")}> &nbsp;</div>
                      </form>
                 </div>))}
               </div>);
            }
}


export default Owner;