import React, { PropTypes, Component } from 'react';
import FormField from './form-components/FormField';
import {LEGALENITITY_COMMON_CONSTANT,  POSITION} from '../constants/ApplicationConstants';

class InternationalAddress extends Component{

    constructor(props, context) {
        super(props, context);
    }

    OnCancelClick(e){
      this.props.OnCancelClick(e); 
    }
    OnClearClick(e){
      this.props.OnClearClick(e);
    }
    OnAddressChnage(e){
        this.props.OnAddressChnage(e);
    }
    OnUpdateClick(e){
        this.props.OnUpdateClick(e);
    }
    render(){
        const{commonData, borrowerinformation, name, isDisabled, addressType }=this.props;
        let vertical=POSITION.VERTICAL;
        let horizontal=POSITION.HORIZONTAL;
        let required=false;
        (addressType=="borrowerAddressType")?(required=false):(required=true);

        return(<div className={isDisabled?"disabled":""} name={name} id={name}>
            <div className="row">
                <FormField columnSize={4} orientation={vertical} name="Line1" type="text"
                displayText={LEGALENITITY_COMMON_CONSTANT.ADDRESS_Line1}  displayValue={borrowerinformation.Line1} isRequired={required}/>
                <FormField columnSize={4} orientation={vertical} name="Line2" type="text"
                displayText={LEGALENITITY_COMMON_CONSTANT.ADDRESS_Line2} displayValue={borrowerinformation.Line2}/>
                <FormField columnSize={4} orientation={vertical} name="City" type="text"
                displayText={LEGALENITITY_COMMON_CONSTANT.CITY} displayValue={borrowerinformation.City} isRequired={required}/>
            </div>
            <div className="row">
                <FormField columnSize={4} orientation={vertical} id={borrowerinformation.CountryId}
                type="select-single" displayText={LEGALENITITY_COMMON_CONSTANT.COUNTRY} displayValue={commonData}
                name="CountryId" isRequired={required} dataValueField="Id"
                dataTextField="Name" defaultSelectValue={borrowerinformation.CountryId} />
                <FormField columnSize={4} orientation={vertical} name="Province" type="text"
                displayText={LEGALENITITY_COMMON_CONSTANT.REGION_PROVINCE} displayValue={borrowerinformation.Province}/>
                <FormField columnSize={4} orientation={vertical} name="ZipCode" type="text"
                displayText={LEGALENITITY_COMMON_CONSTANT.ZIP_POSTAL_CODE} displayValue={borrowerinformation.ZipCode} isRequired={required}/>

                {(addressType=="guarantorAddressType")?(
                <div className="pull-right mar-r-43px mar-t-15px">
                    <input type="button" id="btnUpdate"  name={name+"_Update"} className="btn btn-primary" onClick={this.OnUpdateClick.bind(this)}  value="Update" />
                    <input type="button" id="btnClear"  name={name +"_Clear"} className="btn btn-primary mar-l-15px"  value="Clear" onClick={this.OnClearClick.bind(this)}/>
                        <input type="button" id="btnCancel" name={name + "_Cancel"} onClick={this.OnCancelClick.bind(this)} className="btn btn-primary mar-l-15px"  value="Cancel" />
                </div>
                ):''}
            </div>
            
        </div>)}
            }
                InternationalAddress.propTypes = {
                    borrowerinformation :PropTypes.array.isRequired,
                    commonData:PropTypes.object.isRequired
                }
export default InternationalAddress;
