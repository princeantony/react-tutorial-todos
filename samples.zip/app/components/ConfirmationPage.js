﻿/* React libraries */
import React, {Component, PropTypes} from "react";

/* plugin libraries */
import _ from "lodash";
/* Constant components */
import {CONFIRMATION_PAGE_CONSTANT, POSITION, URL_CONSTANT} from "../constants/ApplicationConstants";
/* Action components */
import {GetFinancialNeedsDocument, GetSnapShotAndDisclosuresDocument} from "../actions/serviceAction";
/* Child components libraries */
import Header from "./Header";
import Footer from "./Footer";
import FormField from "./form-components/FormField";
import {renderSection, renderGrid, renderSpinner} from "./form-components/Form";

/* LoanApp libraries */
import {showError, getDisclosureAfterSubmit, getDisclosureUrl} from "../utils/Functions";

/* variable declaration start */
let displayProductList=[];
let borrowerName = "";
let headers=[{name:'Product ID', value:'Id'},{name:'Product', value:'ProductDisplayName'},{name:'Amount', value:'Amount'},{name:'Description', value:'ProductDescription'}];
const selectRowProp = {
    mode: ''
};
/* variable declaration end */

class ConfirmationPage extends Component {
    constructor(props, context) {
        super(props, context);

        this.state = {
            downloading: false,
        };
    }

    onDisclosureLinkClick(url){
        window.open(url,'_blank');
    }   

    _onClose(e) {
        window.close();
    }

    _generateFinancialNeedsDocument(e) {
        
        GetFinancialNeedsDocument(this.props.confirmationDetails);
        //this.setState({downloading:true});        
    }

    _generateSnapShotAndDisclosuresDocument(e) {
        
        GetSnapShotAndDisclosuresDocument(this.props.confirmationDetails);
        //this.setState({downloading:true});
    }

    getIntegrationCode(productType){
        let ProductTypeDesc = _.find(this.props.Data.ProductTypeList, ["IntegrationCode", productType]);
        return (ProductTypeDesc!=undefined && ProductTypeDesc!=null)?ProductTypeDesc.ProductTypeDescription:"";
    }

    componentWillMount() {
        if(this.props.confirmationDetails.Products.length>0)
        {
            this.props.confirmationDetails.Products.map((product, index) => {
                if(product.ProductId!=0)
                {
                    let _product={Id:product.ProductId,ProductDisplayName:product.DisplayName, Amount:("$" + ((product.IntegrationCode=="TM-ACH" || product.IntegrationCode=="DSL")?(((product.IntegrationCode=="TM-ACH")?(((product.TotalCreditExposureLimit!=undefined)?product.TotalCreditExposureLimit:0)+"/$"+((product.TotalDebitExposureLimit!=undefined)?product.TotalDebitExposureLimit:0)):(product.DailySettlementLimitAmt+"/"+product.ForeignExchangeRiskLimitAmt))):(product.RequestedAmount))),ProductDescription:this.getIntegrationCode(product.ProductType.IntegrationCode)};
                    displayProductList.push(_product);
                }
            });
        }

        if (this.props.confirmationDetails.Borrower.EntityStructure.StructureCode != "I") {
            borrowerName = this.props.confirmationDetails.Borrower.LegalEntityFullName;
        }
        else {
            borrowerName = this.props.confirmationDetails.Borrower.LegalName;
        }
    }

    render() {
        let horizontal = POSITION.HORIZONTAL;
        return (
            <div>
                <Header/>
                <div className="min-height">
                    {renderSection((CONFIRMATION_PAGE_CONSTANT.APP_SUBMITTED), "panel pad-t-20px", "pnl-sub-header-green width-22-per pad-4px font-size-14px bold mar-l-5px", "",
                        (
                            [<div>
                                  <div className={(this.state.downloading?"overlay-div":"")}> &nbsp;
                                    </div>
                                    {(this.state.downloading?renderSpinner():"")}
                                <fieldset className="brd-radius-3px mar-t-m-5px">
                                    <div className="col-lg-12 pad-0px mar-0px">
                                        <div
                                            className="row mar-l-5px mar-r-5px pnl-brd-darkgray brd-radius-10px pad-14px">
                                            <div className="row">
                                                <FormField columnSize="6" orientation={horizontal}
                                                           cssClass="clr-green bold font-size-12px mar-l-15px"
                                                           type="label"
                                                           value="The following requests have been submitted successfully"/>
                                            </div>
                                            <div className="row">
                                                <div className="col-lg-12">
                                                    <div className="col-lg-2">
                                                        <label className="normal clr-lbl font-size-12px">{CONFIRMATION_PAGE_CONSTANT.APPLICATION_ID}</label>
                                                    </div>
                                                    <div className="col-lg-10">
                                                        <label className="clr-black font-size-15px">{(((this.props.confirmationDetails.BLCCreditRequestId==0)?(""):(this.props.confirmationDetails.BLCCreditRequestId + " (BLC)")) + ((this.props.confirmationDetails.BLCCreditRequestId!=0 && this.props.confirmationDetails.BCCCreditRequestId!=0)?(", "):("")) + ((this.props.confirmationDetails.BCCCreditRequestId==0)?(""):(this.props.confirmationDetails.BCCCreditRequestId + " (BCC)")))}</label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="row">
                                                <div className="col-lg-12">
                                                    <div className="col-lg-2">
                                                        <label className="normal clr-lbl font-size-12px">{CONFIRMATION_PAGE_CONSTANT.BORROWER_NAME}</label>
                                                    </div>
                                                    <div className="col-lg-10">
                                                        <label className="clr-black font-size-15px">{borrowerName}</label>
                                                    </div>
                                                </div>
                                            </div>
                                              {(this.props.confirmationDetails.Guarantors.length>0)?(<div className="row"><div className="col-lg-12">
                                                <div className="col-lg-2"><label className="normal clr-lbl font-size-12px">Guarantor(s): </label></div>
                                                <div className="col-lg-10">
                                                {this.props.confirmationDetails.Guarantors.map((guarantor, index)=>{
                                                    if(guarantor.RelatedEntity.Id!=0)
                                                        return (<label className="clr-black font-size-15px">{((index>0)?(", "):(""))+guarantor.RelatedEntity.LegalName}</label>)
                                                })}
                                                </div></div></div>):(<div></div>)}
                                                
                                                {(this.props.confirmationDetails.Cardholders.length>0)?(<div className="row"><div className="col-lg-12">
                                                <div className="col-lg-2"><label className="normal clr-lbl font-size-12px">Cardholder(s): </label></div>
                                                <div className="col-lg-10">
                                                {this.props.confirmationDetails.Cardholders.map((cardholder, index)=>{
                                                    return (<label className="clr-black font-size-15px">{((index>0)?(", "):(""))+cardholder.FirstName+" "+ cardholder.MiddleName+" "+ cardholder.LastName}</label>)
                                                })}
                                                </div></div></div>):(<div></div>)}

                                                {(getDisclosureAfterSubmit(this.props.confirmationDetails.Products).length>0)?(<div className="row"><div className="col-lg-12">
                                                <div className="col-lg-2"><label className="normal clr-lbl font-size-12px">Print Application Disclosures: </label></div>
                                                <div className="col-lg-10">
                                                {getDisclosureAfterSubmit(this.props.confirmationDetails.Products).map((disclosure, index)=>{
                                                    let url;
                                                    if(disclosure.Type=="BLC")
                                                    {
                                                        url=getDisclosureUrl(disclosure.IntegrationCode);
                                                    }
                                                    else if(disclosure.Type=="BCC")
                                                    {
                                                        if(disclosure.IntegrationCode=="MASTERCARD")
                                                        {
                                                            if(disclosure.LoanType==3)
                                                                url = 'https://sharepoint.info53.com/divisions/50174/Shared%20Documents/Retail%20ILP/Small%20Business%20Lending%20Disclosures/Business%20Card%20Disclosures%20Print%20After%20Submit.docx';
                                                            else if(disclosure.LoanType==20)
                                                                url='https://sharepoint.info53.com/divisions/50174/Shared%20Documents/Retail%20ILP/Small%20Business%20Lending%20Disclosures/Bankcard%20Limit%20Increase.docx';
                                                        }
                                                        else if(disclosure.IntegrationCode=="MASTERCARD-TRAV")
                                                        {
                                                            if(disclosure.LoanType==3)
                                                                url = 'https://sharepoint.info53.com/divisions/50174/Shared%20Documents/Retail%20ILP/Small%20Business%20Lending%20Disclosures/Business%20Rewards%20Card%20Disclosures%20Print%20After%20Submit.docx';
                                                            else if(disclosure.LoanType==20)
                                                                url='https://sharepoint.info53.com/divisions/50174/Shared%20Documents/Retail%20ILP/Small%20Business%20Lending%20Disclosures/Bankcard%20Limit%20Increase.docx';
                                                        }
                                                    }
                                                    return(<div><a className="link cursor-pointer" onClick={this.onDisclosureLinkClick.bind(this, url)}>{_.find(this.props.Data.ProductTypeList, ['IntegrationCode', disclosure.IntegrationCode]).ProductTypeDescription}</a><br/></div>);
                                                })}
                                                </div></div></div>):(<div></div>)}

                                              <div className="row">
                                                  <div className="col-lg-12">
                                                    <div className="col-lg-2">
                                                        <label className="normal clr-lbl font-size-12px">{CONFIRMATION_PAGE_CONSTANT.PRODUCT_REQUESTS}</label>
                                                    </div>
                                                    <div className="col-lg-10">
                                                        <label className="clr-black font-size-15px">{renderGrid(displayProductList, headers, selectRowProp)}</label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="row">
                                                <label  className="clr-green bold font-size-12px mar-l-15px" >{CONFIRMATION_PAGE_CONSTANT.ACCOUNTDOCUMENT_DOWNLOAD}</label>
                                                <i className="mar-l-5px fa fa-lg fa-download clr-blue cursor-pointer" onClick={this._generateFinancialNeedsDocument.bind(this)} aria-hidden="true"></i>
                                            </div>
                                              <div className="row">
                                                <label  className="clr-green bold font-size-12px mar-l-15px" >{CONFIRMATION_PAGE_CONSTANT.SNAPSHOTANDDISCLOSURES_DOWNLOAD}</label>
                                                <i className="mar-l-5px fa fa-lg fa-download clr-blue cursor-pointer" onClick={this._generateSnapShotAndDisclosuresDocument.bind(this)} aria-hidden="true"></i>
                                            </div>
                                        </div>
                                    </div>
                                </fieldset>
                             </div>]
                        ))}

    <div className="col-lg-12 pad-t-0px pad-b-13px">
        <input type="button" className="btn btn-primary pull-right" value="Close"
               onClick={this._onClose.bind(this)}/>
        </div>
    </div>
    <Footer/>
</div>
);
    }
}

ConfirmationPage.PropTypes = {
    confirmationDetails: PropTypes.object.isRequired,
    Data: PropTypes.object.isRequired
}

export default ConfirmationPage;
