/* React libraries */
import React, { Component, PropTypes } from "react";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";

/* plugin libraries */
import _ from "lodash";

/* LoanApp libraries */
import {parseBool, showSuccess, showWarning, showError, getFormattedData, formatData} from "../utils/Functions";
import { isCollateralValid } from "../utils/Validation";
import {AddAddress } from "../utils/AddressFunctions";

/* Constant components */
import {GUARANTOR_CONSTANT, BORROWER_CONSTANT, COLLATERAL_CONSTANT, POSITION, LEGEND_CONSTANT,LEGALENITITY_COMMON_CONSTANT, SEARCH_CONSTANT, MESSAGE_CONSTANT, VALIDATION_CONSTANT} from "../constants/ApplicationConstants";
import {APPLICATION_URL} from "../constants/ApplicationURL";

/* Child components libraries */
import {renderAccordion, renderSection, renderSpinner, renderGrid} from "./form-components/Form";
import FormField from "./form-components/FormField";
import SearchCriteriaPage from "./child-components/search/SearchCriteriaPage";
import SearchGrid from "./child-components/search/SearchGrid";
import BusinessInformation from "./child-components/BusinessInformation";
import PhoneNumbers from "./child-components/PhoneNumbers";
import OtherInformation from "./child-components/OtherInformation";
import EditableAddress from "./EditableAddress";
import MultipleAddress from "./MultipleAddress";

/* Action components */
import {CreateCollateral, GetCollateralOwner, SaveCollateralOwner, SaveCollateral, CreateCollateralOwner, GetQualifiedProposedCollaterals, GetQualifiedProductLs, CreateNewCollateral} from "../actions/collateralAction";
import {GetCollateralCommonData, UpdateActionStatus} from  "../actions/commondataAction";
import {SearchLegalEntities} from "../actions/searchAction";
import {IsInValidPOBox} from "../actions/legalEntityAction";

/* variable declaration start */
let guarantor=[];
let _tempCollateral={};
let _legalEnitityId="add";
let isIndividual = false;
let entityStructureForCollateral=[];
let existingAddress = null;
let existingHomeAddress = null;
let existingBusinessAddress = null;
let entityAddress = null;
let errorCollection = {};
let headers=[{name:'Product ID', value:'Id'},{name:'Product', value:'ProductDisplayName'},{name:'Amount', value:'Amount'},{name:'Description', value:'ProductDescription'}];
/* variable declaration end */
const selectRowProp = {
    mode: 'checkbox',
    clickToSelect: true,
    bgColor: "rgba(216, 226, 248, 1)",
    selected:[]
};

class Collateral extends Component {
    constructor(props, context) {
        super(props, context);

        this.state={
            collateralInformationData: Object.assign({}, props.collateralinformation),
            searching:false,
            ajaxCallsInProgress:true,
            visibleComponent: 0,
            isContinueEnable:false,
            saving:false,
            showGuarantor:false,
            proposedCollaterList:[],
            productList: this.getQulaifiedProductList((props.collateralinformation!=undefined && props.collateralinformation!=null && props.collateralinformation.Type!=undefined)?(props.collateralinformation.Type.Id):(-1)),
            isCollateralEditClicked:false,
            isEntityEditClicked:false,
            saveRightCollateralAddress:false,
            collateralAddressNew: null,
            defaultAddressOption:"",
            isInternationalAddress: false,
            collateralAddressCount: 1,
            doValidate: false,
            doValidateOwner: false,
            doValidateAddress: false,
            savedStatus: Object.assign({}, props.savedStatus)
        };

        this.onFieldChange = this.onFieldChange.bind(this);
        this.onFieldBlur = this.onFieldBlur.bind(this);
        this.onKeyDown=this.onKeyDown.bind(this);
        this.onCollateralFieldBlur=this.onCollateralFieldBlur.bind(this);
        this.onCollateralFieldChange=this.onCollateralFieldChange.bind(this);
    }

    /* component lifecycle methods start */
    componentWillMount() {
        if(this.props.collateralCommonData==undefined && this.props.collateralCommonData==null)
        {
            this.getCollateralCommonData();
            let _collateral=getCollateralById(this.props.collateralList, this.props.params.id);
            if(_collateral==null)
            {
                this.setState({ajaxCallsInProgress:true});
                this.addNewCollateral();
            }
        }
        else
        {
            let _collateral=getCollateralById(this.props.collateralList, this.props.params.id);
            let lstIntegrationCode=this.getIntegrationCode();
            this.getProposedCollateralList(lstIntegrationCode);
            if(_collateral==null)
            {
                this.setState({ajaxCallsInProgress:true});
                this.addNewCollateral();
            }
            else
            {
                this.setState({collateralInformationData: _collateral});
                this.setState({ajaxCallsInProgress: false});
            }
        }
        _.set(selectRowProp, 'selected', this.state.collateralInformationData.ProductIds);
    }

    componentWillReceiveProps(nextProps)
    {
        if(this.props.params.id!=nextProps.params.id && nextProps.params.id==this.props.collateralList.length)
        {
            let _collateral=getCollateralById(this.props.collateralList, nextProps.params.id);
            if(_collateral==null)
            {
                this.setState({ajaxCallsInProgress:true});
                this.addNewCollateral();
            }
            else
            {
                this.setState({collateralInformationData: _collateral});
                this.setState({ajaxCallsInProgress: false});
            }
        }
        if(this.props.collateralinformation!=null && nextProps.collateralinformation!=null && this.props.collateralinformation!=nextProps.collateralinformation)
        {
            this.setState({collateralInformationData: nextProps.collateralinformation});
        }
    }
    /* component lifecycle methods end */
    

    /* component event methods start */
    onFieldChange(e){
        this.updateCollateral(e, false);
        if(this.refs.table!=undefined){
            
            this.state.collateralInformationData.ProductIds = this.refs.table.state.selectedRowKeys;
            this.setState({
                collateralInformationData  : Object.assign({}, _.assign(this.state.collateralInformationData,{
                    ProductIds: this.refs.table.state.selectedRowKeys
                }))
            });
            _.set(selectRowProp, 'selected', this.state.collateralInformationData.ProductIds);
        }
    }

        onFieldBlur(e){
            if(e.target.name=="Line1")
            {
                this.props.actions.IsInValidPOBox(e.target.value).then((data)=>{
                    if(data)
                        showError(MESSAGE_CONSTANT.POSTBOX_ERROR_MESSAGE);
                }).catch(error=>{console.log(error.response.data.ExceptionMessage);});
            }
            else
                this.updateCollateral(e, false);
        }

        onCollateralFieldBlur(e){
            this.updateCollateral(e, true);
        }

        onCollateralFieldChange(e){
            this.updateCollateral(e, true);
        }

        onKeyDown(e){
            if(e.keyCode==13)
                this.onSearchButtonClick();
        }
    /* component event methods end */

    getCollateralCommonData(){
        this.props.actions.GetCollateralCommonData().then(()=>{
            let lstIntegrationCode=this.getIntegrationCode();
            this.getProposedCollateralList(lstIntegrationCode);
            this.setState({ajaxCallsInProgress:false});
        }).catch(error=>{console.log(error.response.data.ExceptionMessage);});
    }

    getProposedCollateralList(integrationCode){
        this.props.actions.GetQualifiedProposedCollaterals(integrationCode).then((data)=>{
            if(this.props.collateralCommonData.ProposedCollateralList.length>0)
            {
                let _proposedCollateralList=_.intersectionBy(this.props.collateralCommonData.ProposedCollateralList, data, 'Id');
                this.setState({proposedCollaterList: Object.assign([], _proposedCollateralList)});
            }
            this.setState({ajaxCallsInProgress:false});
        }).catch(error=>{
            console.log(error.response.data.ExceptionMessage);
        });
    }

    addNewCollateral(){
        this.props.actions.CreateNewCollateral(-1, this.props.userId).then(() => {
            this.setState({collateralInformationData: Object.assign({}, this.props.collateralinformation)});
            this.setState({ajaxCallsInProgress:false});
        }).catch(error => {
            console.log(error.response.data.ExceptionMessage);
        });
    }

    getIntegrationCode()
    {
        let  lstIntegrationCode=[];
        if(this.props.productsList!=undefined && this.props.productsList.length>0)
        {
            this.props.productsList.map((product, index)=>{
                if(product.ProductId!=0){
                    lstIntegrationCode[index]=product.ProductType.IntegrationCode;
                }
            });
            return lstIntegrationCode;
        }
    }

    getIntegrationCodeByType(productType){
        let ProductTypeDesc = _.find(this.props.productTypeList, ["IntegrationCode", productType]);
        return (ProductTypeDesc!=null)?ProductTypeDesc.ProductTypeDescription:"";
    }

    
    // Below code to be re-visit once we do the change in borrower savedaddressType implementation.
    updateCollateralOwnerDetails(collateralOwnerDetails, ownerOfCollateral){
        if(collateralOwnerDetails)
        {
            this.setState({
                collateralInformationData  : Object.assign({}, _.assign(this.state.collateralInformationData,{
                    Owner: collateralOwnerDetails,
                    OwnerOfCollateral:ownerOfCollateral
                }))
            });
            if(ownerOfCollateral == 0){
                if(collateralOwnerDetails.IsIndividual){
                    existingHomeAddress = _.find(collateralOwnerDetails.Addresses, {'AddressTypeId':(collateralOwnerDetails.isNewHomeAddressSelected)?'T':'E'})
                }
                existingBusinessAddress = _.find(collateralOwnerDetails.Addresses, {'AddressTypeId': collateralOwnerDetails.IsIndividual?(collateralOwnerDetails.isNewBusinessAddressSelected?'S':'B'):(collateralOwnerDetails.isNewBusinessAddressSelected?'T':'E')});
            }
        }
    }

    onGuarantorSelect(e){
        let fieldValue=e.target.value;
        if(this.props.guarantorDetails)
        {
            let _tempGuarantor=this.props.guarantorDetails[fieldValue].RelatedEntity;
            this.updateCollateralOwnerDetails(_tempGuarantor, 1);
            this.setState({showGuarantor:true});
        }
    }

    updateOwnerOfCollateral(fielValue)
    {
        if(fielValue==0)///Borrower
        {
            this.updateCollateralOwnerDetails(this.props.borrowerDetails, 0);
        }
        else if(fielValue==1)/// Guarantor
        {
            guarantor=[];
            this.props.guarantorDetails.map((option, index) => {
                if(option.RelatedEntity.Id!=0 && option.RelatedEntity.IsNew==false)
                {
                    guarantor.push({"Key": index, "Value": ("Guarantor" + (index+1))});
                }
            });
        }
        else if(fielValue==2)/// Third Party Pledger
        {
            this.setState({visibleComponent:2});
            this.setState({collateralInformationData  : Object.assign({}, _.assign(this.state.collateralInformationData,{
                OwnerOfCollateral:2
                }))
            });
        }
        this.setState({
            collateralAddressNew: null,
            collateralAddressCount:1,
            saveRightCollateralAddress: false
        });
    }

    updateCollateral(e, isCollateralOwner)
    {
        const fieldName = e.target.name;
        let fielValue=getFormattedData(e);

        if(fieldName=="OwnerOfCollateral")
        {
            this.updateOwnerOfCollateral(fielValue);
        }

        let collateralDetails ={};
        if(isCollateralOwner){
            collateralDetails = this.state.collateralInformationData.Owner;
            _.set(collateralDetails, fieldName, fielValue);
            this.setState({
                collateralInformationData  : Object.assign({}, _.assign(this.state.collateralInformationData,{
                    Owner: collateralDetails,
                    OwnerOfCollateral:2
                }))
            });
        }
        else{
            collateralDetails = this.state.collateralInformationData;
            
            _.set(collateralDetails, fieldName, fielValue);
            this.setState({collateralInformationData: collateralDetails});
        }

        if(fieldName=="Type.Id" && fielValue !="-1")
        {
            this.props.actions.CreateCollateral(fielValue, this.props.userId, this.props.params.id, this.props.collateralinformation).then(() => {
                ///this.setState({collateralInformationData: Object.assign({}, data)});
                this.setState({collateralInformationData: Object.assign({}, this.props.collateralinformation)});
                this.setState({ajaxCallsInProgress:false});
            }).catch(error => {
                console.log(error.response.data.ExceptionMessage);
            });
            this.getQulaifiedProductList(fielValue);
        }
    }

    getQulaifiedProductList(fielValue)
    {
        this.props.actions.GetQualifiedProductLs(fielValue).then((data)=>{
            let _productList =   _.filter(this.props.productsList, function(o){
                return _.includes(data, o.IntegrationCode);
            });
            let displayProductList=[];
            _productList.map((product, index) => {
                if(product.ProductId!=0)
                {
                    let _product={Id:product.ProductId,ProductDisplayName:product.DisplayName, Amount:("$" + ((product.IntegrationCode=="TM-ACH" || product.IntegrationCode=="DSL")?(((product.IntegrationCode=="TM-ACH")?(((product.TotalCreditExposureLimit!=undefined)?product.TotalCreditExposureLimit:0)+"/$"+((product.TotalDebitExposureLimit!=undefined)?product.TotalDebitExposureLimit:0)):(product.DailySettlementLimitAmt+"/"+product.ForeignExchangeRiskLimitAmt))):(product.RequestedAmount))),ProductDescription:this.getIntegrationCodeByType(product.ProductType.IntegrationCode)};
                    displayProductList.push(_product);
                }
            });
            this.setState({productList:displayProductList, ajaxCallsInProgress:false});
        }).catch(error=>{console.log(error.response.data.ExceptionMessage);});
    }

   

    _onCollateralOwnerDone(e) {
            e.preventDefault();
            errorCollection = {};
            this.setState({doValidateOwner: true});
        }
    componentDidUpdate(prevProps, prevState){
        if(prevState.doValidateAddress != this.state.doValidateAddress){
            this.state.doValidateAddress = false;
            if(_.size(errorCollection)>0)
            {
                this.setState({saving: false});
                showError(VALIDATION_CONSTANT.COLLATERAL_OWNER_ERROR_MESSAGE);
            }
            else
            {
                if(this.state.isCollateralEditClicked){
                    this.UpdateAddress();
                }
            }
        }
        if(prevState.doValidateOwner != this.state.doValidateOwner)
        {
            this.state.doValidateOwner = false;
            if(_.size(errorCollection)>0)
            {
                this.setState({saving: false});
                showError(VALIDATION_CONSTANT.COLLATERAL_OWNER_ERROR_MESSAGE);
            }
            else
            {
                this.saveCollateralOwner();
            }
        }
        if(prevState.doValidate != this.state.doValidate)
        {
            this.state.doValidate = false;
            if(_.size(errorCollection)>0)
            {
                this.setState({saving: false});
                showError(VALIDATION_CONSTANT.COLLATERAL_ERROR_MESSAGE);
            }
            else
            {
                this.saveCollateral();
            }
        }
    }
    saveCollateralOwner(){
        this.setState({saving: true});
        let formData=$("#customerForm :input").not('#CollateralAddress_Editable').serializeArray();
        let addressData=$("#CollateralAddress_Editable :input").serializeArray();
        let _updatedOwner = this.state.collateralInformationData.Owner;
        let _newOwnerAddress = {};
            
        {formData && formData.map((data, index) => {
            data.value = formatData(data.value);
            _.set(_updatedOwner, data.name, data.value);
        })}
        {addressData && addressData.map((data, index) => {
            data.value=formatData(data.value);
            _.set(_newOwnerAddress, data.name, data.value);
        })}
        _.set(_newOwnerAddress,"AddressTypeId" , "E");
        if(!this.state.isInternationalAddress){
            _.set(_newOwnerAddress,"CountryId" , "223");
        }
        _.set(_updatedOwner, "Addresses[0]", _newOwnerAddress);
        this.state.collateralInformationData.Owner=_updatedOwner;
        this.props.actions.SaveCollateralOwner(this.state.collateralInformationData.Owner, this.props.params.id)
            .then(() => {
                this.setState({visibleComponent:1, saving: false});
            }).catch(error => {
                console.log(error.response.data.ExceptionMessage);
                this.setState({saving: false});
            });
    }

    getProductTypeCategory(integrationCode)
    {
        if(this.props.productTypeList.length>0)
            return _.find(this.props.productTypeList, ['IntegrationCode', integrationCode]);
    }

    saveAddress(collateralInformation){
        //Save updated Third Party Address
        if(this.state.saveRightCollateralAddress && this.state.collateralAddressNew ){
            let _updatedAddress = collateralInformation.Owner;
            let _addressTypeId = "T";
            AddAddress(_updatedAddress.Addresses, this.state.collateralAddressNew, _addressTypeId);
            _.set(_updatedAddress, "PrimaryAddress", this.state.saveRightCollateralAddress);
            if(_updatedAddress.IsInternational == false)
                _.set(_updatedAddress,"CountryId" , 223);
        }
        
        //Save Address for RealEstate type of Products 
        if(this.state.collateralInformationData.Type && this.state.collateralInformationData.Type.Id == 147){
            let addressData=$("#CollateralEntityAddress_Editable :input").serializeArray();
            {addressData && addressData.map((data, index) => {
                data.value=formatData(data.value);
                _.set(collateralInformation.EntityAddress, data.name, data.value);
            })}
            collateralInformation.EntityAddress.AddressTypeId ="E";
        }
    }
    saveCollateral(){
        this.setState({saving: true});

        if(this.state.collateralInformationData.Type.Id=="3")
        {
            this.updateCollateralOwnerDetails(this.props.borrowerDetails,0);
        }

        let collateralInformation=this.state.collateralInformationData;
        let productListSection=[];

        if(this.refs.table!=undefined)
        {
            productListSection =  this.refs.table.state.selectedRowKeys;
        }

        if(this.state.productList!=undefined && this.state.productList.length==1 && productListSection.length==0)
        {
            collateralInformation.ProductIds[0]=this.state.productList[0].Id;
        }
        else if(productListSection.length>0)
        {
            collateralInformation.ProductIds=productListSection;
        }
        else
        {
            collateralInformation.ProductIds=[];
        }

        if(collateralInformation.ProductIds.length>0)
        {
            if(this.state.collateralInformationData.OwnerOfCollateral==-1)
            {
                showError(MESSAGE_CONSTANT.COLLATERAL_OWNER_ERRROR_MESSAGE);
            }
            else
            {
                this.saveAddress(collateralInformation);
                collateralInformation.ProductIds= _.uniq(collateralInformation.ProductIds);
                
                this.props.actions.SaveCollateral(this.props.productsList, collateralInformation, this.props.params.id).then(() => {
                    if(this.state.savedStatus.Collateral == undefined)
                    {
                        let newStatus = this.state.savedStatus;
                        _.set(newStatus, "Collateral", true);
                        this.props.actions.UpdateActionStatus(newStatus);
                    }
                    showSuccess(MESSAGE_CONSTANT.COLLATERAL_REQUEST_SAVE_SUCCESS);
                    showWarning(MESSAGE_CONSTANT.COLLATERAL_REQUEST_ADD_LINK);
                    this.setState({
                        saving: false,
                        collateralAddressNew:null,
                        collateralAddressCount:1,
                        isEntityEditClicked:true,
                        collateralInformationData: this.props.collateralinformation
                    });
                }).catch(error => {
                    this.setState({saving: false});
                    console.log(error.response.data.ExceptionMessage);
                });
            }
        }
        else
        {
            showError(MESSAGE_CONSTANT.COLLATERAL_PRODUCT_ERRROR_MESSAGE);
        }
    }
    onNextButtonClick(e) {
        e.preventDefault();
        errorCollection = {};
        this.setState({doValidate: true});
    }

    _renderComponent()
    {
        switch (this.state.visibleComponent)
        {
            case 1: return (<div>{this._renderCollateral()}</div>);
            case 2: return (<div>{this._renderSearch()}</div>);
            case 3: return (<div>{this._renderGrid()}</div>);
            case 4: return (<div>{this._renderAddNewCollateral()}</div>);
            default: return (<div>{this._renderCollateral()}</div>);
        }
    }

    _resetSearchCriteria(){
        document.getElementById("TINSSN").value="";
        document.getElementById("CUSTOMER_NAME").value="";
    }

    _renderSearchCriteria(){
        this.setState({visibleComponent:2});
    }

    onRowSelect(row, isSelected){
        if(isSelected)
        {
            _legalEnitityId= row.LegalEntityId;
            this.setState({isContinueEnable: true});
        }
        else
        {
            _legalEnitityId="add";
            this.setState({isContinueEnable: false});
        }
    }

    _getLEInfo()
    {
        if(_legalEnitityId>0)
        {
            this.props.actions.GetCollateralOwner(_legalEnitityId, this.props.params.id).then(() => {
                this.updateCollateralOwnerDetails(this.props.collateralinformation.Owner, 2);
                this.setState({visibleComponent:1});
            }).catch(error => {
                console.log(error.response.data.ExceptionMessage);
            });
        }
    }

    _renderAddNewCustomer(){
        this.props.actions.CreateCollateralOwner(this.props.params.id).then(() => {
            this.updateCollateralOwnerDetails(this.props.collateralinformation.Owner, 2);
            this.setState({visibleComponent:4});
        }).catch(error => {
            console.log(error.response.data.ExceptionMessage);
        });
    }

    renderSearchGrid(){
        this.setState({searching: false});
        this.setState({visibleComponent:3});
    }

    _onDone(e){
        e.preventDefault();
        let isValid = "";
        isValid = this.validateCollateralForm(this.state.collateralInformationData);
        if (isValid) {
            this.validateData();
            this.setState({saving: true});
        }
        else {
            showError("error");
            this.setState({saving: false});
        }
    }
    hasError(error, e, isOnBlur){
        let fieldName=e.name;
        if(e.id != undefined && e.id != null){
            fieldName=e.id;
        }
        if(error[fieldName])
            _.set(errorCollection, fieldName, error[fieldName]);
        else
            _.unset(errorCollection, fieldName);
    }

    validateCollateralForm(data)
    {
        let _formIsValid = true;
        let _errors = isCollateralValid(this.refs.collateralForm["Type.Id"], this.refs.collateralForm["SubType.Id"]);
        /*Check any error is available in page*/
        if((Object.keys(_errors).length > 0))
            _formIsValid = false;
        else
            _formIsValid = true;

        return _formIsValid;
    }

    onSearchButtonClick(){
        this.setState({searching: true});
        let tinNo= document.getElementById("TINSSN").value;
        let customerName= document.getElementById("CUSTOMER_NAME").value;

            this.props.actions.SearchLegalEntities(tinNo, customerName, this.props.borrowerDetails.Id)
                .then(() => {this.renderSearchGrid();})
                .catch(error => {
                    this.setState({searching: false});
                    console.log(error.response.data.ExceptionMessage);
                });
        }
   
        onEditClick(e){
            if(e.target.name=="CollateralAddress_Edit"){
                this.setState({isCollateralEditClicked:true})
                if(this.state.collateralAddressNew == null){
                    this.setState({collateralAddressNew: existingAddress});
                }
                this.setState({isInternationalAddress:existingAddress.IsInternational})
            }
            if(e.target.name=="Entity_Edit")
                this.setState({isEntityEditClicked:true});
        }
   
        onCancelClick(e){
            if(this.state.collateralAddressCount == 1){
                this.setState({collateralAddressNew: null});
            }
            this.setState({isCollateralEditClicked:false});
        }

        onClearClick(e){
            if(e.target.name == "CollateralAddress_Clear"){
            }
        }

    onAddressTypeClick(_isInternational){
        this.state.collateralAddressNew.IsInternational = _isInternational;
    }

    UpdateAddress(){
        // below code will make a generic method later
        this.setState({isCollateralEditClicked:false});
        let formData=$("#CollateralAddress_Editable :input").serializeArray();
        let _tempCollateralAddress = Object.assign({}, this.state.collateralAddressNew);
        {formData && formData.map((data, index) => {
            _.set(_tempCollateralAddress, data.name, data.value);
        })}
        _tempCollateralAddress.AddressTypeId = (isIndividual? "T":"S");
        this.state.collateralAddressNew = Object.assign({}, _tempCollateralAddress);
        this.setState({
            saveRightCollateralAddress: true,
            defaultAddressOption:2,
            collateralAddressCount:2
        });
    }
    onUpdateClick(e){
        e.preventDefault();
        errorCollection = {};
        this.setState({doValidateAddress: true});
    }

    onMismatchClick(name, value) {
        if (name == "OwnerAddressIndividual_true" || name=="OwnerAddressIndividual_false")
            this.state.saveRightCollateralAddress = value == "2"? true: false;
    }

    _renderAddNewCollateral(){
        let vertical=POSITION.VERTICAL;
        let horizontal=POSITION.HORIZONTAL;
        isIndividual = (this.state.collateralInformationData.Owner && this.state.collateralInformationData.Owner.EntityStructure && this.state.collateralInformationData.Owner.EntityStructure.StructureCode!=null && this.state.collateralInformationData.Owner.EntityStructure.StructureCode !== "I") ? false : true;
        return(
            <div>
                {renderSection(('Collateral '+ ((parseInt(this.props.params.id)) + 1)),'panel','pnl-sub-header-green width-30-per pad-4px font-size-14px bold mar-l-5px','',
                    ([<div>
                        <form method="post" action="" key="customerForm" name="customerForm" id="customerForm" ref="customerForm" >
                                <div className={(this.state.saving?"overlay-div":"")}> &nbsp;
                                        </div>
                                        {(this.state.saving?renderSpinner():"")}
                            <fieldset className="brd-radius-3px mar-t-m-5px">
                                <div className="col-lg-12 pad-0px mar-0px">
                                    <div className="mar-l-5px mar-r-5px pnl-brd-darkgray brd-radius-10px pad-14px pad-b-0px pad-t-0px bg-clr-white">
                                        <FormField type="legend" displayText={LEGEND_CONSTANT.REQUIRED_FIELD} />
                                        <div className="pad-b-5px pad-l-5px pad-r-5px  font-size-11px">
                                            {/*Type Of Guarantor onClick={this._onDone.bind(this)} */}
                                            <div className="row mar-l-5px mar-r-5px pad-14px pad-b-0px pad-t-0px">
                                                <div className="pad-b-0px pad-t-0px">
                                                    <FormField columnSize={4} orientation={horizontal} key="EntityStructure.StructureCode" name="EntityStructure.StructureCode" type="radio" displayText={LEGALENITITY_COMMON_CONSTANT.TYPE_OF_CUSTOMER}  defaultOption={(((this.state.collateralInformationData.Owner.EntityStructure.StructureCode!=null)?((this.state.collateralInformationData.Owner.EntityStructure.StructureCode.trim()!="I")?("C"):("I")):("")))} displayValue={[{"Key":"I","Value":"Individual"},{"Key":"C","Value":"Corporate"}]} onFieldChange={this.onCollateralFieldChange} />
                                                </div>
                                            </div>
                                                    {((this.state.collateralInformationData.Owner && this.state.collateralInformationData.Owner.EntityStructure && this.state.collateralInformationData.Owner.EntityStructure.StructureCode!=null)?(<div>
                                                        <div><BusinessInformation isIndividual={isIndividual} customerLabel="Owner" entityStructure={entityStructureForCollateral} initialData={this.props.collateralinformation.Owner} isBorrower={false} isEditable={true} data={this.state.collateralInformationData.Owner} onFieldBlur={this.onCollateralFieldBlur} onFieldChange={this.onCollateralFieldChange} hasError={this.hasError} doValidate={this.state.doValidateOwner} /></div>
                                                        <div>
                                                        {/*Third Party Address Add New Customer*/}
                                                        {(renderAccordion('fa fa-address-card', (isIndividual ? LEGALENITITY_COMMON_CONSTANT.HOME_ADDRESS : LEGALENITITY_COMMON_CONSTANT.BUSINESS_ADDRESS),"panel accordion-brd-color font-size-12px", "accordion-panel pad-4px bold", "","",
                                                            <div>
                                                                <EditableAddress addressType="InputAddressType" disabled={false}  name={"InputAddress"} type={"CollateralAddress"} 
                                                                    commonData={this.props.legalEntitycommondata} onAddressTypeClick={this.onAddressTypeClick.bind(this)} 
                                                                    onFieldBlur={this.onFieldBlur.bind(this)} isCollateralAddress={true}
                                                                    isInternational={this.state.isInternationalAddress} hasError={this.hasError} doValidate={this.state.doValidateOwner}/>
                                                            </div>
                                                         ))}
                                                        </div>
                                                        <div><PhoneNumbers initialData={this.props.collateralinformation.Owner} data={this.state.collateralInformationData.Owner} onFieldBlur={this.onCollateralFieldBlur} hasError={this.hasError} doValidate={this.state.doValidateOwner} /></div>
                                                        <div><OtherInformation isIndividual={isIndividual} isBorrower={false} initialData={this.props.collateralinformation.Owner} 
                                                              paramId={_legalEnitityId} data={this.state.collateralInformationData.Owner} onFieldBlur={this.onCollateralFieldBlur}  customerLabel="Owner"
                                                                onFieldChange={this.onCollateralFieldChange}  statesList={this.props.legalEntitycommondata.States} hasError={this.hasError} doValidate={this.state.doValidateOwner}/>
                                                        </div>
                                                        <div className="pull-right pull-left-sm pad-r-5px mar-r-5px btn-primary bg-btn-clr-navy text-center-xs ">
                           		                            <span className=" fa fa-lg fa-floppy-o" aria-hidden="true"></span>
                                                            <input type="button" className="bg-clr-transparent br-none wid-55px pad-l-7px" value="Save" onClick={this._onCollateralOwnerDone.bind(this)} disabled={this.state.saving}  />
                                                        </div>

                                                     </div>):(<div></div>))}
                                        </div>

                                    </div>
                                </div>
                            </fieldset>
                           
                        </form>
                    </div>]))}
            </div>);
    }


    _renderGrid(){
        return(
            <div>
                <SearchGrid searchcustomerPageHeaderText={SEARCH_CONSTANT.CUSTOMER_SEARCH}
                            displayValue={this.props.searchresults}
                            addNewButtonDisplayText="Third Party Pledger" isHover={true} isSort={((this.props.searchresults == 0) ? (false) : (true))}
                            isSearch={false} selectType="radio" 
                            showErrorMessage={true}  searchAgain={true}
                            onSearchAgainClick={this._renderSearchCriteria.bind(this)}
                            onRowSelect={this.onRowSelect.bind(this)}
                            isContinueDisable={(!this.state.isContinueEnable)}
                            onContinueButtonClick={this._getLEInfo.bind(this)}
                            onAddButtonClick={this._renderAddNewCustomer.bind(this)}
                />
            </div>
        );
            }

            _renderCollateral(){
            let vertical=POSITION.VERTICAL;
            let horizontal=POSITION.HORIZONTAL;
            isIndividual = (this.state.collateralInformationData.Owner && this.state.collateralInformationData.Owner.EntityStructure && this.state.collateralInformationData.Owner.EntityStructure.StructureCode!=null && this.state.collateralInformationData.Owner.EntityStructure.StructureCode !== "I") ? false : true;
            if(this.state.collateralInformationData && this.state.collateralInformationData.EntityAddress && this.state.collateralInformationData.EntityAddress.AddressTypeId){
                entityAddress =(this.state.collateralInformationData.EntityAddress.AddressTypeId=="E")?this.state.collateralInformationData.EntityAddress:null;
            }if(this.state.collateralInformationData.Owner && this.state.collateralInformationData.Owner.Addresses){
                existingAddress = _.find(this.state.collateralInformationData.Owner.Addresses, {'AddressTypeId': (this.state.collateralInformationData.Owner.PrimaryAddress)? 'T':"E" });
            }
            
        return(
            <div>{renderSection(('Collateral '+ ((parseInt(this.props.params.id)) + 1)),'panel','pnl-sub-header-green width-30-per pad-4px font-size-14px bold mar-l-5px','',
                ([<div>
                    <form method="post" action="" key="collateralForm" name="collateralForm" id="collateralForm" ref="collateralForm">
                        <div className={(this.state.saving?"overlay-div":"")}> &nbsp;
                            </div>
                            {(this.state.saving?renderSpinner():"")}
                        <fieldset className="brd-radius-3px mar-t-m-5px">
                            <div className="col-lg-12 pad-0px mar-0px">
                                <div className="mar-l-5px mar-r-5px pnl-brd-darkgray brd-radius-10px pad-14px bg-clr-white">
                                        <FormField type="legend" displayText={LEGEND_CONSTANT.REQUIRED_FIELD} />
                                    {/*Proposed collateral information section*/}
                                        {renderAccordion('fa fa-newspaper-o', (COLLATERAL_CONSTANT.PROPOSED_COLLATERAL_INFORMATION), 'panel accordion-brd-color font-size-12px', 'accordion-panel pad-4px bold', '', '',
                                        <div>
                                            <div className="row">
                                                <FormField columnSize={4} orientation={vertical} key="Id" name="Type.Id"
                                                           displayText={COLLATERAL_CONSTANT.PROPOSED_COLLATERAL}
                                                           type="select-single" dataTextField="Description" dataValueField="Id"
                                                           displayValue={this.state.proposedCollaterList}  defaultSelectValue={(this.state.collateralInformationData.Type!=undefined && this.state.collateralInformationData.Type.Id!=-1)?(this.state.collateralInformationData.Type.Id):(-1)}
                                                           onFieldChange={this.onFieldChange} />
                                                {((this.state.collateralInformationData.Type && this.state.collateralInformationData.Type.Id=="LQ")?
                                                (<FormField columnSize={4} orientation={vertical} name="SubType.Id"
                                                           displayText={COLLATERAL_CONSTANT.COLLATERAL_SUBTYPE} type="select-single"
                                                           dataTextField="Description" dataValueField="Id"
                                                           displayValue={this.props.collateralCommonData.CollateralSubTypesList}
                                                           onFieldChange={this.onFieldChange} />
                                                ):(<div></div>))}
                                            </div>


                                            {((this.state.collateralInformationData.Type && this.state.collateralInformationData.Type.Id!=="3")?(<div>
                                                {((this.state.collateralInformationData.Type && this.state.collateralInformationData.Type.Id==217)?(<div>
                                                    <div className="row">
                                                        <FormField columnSize={4} orientation={vertical}  key="EquipmentType" name="EquipmentType" type="text" displayText={COLLATERAL_CONSTANT.EQUIPMENT_TYPE} displayValue={this.state.collateralInformationData.EquipmentType} onFieldBlur={this.onFieldBlur} />
                                                        <FormField columnSize={4} orientation={vertical} key="VinSerialOrModelNumber"  name="VinSerialOrModelNumber" type="text" displayText={COLLATERAL_CONSTANT.VIN_MODEL_NUMBER} displayValue={this.state.collateralInformationData.VinSerialOrModelNumber} onFieldBlur={this.onFieldBlur} />
                                                    </div>
                                                    <div className="row">
                                                        <FormField columnSize={4} orientation={horizontal} name="Condition" type="radio" defaultOption={this.state.collateralInformationData.Condition} displayText={COLLATERAL_CONSTANT.EQUIPEMENT_CONDITION} displayValue={[{"Key":0,"Value":"New"},{"Key":1,"Value":"Used"}]}  onFieldChange={this.onFieldChange} />
                                                    </div>

                                                        {((this.state.collateralInformationData.Condition==0)?(<div className="row"><FormField columnSize={4} orientation={vertical} key="PurchasePrice"  name="PurchasePrice" type="text" displayText={COLLATERAL_CONSTANT.EQUIPMENT_PURCHASE_PRICE} displayValue={this.state.collateralInformationData.PurchasePrice} onFieldBlur={this.onFieldBlur} /> </div>):(<div></div>))}
                                                </div>):(<div></div>))}

                                                {((this.state.collateralInformationData.Type && this.state.collateralInformationData.Type.Id==166)?(<div>
                                                    <div className="row">
                                                        <FormField columnSize={4} orientation={horizontal} key="Condition" name="Condition" type="radio" defaultOption={this.state.collateralInformationData.Condition} displayText={COLLATERAL_CONSTANT.VEHICLE_CONDITION}  displayValue={[{"Key":0,"Value":"New"},{"Key":1,"Value":"Used"}]}  onFieldChange={this.onFieldChange} />
                                                    </div>

                                                    <div className="row">
                                                        {((this.state.collateralInformationData.VehicleCondition==0)?(<FormField columnSize={4} orientation={vertical} key="VehiclePurchasePrice" faClass="fa-usd label-color font-size-14px bold" name="VehiclePurchasePrice" type="currency" displayText={COLLATERAL_CONSTANT.VEHICLE_PURCHASE_PRICE} displayValue={this.state.collateralInformationData.VehiclePurchasePrice} onFieldBlur={this.onFieldBlur} />  ):(<div></div>))}
                                                        <FormField columnSize={4} orientation={vertical} key="Make"  name="Make" type="text" displayText={COLLATERAL_CONSTANT.VEHICLE_MAKE} displayValue={this.state.collateralInformationData.Make} onFieldBlur={this.onFieldBlur} />
                                                        <FormField columnSize={4} orientation={vertical} key="Model" name="Model" type="text" displayText={COLLATERAL_CONSTANT.VEHICLE_MODEL} displayValue={this.state.collateralInformationData.Model} onFieldBlur={this.onFieldBlur} />
                                                        <FormField columnSize={4} orientation={vertical} key="VIN" name="VIN" type="text" displayText={COLLATERAL_CONSTANT.VEHICLE_VIN} displayValue={this.state.collateralInformationData.VIN} onFieldBlur={this.onFieldBlur} />
                                                        <FormField columnSize={4} orientation={vertical} key="Year"  name="Year" type="text" displayText={COLLATERAL_CONSTANT.VEHICLE_YEAR} displayValue={this.state.collateralInformationData.Year} onFieldBlur={this.onFieldBlur} />
                                                    </div>
                                                </div>):(<div></div>))}


                                                   {((this.state.collateralInformationData.Type && this.state.collateralInformationData.Type.Id==147)?(<div>
                                                    <div className="row">
                                                        <FormField columnSize={4} orientation={vertical} key="PurchasePrice"  name="PurchasePrice" faClass="fa-usd label-color font-size-14px bold" type="currency" displayText={COLLATERAL_CONSTANT.REAL_ESTATE} displayValue={this.state.collateralInformationData.PurchasePrice} onFieldBlur={this.onFieldBlur} />
                                                        <FormField columnSize={8} orientation={vertical} key="IsResidence" name="IsResidence" type="radio" displayText={COLLATERAL_CONSTANT.REAL_ESTATE_FAMILY_RESIDENCE} defaultOption={this.state.collateralInformationData.IsResidence} onFieldChange={this.onFieldChange} />
                                                    </div></div>):(<div></div>))}

                                                        {((this.state.collateralInformationData.Type && this.state.collateralInformationData.Type.Id=="LQ")?(<div><div className="row">
                                                    <FormField columnSize={4} orientation={vertical}  name="BankOrInstitution" type="text" displayText={COLLATERAL_CONSTANT.BANK_INSTITUTION} displayValue={this.state.collateralInformationData.BankOrInstitution} onFieldBlur={this.onFieldBlur} />
                                                    <FormField columnSize={4} orientation={vertical}  name="AccountPolicyNumber" type="text" displayText={COLLATERAL_CONSTANT.ACCOUNT_POLICY} displayValue={this.state.collateralInformationData.AccountPolicyNumber} onFieldBlur={this.onFieldBlur} />
                                                        </div></div>):(<div></div>))}
                                                    </div>):(<div></div>))}
                                        </div>
                                    )}

                                            {/*Product List Section*/}
                                            <div>
                                            {((this.state.collateralInformationData.Type && this.state.collateralInformationData.Type.Id!==-1 && this.state.productList!=undefined && this.state.productList.length>1)?(
                                            <div>
                                                {renderAccordion('fa fa-suitcase', (<span className="font-size-11px">{COLLATERAL_CONSTANT.APPILICABLE_PRODUCT_SECURED}</span>), 'panel accordion-brd-color font-size-12px', 'accordion-panel pad-4px bold', '', '',
                                                (<div className="mar-b-40px">
                                                   {renderGrid(this.state.productList, headers, selectRowProp)}
                                                       
                                                 </div>))}
                                                </div>):(<div></div>))}

                                       </div>

                                            {/* Entity Address Starts*/}
                                             {(this.state.collateralInformationData.Type && this.state.collateralInformationData.Type!=undefined && this.state.collateralInformationData.Type.Id == 147) ?
                                           (renderAccordion('fa fa-address-card', (COLLATERAL_CONSTANT.COLLATERAL_ADDRESS),"panel accordion-brd-color font-size-12px", "accordion-panel pad-4px bold", "","",
                                                 <div>
                                                    <EditableAddress addressType={(entityAddress!=null && entityAddress != undefined)?"EditableAddressType":"InputAddressType"} 
                                                        disabled={(this.state.isEntityEditClicked || entityAddress==null || entityAddress==undefined) ? false : true} 
                                                        name={"AddressIndividual_" + isIndividual} 
                                                        addressInformation={(entityAddress!=null && entityAddress!=undefined)?entityAddress:null} 
                                                        type={"CollateralEntityAddress"} commonData={this.props.legalEntitycommondata} isCollateralAddress={true}
                                                        isInternational={false} isDomesticAddress={true} onFieldBlur={this.onFieldBlur.bind(this)} 
                                                        hasError={this.hasError} doValidate={this.state.doValidate} />

                                                     {(!this.state.isEntityEditClicked && entityAddress !=null && entityAddress != undefined)?(
                                                         <a name="Entity_Edit" className="link cursor-pointer mar-l-15px pull-left mar-b-5px" onClick={this.onEditClick.bind(this)}>Edit</a>
                                                     ):''}
                                                </div>
                                            )):''}
                                            {/* Entity Address Ends*/}

                                    {/* collateral owner address section, Address section yet to integrate*/}
                                    {((this.state.collateralInformationData.Type && this.state.collateralInformationData.Type.Id!=-1 && this.state.collateralInformationData.Type.Id!=3)?(<div>
                                        {renderAccordion('fa fa-user-circle', (COLLATERAL_CONSTANT.COLLATERAL_OWNER_INFORMATION), 'panel accordion-brd-color font-size-12px', 'accordion-panel pad-4px bold', '', '',
                                        <div>
                                            <div className="row">
                                                <FormField columnSize={4} orientation={horizontal} key="OwnerOfCollateral" name="OwnerOfCollateral" type="radio" width="500"
                                                            displayText={COLLATERAL_CONSTANT.WHO_IS_OWNER}
                                                            displayValue={[{"Key":0,"Value":"Borrower"},{"Key":1,"Value":"Guarantor"}, {"Key":2,"Value":"Third Party Pledger"}]}
                                                            onFieldChange={this.onFieldChange} defaultOption={this.state.collateralInformationData.OwnerOfCollateral} />
                                            </div>
                                            {((this.state.collateralInformationData.OwnerOfCollateral==1 && guarantor.length>0)?(<div className="row">
                                                <FormField columnSize={4} orientation={horizontal} key="TypeOfGuarantor" name="TypeOfGuarantor"  type="select-single" displayText={COLLATERAL_CONSTANT.GUARANTORS} displayValue={guarantor} defaultSelectValue={_.findIndex(this.props.guarantorDetails, ['RelatedEntity.Id', this.state.collateralInformationData.Owner.Id])} onFieldChange={this.onGuarantorSelect.bind(this)} />
                                            </div>):(<div></div>))}

                                            {((this.state.collateralInformationData.OwnerOfCollateral==0 || this.state.collateralInformationData.OwnerOfCollateral==2 || (this.state.collateralInformationData.OwnerOfCollateral==1 && (_.findIndex(this.props.guarantorDetails, ['RelatedEntity.Id', this.state.collateralInformationData.Owner.Id])!=-1)))?(
                                                <div>{((this.state.collateralInformationData.Owner && this.state.collateralInformationData.Owner.EntityStructure && this.state.collateralInformationData.Owner.EntityStructure.StructureCode !== "I")?(<div className="row">
                                                    <FormField columnSize={4} orientation={vertical} key="LegalName"  name="LegalName" type="label-group" displayText={LEGALENITITY_COMMON_CONSTANT.BUSINESS_NAME} displayValue={this.state.collateralInformationData.Owner.LegalName} />
                                                </div>):(<div className="row">
                                                    <FormField columnSize={4} orientation={vertical} key="FirstName"  name="FirstName" type="label-group" displayText={LEGALENITITY_COMMON_CONSTANT.FIRST_NAME} displayValue={this.state.collateralInformationData.Owner.FirstName} />
                                                    <FormField columnSize={4} orientation={vertical} key="MiddleName"  name="MiddleName" type="label-group" displayText={LEGALENITITY_COMMON_CONSTANT.MIDDLE_NAME} displayValue={this.state.collateralInformationData.Owner.MiddleName} />
                                                    <FormField columnSize={4} orientation={vertical} key="LastName"  name="LastName" type="label-group" displayText={LEGALENITITY_COMMON_CONSTANT.LAST_NAME} displayValue={this.state.collateralInformationData.Owner.LastName} />
                                                </div>))}

                                                    {/*Borrower Owner Address start*/}
                                                    {(this.state.collateralInformationData.OwnerOfCollateral==0 && existingHomeAddress!=null && existingHomeAddress!= undefined)?(
                                                     renderAccordion('fa fa-address-card', (LEGALENITITY_COMMON_CONSTANT.HOME_ADDRESS), "panel accordion-brd-color font-size-12px", "accordion-panel pad-4px bold mar-r-5px", "", "",
                                                     <MultipleAddress name={"OwnerAddressIndividual_" + isIndividual}
                                                        existingAddress={existingHomeAddress}
                                                        newAddress={null}
                                                        addressCount={this.state.collateralAddressCount} isCollateralAddress={true} />
                                                     )):''}

                                                    {(this.state.collateralInformationData.OwnerOfCollateral==0 && existingBusinessAddress!=null && existingBusinessAddress!= undefined)?(
                                                        renderAccordion('fa fa-address-card', (LEGALENITITY_COMMON_CONSTANT.BUSINESS_ADDRESS), "panel accordion-brd-color font-size-12px", "accordion-panel pad-4px bold mar-r-5px", "", "",
                                                        <MultipleAddress name={"OwnerAddressIndividual_" + isIndividual}
                                                            existingAddress={existingBusinessAddress}
                                                            newAddress={null}
                                                            addressCount={this.state.collateralAddressCount} isCollateralAddress={true} />
                                                     )):''}
                                                {/*Borrower Owner Address ends*/}

                                                {(!this.state.isCollateralEditClicked && this.state.collateralInformationData.OwnerOfCollateral !=0)?(
                                                renderAccordion('fa fa-address-card', (isIndividual? LEGALENITITY_COMMON_CONSTANT.HOME_ADDRESS: LEGALENITITY_COMMON_CONSTANT.BUSINESS_ADDRESS), "panel accordion-brd-color font-size-12px", "accordion-panel pad-4px bold mar-r-5px", "", "",
                                                    <div>
                                                        <MultipleAddress name={"OwnerAddressIndividual_" + isIndividual}
                                                        defaultOption={this.state.defaultAddressOption}
                                                        existingAddress={existingAddress}
                                                        newAddress={this.state.collateralAddressNew? this.state.collateralAddressNew : null}
                                                        addressCount={this.state.collateralAddressCount} isCollateralAddress={true}
                                                        onMismatchClick={this.onMismatchClick.bind(this)} />

                                                    
                                                        {(this.state.collateralInformationData.OwnerOfCollateral == 2 && this.state.collateralInformationData.Owner && this.state.collateralInformationData.Owner.Addresses.length > 0 && existingAddress!=null)?(
                                                                <a name="CollateralAddress_Edit" className={(this.state.collateralAddressCount == 1)?("link mar-l-342px edit-link-style"):("link mar-r-20px pull-right edit-link-style")}
                                                                onClick={this.onEditClick.bind(this)}>Edit</a>
                                                        ):''}
                                                    </div>
                                                    )):''}
                                                    {(this.state.isCollateralEditClicked)?(
                                                    <EditableAddress addressType="EditableAddressType" disabled={false}  name={"OwnerAddressIndividual_" + isIndividual}
                                                        addressInformation={this.state.collateralAddressNew} type={"CollateralAddress"} isCollateralAddress={true}
                                                        commonData={this.props.legalEntitycommondata} isInternational={this.state.isInternationalAddress}
                                                        onCancelClick={this.onCancelClick.bind(this)}
                                                        onUpdateClick={this.onUpdateClick.bind(this)}
                                                        onClearClick={this.onClearClick.bind(this)}
                                                        onAddressTypeClick={this.onAddressTypeClick.bind(this)} 
                                                        onFieldBlur={this.onFieldBlur.bind(this)} hasError={this.hasError} doValidate={this.state.doValidateAddress} />
                                                        ):''}
                                                </div>):(<div></div>))}
                                            </div>
                                        )}</div>):(<div></div>))}
                                        
                                        <div className="row">
                                           <div className={this.state.isCollateralEditClicked?"disabled pull-right pull-left-sm pad-r-5px mar-r-5px btn-primary bg-btn-clr-navy text-center-xs":"pull-right pull-left-sm pad-r-5px mar-r-5px btn-primary bg-btn-clr-navy text-center-xs"}>
                           		                <span className=" fa fa-lg fa-floppy-o" aria-hidden="true"></span>
						                            <input type="button" className="bg-clr-transparent br-none wid-55px pad-l-7px"  value="Save"
                                                       onClick={this.onNextButtonClick.bind(this)} />
                                            </div>
                                        </div>
                                </div>
                            </div>
                        </fieldset>
                    </form>
                </div>]))
            }</div>);
    }

            _renderSearch(){
                let vertical=POSITION.VERTICAL;
                return(
                    <div>
                        <SearchCriteriaPage searchPageHeader="Collateral Owner Search"  isDisabled={this.state.searching}  onResetClick={this._resetSearchCriteria.bind(this)} onSearchClick={this.onSearchButtonClick.bind(this)} onKeyDown={this.onKeyDown} />
            </div>);
    }

    render()
    {
        if(this.props.collateralCommonData==undefined || this.props.collateralCommonData==null)
        {
            return (renderSpinner());
        }
        return(<div>{this._renderComponent()}</div>)
    }
}

Collateral.propTypes = {
    productType:PropTypes.number.isRequired,
    ajaxCallsInProgress:PropTypes.number.isRequired,
    actions: PropTypes.object.isRequired
};

Collateral.contextTypes = {
    router: PropTypes.object
};

function getCollateralById(collaterals, id) {
    let collateral =_.nth(collaterals, id);
    if(collateral)
        return collateral;
    return null;
}


let mapStateToProps = (state, ownProps) => {
    let _collateral={};
    if (state.loanAppReducer.LoanApplication.Collaterals.length > 0) {
        _collateral = getCollateralById(state.loanAppReducer.LoanApplication.Collaterals, ownProps.params.id);
    }
    return {
        collateralinformation: _collateral,
        borrowerDetails: state.loanAppReducer.LoanApplication.Borrower,
        guarantorDetails: state.loanAppReducer.LoanApplication.Guarantors,
        collateralCommonData: state.loanAppReducer.CollateralCommonData,
        searchresults:state.loanAppReducer.SearchResults,
        productsList: state.loanAppReducer.LoanApplication.Products,
        productTypeList: ((state.loanAppReducer.ProductCommonData!=undefined && state.loanAppReducer.ProductCommonData!=null)?(state.loanAppReducer.ProductCommonData.ProductTypeList):([])),
        legalEntitycommondata: state.loanAppReducer.LegalEntityCommonData,
        userId: state.loanAppReducer.LoanApplication.ApplicationSummary.EmployeeId,
        collateralList:state.loanAppReducer.LoanApplication.Collaterals,
       savedStatus: state.loanAppReducer.SavedStatus
    };
}

function mapDispatchToProps(dispatch) {
    return {actions: bindActionCreators({CreateCollateral, GetCollateralCommonData, SearchLegalEntities, GetCollateralOwner, SaveCollateralOwner, SaveCollateral, CreateCollateralOwner, GetQualifiedProposedCollaterals, GetQualifiedProductLs, CreateNewCollateral, IsInValidPOBox, UpdateActionStatus}, dispatch)};
}

export default connect(mapStateToProps, mapDispatchToProps)(Collateral);
