import React, {PropTypes} from "react";
import CustomLabel from "./Label";
import {renderTooltip} from "./Tooltip";
import {POSITION} from "../../constants/ApplicationConstants";

const Link = ({name, cssClass, displayText, isRequired, targetType, href, displayValue, orientation, columnSize, node, tooltip}) => {
    return ((orientation==POSITION.HORIZONTAL)?(
        <div>
            <div className="form-group">
                <div className={"col-sm-"+columnSize}>
                    {displayText && <CustomLabel value={displayText} cssClass={" " + cssClass} isRequired={isRequired} />}
                </div>
            </div>
            <div className="form-group">
                <div className={"col-sm-"+columnSize}>
                    <a id={name} className="link" target={targetType} name={name} ref={name} href={href}>{displayValue}</a>{((node)?(((tooltip)?(renderTooltip(name,tooltip,POSITION.TOP,node)):(node))):(""))}
                </div>
            </div>
        </div>
    ):(
        <div className={"col-lg-"+columnSize}>
            <div className="form-group">
                {displayText && <CustomLabel value={displayText} cssClass={" " + cssClass} isRequired={isRequired} />}
                <div className="col-sm-12 pad-0px mar-0px mar-l-10px">
                    <a id={name} className="link" target={targetType} name={name} ref={name} href={href}>{displayValue}</a>{((node)?(node):(""))}
                </div>
            </div>
        </div>
    ));
};

Link.propTypes = {
    href:PropTypes.string.isRequired,
    cssClass:PropTypes.string,
    name:PropTypes.string,
    displayText:PropTypes.string,
    isRequired:PropTypes.bool,
    targetType:PropTypes.string,
    displayValue:PropTypes.string,
    orientation:PropTypes.string,
    columnSize:PropTypes.number,
};

export default Link;
