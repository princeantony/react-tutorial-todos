import React, {PropTypes} from "react";
import CustomLabel from "./Label";
import {POSITION} from "../../constants/ApplicationConstants";

const LabelGroup = ({displayText, displayValue, columnSize, isRequired, orientation, error, cssLabelClass, cssLabelValueClass, name}) => {
    let wrapperClass = "form-group";
    if (error && error.length > 0) {
        wrapperClass += " " + "has-error";
    }

    return ((orientation == POSITION.HORIZONTAL) ? (
        <div>
            <div className={wrapperClass}>
                <div className={"col-md-" + columnSize}>
                    <CustomLabel value={displayText}
                                 cssClass={((cssLabelClass) ? (cssLabelClass) : ("normal clr-lbl font-size-12px "))}
                                 isRequired={isRequired}/>
                </div>
            </div>
            <div className="form-group">
                <div className={"col-md-" + columnSize}>
                    <CustomLabel cssClass={((cssLabelValueClass) ? (cssLabelValueClass) : ("clr-black font-size-15px"))}
                                 id={name} value={displayValue}/>
                </div>
            </div>
        </div>
    ) : (
        <div className={"col-md-" + columnSize}>
            <div className={wrapperClass}>
                <CustomLabel value={displayText}
                             cssClass={((cssLabelClass) ? (cssLabelClass) : ("normal clr-lbl font-size-12px "))}
                             isRequired={isRequired}/>
                <div className="pad-0px mar-0px">
                    <CustomLabel cssClass={((cssLabelValueClass) ? (cssLabelValueClass) : ("clr-black font-size-15px"))}
                                 id={name} value={displayValue}/>
                </div>
            </div>
        </div>
    ));
};

LabelGroup.propTypes = {
    displayText: PropTypes.string.isRequired,
    columnSize: PropTypes.number.isRequired,
    orientation: PropTypes.string.isRequired,
    isRequired: PropTypes.bool,
    ///displayValue: PropTypes.string,
    error: PropTypes.string,
};

export default LabelGroup;
