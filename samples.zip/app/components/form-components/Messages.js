﻿import React, {PropTypes} from "react";

const Messages = ({name, cssClass, displayText, type}) => {
    let wrapperClass="alert";
    if (type && type==="error-message") {
        wrapperClass += " " + "alert-danger";
    }
    else if(type && type==="success-message")
    {
        wrapperClass += " " + "alert-success";
    }
    else if(type && type==="warning-message")
    {
        wrapperClass += " " + "alert-warning";
    }
    else{
        wrapperClass += " " + "alert-info";
    }

    return (<div className={wrapperClass + " mar-b-0px"} role="alert"><div id={name} ref={name} className={cssClass}>{displayText}</div></div>);
};

Messages.propTypes = {
    type:PropTypes.string.isRequired,
    name:PropTypes.string,
    cssClass:PropTypes.string
    ///displayText:PropTypes.node,
};

export default Messages;
