import React, {Component, PropTypes} from 'react';
import CustomLabel from './Label';
import Select from 'react-select';
import { isRequired } from '../../utils/Functions';
import {POSITION} from "../../constants/ApplicationConstants";
import {validateFields} from "../../utils/Validation";

class SelectInput extends Component
{
    constructor(props) {
        super(props);
        this.state = {
            errors: {},
            defaultSelectValue: props.defaultSelectValue
        };
    }

    validateSelectField(props, isOnBlur)
    {
        let errors = validateFields(props, isOnBlur);
        this.setState({errors: errors});
        if(this.props.hasError && !isOnBlur)
            this.props.hasError(errors, props);
    }

    componentWillReceiveProps(nextProps)
    {
        /*if(nextProps.defaultSelectValue!=undefined && nextProps.defaultSelectValue!=null)
         {
           this.setState({defaultSelectValue:nextProps.defaultSelectValue});
         }*/
        if(nextProps.doValidate)
            this.validateSelectField(nextProps, false);
    }

    onFieldChange(e){
        this.setState({defaultSelectValue: e.target.value});

        if(this.props.isRequired){
            this.validateSelectField(this.props, true);
        }

        if(this.props.onFieldChange)
        {
            this.props.onFieldChange(e);
        }
    }

    _renderHorizontalLayout(){
        let wrapperClass = 'form-group';

        if (this.state.errors[(this.props.id != undefined)?this.props.id:this.props.name]) {
            wrapperClass += " " + ' has-error';
        }

        return(<div>
                <div className={wrapperClass}>
                        <div className={"col-md-"+this.props.columnSize}>
                        {this.props.displayText && <CustomLabel value={this.props.displayText}  cssClass="normal clr-lbl font-size-12px" isRequired={this.props.isRequired} help={this.props.help} />}
                        </div>
                </div>
                <div className={wrapperClass}>
                        <div className={"col-md-"+this.props.columnSize}>
                            <div className="width-175px input-group">
                        {((this.props.faClass)?(<span className="input-group-addon"><i className={"fa " + this.props.faClass} aria-hidden="true"></i></span>):(''))}
                        {((!this.props.autoComplete)?(<div>
                         <select {...this.props} id={(this.props.id != undefined)?this.props.id:this.props.name} name={this.props.name} ref={this.props.name} value={this.state.defaultSelectValue} disabled={this.props.isDisabled} onChange={this.onFieldChange.bind(this)} placeholder={this.props.placeholder} className={((!this.props.faClass)?("form-control"):("form-control "))}>
                               <option className="normal clr-black font-size-13px" value={this.props.pleaseSelectValue}>Please Select...</option>

                               {this.props.displayValue!=undefined &&  this.props.displayValue!=null && this.props.displayValue.length>0 && this.props.displayValue.map((option, index) => {
                                   return <option className="normal clr-black font-size-13px" key={index} hiddenSelectedValue={option} value={option[this.props.dataValueField]}>{option[this.props.dataTextField]}</option>;
                               })}

                            </select></div>):(<div><Select labelKey={this.props.dataTextField} valueKey={this.props.dataValueField} id={(this.props.id != undefined)?this.props.id:this.props.name}  name={this.props.name} value={this.props.defaultSelectValue} placeholder={this.props.placeholder}  options={this.props.displayValue} onChange={this.onFieldChange.bind(this)} clearable={true}  tabSelectsValue={true} onValueClick={this.onFieldChange.bind(this)} onBlur={this.onFieldChange.bind(this)} autoBlur={true} /></div>))}
                            </div>
                            {this.props.error && <div className="alert alert-danger">{this.props.error}</div>}
                        </div>
                </div>
       </div>
);
                            }

    _renderVerticalLayout(){
        let wrapperClass = 'form-group';

        if (this.state.errors[(this.props.id != undefined)?this.props.id:this.props.name]) {
            wrapperClass += " " + ' has-error';
        }

        return(<div>
       <div className={"col-lg-"+this.props.columnSize}>
            <div className={wrapperClass}>
            {this.props.displayText && <CustomLabel value={this.props.displayText} cssClass="normal clr-lbl font-size-12px" isRequired={this.props.isRequired} help={this.props.help}/>}
                <div className="col-md-12 pad-0px mar-0px">
                    <div className="width-175px input-group">{((this.props.faClass)?(<span className="input-group-addon"><i className={"fa " + this.props.faClass} aria-hidden="true"></i></span>):(''))}
                            {((!this.props.autoComplete)?(<div>
                            <select {...this.props} id={(this.props.id != undefined)?this.props.id:this.props.name} name={this.props.name} ref={this.props.name} value={this.state.defaultSelectValue} disabled={this.props.isDisabled} onChange={this.onFieldChange.bind(this)} placeholder={this.props.placeholder} className={((!this.props.faClass)?("form-control"):("form-control "))}>
                            <option className="normal clr-black font-size-13px" value={this.props.pleaseSelectValue}>Please Select...</option>

                            {this.props.displayValue!=undefined &&  this.props.displayValue!=null && this.props.displayValue.length>0 && this.props.displayValue.map((option, index) => {
                                return <option className="normal clr-black font-size-13px" key={index} hiddenSelectedValue={option} value={option[this.props.dataValueField]}>{option[this.props.dataTextField]}</option>;
                            })}

                    </select>
                    </div>):(<div><Select labelKey={this.props.dataTextField} valueKey={this.props.dataValueField} id={(this.props.id != undefined)?this.props.id:this.props.name} name={this.props.name} value={this.props.defaultSelectValue} placeholder={this.props.placeholder} options={this.props.displayValue} onChange={this.onFieldChange.bind(this)} clearable={true} tabSelectsValue={true} onValueClick={this.onFieldChange.bind(this)} onBlur={this.onFieldChange.bind(this)} autoBlur={true} /></div>))}
    {this.props.error && <div className="alert alert-danger">{this.props.error}</div>}
</div>
</div>
</div>
</div></div>);
    }

    _renderDropDown()
    {
        return (((this.props.orientation==POSITION.HORIZONTAL)?(<div>{this._renderHorizontalLayout()}</div>):(<div>{this._renderVerticalLayout()}</div>)));
    }

    render()
    {
        return (<div>{this._renderDropDown()}</div>);
    }

}

SelectInput.propTypes = {
    name: PropTypes.string.isRequired,
    displayText: PropTypes.string.isRequired,
    orientation:PropTypes.string.isRequired,
    columnSize:PropTypes.number.isRequired,
    onFieldChange: PropTypes.func,
    defaultOption: PropTypes.string,
    defaultSelectValue: PropTypes.number,
    error: PropTypes.string,
    isRequired:PropTypes.bool,
    displayValue: PropTypes.arrayOf(PropTypes.object),
    faClass:  PropTypes.string,
    autoComplete:PropTypes.bool,
    placeholder:PropTypes.string,
    isDisabled:PropTypes.bool
};

SelectInput.defaultProps = {
    defaultSelectValue:-1,
    dataTextField:"Value",
    dataValueField:"Key",
    pleaseSelectValue:-1
};

export default SelectInput;
