import React, { Component, PropTypes } from 'react'
import {Modal,ModalHeader,ModalTitle,ModalClose,ModalBody,ModalFooter} from 'react-modal-bootstrap'

class DialogBox extends Component {

    hideDialogBox(){
        this.props.onClose();
    }

    render() {
        return(
            <div>
                <Modal isOpen={this.props.isOpenDialog} onRequestHide={this.hideDialogBox.bind(this)} backdrop={false}>
                    <ModalHeader>
                        <ModalClose onClick={this.hideDialogBox.bind(this)}/>
                        <ModalTitle className="font-size-11px">{this.props.ModalTitle}</ModalTitle>
                    </ModalHeader>
                    <ModalBody>
                        <p>{this.props.Message}</p>
                    </ModalBody>
                    <ModalFooter>
                        {this.props.node}
                    </ModalFooter>
                </Modal>
            </div>);
    }
}

DialogBox.propTypes = {
    isOpenDialog:PropTypes.bool,
    ModalTitle:PropTypes.string,
    Message:PropTypes.string,
    node:PropTypes.node
}
export default DialogBox;