import React, {PropTypes} from "react";
import CustomLabel from "./Label";
import {POSITION, VALIDATION_CONSTANT} from "../../constants/ApplicationConstants";

const Radiogroup = ({name, displayText, isDisabled, onFieldChange, defaultOption, value, error, displayValue, orientation, columnSize, isRequired, faClass, help, doValidate, hasError, width = "200", className, disabledOption}) => {
    let wrapperClass = "form-group";
    if (error && error.length > 0) {
        wrapperClass += " " + "has-error";
    }
    
    let errors={};
    let isValid = false; 
    if(doValidate)
    {
        displayValue.map((option, index) => {
            if (!isValid && document.getElementById(name + "_" + option.Key).checked) 
            {
                isValid = true;
            }
        })
        
        if(!isValid)
        {
            let e ={};
            e.name= name;
            errors[name] = VALIDATION_CONSTANT.RADIO_BUTTON_REQUIRED;
            if(hasError)
                hasError(errors, e);
        }
    }

    return (
        ((orientation == POSITION.HORIZONTAL) ? (<div className={(isDisabled)?'disabled':''}> 
            <div className={wrapperClass}>
                <div className={"col-md-" + columnSize}>
                    {displayText &&
                    <CustomLabel value={displayText} cssClass="normal clr-lbl font-size-12px" isRequired={isRequired}
                                 help={help}/>}
                </div>
            </div>
            <div className={wrapperClass}>
                <div className="col-md-5">
                    <div className={"width-" + width + "px input-group"}>{((faClass) ? (
                        <span className="input-group-addon"><i className={"fa " + faClass}
                                                               aria-hidden="true"></i></span>) : (""))}
                        {
                            displayValue.map((option, index) => {
                                return (<div key={index}>
                                        <div className="float-l mar-r-6px"><input type="radio" className={((_.size(errors)==0)&&(className==undefined || className=="") ?"":"radio-error")}
                                                                                  id={name + "_" + option.Key}
                                                                                  name={name}
                                                                                  disabled={((option.Key == disabledOption) ? (true) : (false))}
                                                                                  onChange={onFieldChange}
                                                                                  defaultChecked={((option.Key == defaultOption) ? (true) : (false))}
                                                                                  value={option.Key}/></div>
                                        <div className="float-l mar-r-6px"><label
                                            className="clr-black font-size-15px">{option.Value}</label></div>
                                    </div>
                                )
                            })
                        }
                    </div>
                    {error && <div className="alert alert-danger">{error}</div>}
                </div>
            </div>
        </div>) : (<div className={(isDisabled)?'disabled':''}>
                <div className={"col-lg-" + columnSize}>
                    <div className="form-group">
                        {displayText && <CustomLabel value={displayText} cssClass="normal clr-lbl font-size-12px"
                                                     isRequired={isRequired} help={help}/>}
                        <div className="col-md-5 pad-0px mar-0px">
                            <div className={"width-" + width + "px input-group"}>{((faClass) ? (
                                <span className="input-group-addon"><i className={"fa " + faClass}
                                                                       aria-hidden="true"></i></span>) : (""))}
                                {
                                    displayValue.map((option, index) => {
                                        return (<div key={index}>
                                                <div className="float-l mar-r-6px"><input type="radio" className={((_.size(errors)==0)&&(className==undefined || className=="") ?"":"radio-error")}
                                                                                          id={name + "_" + option.Key}
                                                                                          disabled={((option.Key == disabledOption) ? (true) : (false))}
                                                                                          name={name}
                                                                                          onChange={onFieldChange}
                                                                                          defaultChecked={((option.Key == defaultOption) ? (true) : (false))}
                                                                                          value={option.Key}/></div>
                                                <div className="float-l mar-r-6px"><label
                                                    className="clr-black font-size-15px">{option.Value}</label></div>
                                            </div>
                                        )
                                    })
                                }
                                {error && <div className="alert alert-danger">{error}</div>}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        ))
    );
};

Radiogroup.propTypes = {
    name: PropTypes.string.isRequired,
    displayText: PropTypes.string.isRequired,
    onFieldChange: PropTypes.func,
    orientation: PropTypes.string.isRequired,
    columnSize: PropTypes.number.isRequired,
    defaultOption: PropTypes.bool,
    value: PropTypes.string,
    error: PropTypes.string,
    isRequired: PropTypes.bool,
    displayValue: PropTypes.arrayOf(PropTypes.object),
    faClass: PropTypes.string,
    help: PropTypes.string,
    isDisabled: PropTypes.bool
};

Radiogroup.defaultProps = {
    displayValue: [{"Key": true, "Value": "Yes"}, {"Key": false, "Value": "No"}],
    defaultOption: false,
};
export default Radiogroup;

