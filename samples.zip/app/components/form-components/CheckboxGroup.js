import React, { Component, PropTypes } from "react";
import CustomLabel from "./Label";

class CheckBox extends Component
{
    renderLabel(){
        return <CustomLabel value={this.props.displayText} cssClass="bold" isRequired={this.props.isRequired} />;
    }

    renderCheckList(){
        return <input id={this.props.id} ref={this.props.id} name={this.props.id} type="checkbox" checked={this.props.displayValue} />;
    }
    render() {
        return ((this.props.orientation=="horizontal")?(
            <div>
                <div className="form-group">
                    <div className={"col-md-"+this.props.columnSize}>{this.renderLabel()}</div>
                </div>
                <div className="form-group">
                    <div className="col-md-7 pull-left"> {this.renderCheckList()}</div>
                </div>
            </div>
        ):(
            <div className={"col-lg-"+this.props.columnSize}>
                <div className="form-group">
                    {this.renderLabel()}
                    <div className="col-sm-12 pad-0px mar-0px">{this.renderCheckList()}</div>
                </div>
            </div>
        ));
    }
}

CheckBox.propTypes = {
}

export default CheckBox;

