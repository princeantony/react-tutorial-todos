import React, { PropTypes, Component } from "react";
///import LinearPorgressBar from "./LinearPorgressBar";
import Legend from "./Legend";
import Messages from "./Messages";
import Grid from "./Grid";
import CustomLabel from "./Label";
import TextField from "./TextField";
import RadioGroup from "./RadioGroup";
import SelectInput from "./Select";
import LabelGroup from "./LabelGroup";
import Spinner from "./Spinner";
import DialogBox from "./DialogBox";

import Image from "./Image";
import Link from "./Link";
import TextArea from "./TextArea";
import CheckboxGroup from "./CheckboxGroup";
import DatePicker from "./DatePicker";

import CustomButton from "./CustomButton";

class FormField extends Component {

    render() 
    {
        return <div>{this.renderField()}</div>;
    }

    renderField()
    {
        switch (this.props.type)
        {
            case "custom-button": return <CustomButton {...this.props} />;
            case "dialog": return <DialogBox {...this.props} />;
            ///case "linear-progress": return <LinearPorgressBar {...this.props} />;
            case "spinner": return <Spinner {...this.props} />;
            case "legend": return <Legend {...this.props} />;
            case "error-message": return <Messages {...this.props} />;
            case "success-message": return <Messages {...this.props} />;
            case "info-message":return <Messages {...this.props} />;
            case "warning-message": return <Messages {...this.props} />;
            case "grid": return <Grid {...this.props} />;
            case "text" : return <TextField {...this.props} />;
            case "number" : return <TextField {...this.props} />;
            case "currency" : return <TextField {...this.props} />;
            case "phone" : return <TextField {...this.props} />;
            case "email" : return <TextField {...this.props} />;
            case "select-single": return <SelectInput {...this.props} />;
            case "image":  return <Image {...this.props} />;
            case "link":    return <Link {...this.props} />;
            case "label":   return <CustomLabel {...this.props} />;
            case "label-group":    return <LabelGroup {...this.props} />;
            case "radio" :   return <RadioGroup {...this.props} />;
            case "checkbox" :   return <CheckboxGroup {...this.props} />;
            case "textarea" : return <TextArea {...this.props} />;
            case "date":   return <DatePicker {...this.props} />;
        }
    }
}

export default FormField;
