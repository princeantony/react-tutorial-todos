import React, {PropTypes} from "react";

const Image = ({name, cssClass, src}) => {
    return (<img id={name} name={name} ref={name} className={cssClass} src={src} alt={name} />);
};

Image.propTypes = {
    src:PropTypes.string.isRequired,
    cssClass:PropTypes.string,
    name:PropTypes.string,
};

export default Image;
