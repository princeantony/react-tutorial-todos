import React, { Component, PropTypes } from "react";
import CustomLabel from "./Label";
import { isRequired } from "../../utils/Functions";
import { validateFields } from "../../utils/Validation";

class TextArea extends Component
{
    constructor(props) {
        super(props);
        this.state = {
            errors: {}
        };
    }

    componentWillReceiveProps(nextProps)
    {
        if(nextProps.doValidate)
            this.validateTextField(nextProps, false);
    }

    validateTextField(props, isOnBlur)
    {
        let errors = validateFields(props, isOnBlur);
        this.setState({errors: errors});
        if(this.props.hasError && !isOnBlur)
            this.props.hasError(errors, props);
    }

    onFieldBlur(e)
    {
        if(this.props.isRequired || this.props.isAlphaNumericFormat){
            {
                this.validateTextField(this.props, true);
            }
            if(this.props.onFieldBlur)
                this.props.onFieldBlur(e);
        }
    }

    render() {
        let wrapperClass = "form-group";
        let param = this.props.name;
        if(this.props.id!=undefined && this.props.id != null)
            param = this.props.id;
        if (this.state.errors[param]) {
            wrapperClass += " " + "has-error";
        }
        return ((this.props.orientation=="horizontal")?(
            <div>
                <div className="form-group">
                    <div className={"col-sm-"+this.props.columnSize}>
                        {this.renderLabel()}
                    </div>
                </div>
                <div className={wrapperClass}>
                        <div className={"col-sm-"+this.props.columnSize}>
                        {this.renderTextArea()}
                        </div>
                            </div>
                        </div>
        ):(
            <div className={"col-lg-"+this.props.columnSize}>
                <div className={wrapperClass}>
                {this.renderLabel()}
                    <div className={"col-sm-12 pad-0px mar-0px"}>
                        {this.renderTextArea()}
                    </div>
                </div>
            </div>
        ));
                }

    renderLabel() {
        return <CustomLabel value={this.props.displayText}  cssClass="normal clr-lbl font-size-12px" isRequired={this.props.isRequired} />;
    }

    renderTextArea() {
        return <textarea
        ref={this.props.name}
        id={(this.props.id != undefined)?this.props.id:this.props.name}
        className="textarea form-control wid-100-per"
        rows={this.props.rows}
        cols={this.props.cols}
        name={this.props.name}
        defaultValue={this.props.displayValue}
        onBlur={this.onFieldBlur.bind(this)} 
        maxLength={this.props.maxLength}/>;
    }
}

export default TextArea;
