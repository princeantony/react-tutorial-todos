﻿import React from "react";
import FormField from "./FormField";
import {BootstrapTable, TableHeaderColumn} from "react-bootstrap-table";

let renderGrid = (datasource, headers, selectRowProp=null)=>{
    return (<BootstrapTable data={datasource} condensed={true} selectRow={selectRowProp} ref='table'>
        {headers.map((header, index) => {
            return( <TableHeaderColumn isKey={header.value=="Id"} dataField={header.value} columnClassName={(header.value=="Id")?"display-none":""} className={(header.value=="Id")?"bold thead width-15-per display-none":"bold thead width-15-per"}>{header.name}</TableHeaderColumn>);
        })}
       </BootstrapTable>);
}

       let renderHyperLink = (id, linkText, url, cssClass, target="_blank") => {
    return (<a id={id} target={target} className={'link cursor-pointer ' + cssClass} ref={id} href={url}>{linkText}</a>);
}

let renderIcon = (classIcon) => {
    return (<i className={classIcon + " label-color"} aria-hidden="true"></i>);
}

let renderSpan = (cssClass, id, text) => {
    return (<span id={id} className={cssClass}>{text}</span>);
}

let renderSubSection = (subHeaderValue, childComponent) => {
    return (
        <div>
            <h6 className="label-color bold">
                {subHeaderValue}
            </h6>
            <div className="col-lg-12 pad-t-15px pad-b-15px pad-r-0px pad-l-0px brd brd-radius-10px mar-b-15px">
                {childComponent}
            </div>
        </div>
    );
}

let renderAccordion = (fieldSetIcon, subHeaderValue, accrdnStyle, accrdnHeaderStyle, accrdHeaderActions, accrdnBodyStyle, childComponent) => {
    return (<div>
            <fieldset className="brd-radius fsStyle pad-0px pad-l-5px pad-b-0px  mar-t-10px">
                 <legend className="legendStyle mar-b-0px font-14px bold txt-clr-navy">
                    <span><i className={fieldSetIcon+ " pad-r-5px"}></i>{subHeaderValue}{accrdHeaderActions}</span>
                </legend>
                <div className={accrdnBodyStyle}>
                    {childComponent}
                </div>
            </fieldset>
        </div>
    );
}
let renderAppSection = (subHeaderValue, pnlStyle, pnlHeaderStyle, pnlBodyStyle, childComponent) => {
    return (
        <div>
            <fieldset className="brd-radius fsStyle pad-0px bg-clr-lightgray pad-l-5px pad-b-0px">
                <legend className="legendStyle mar-b-0px font-14px bold txt-clr-gray">{subHeaderValue}</legend>
                <div className={pnlBodyStyle}>
                    {childComponent}
                </div>
            </fieldset>
        </div>
    );
}
let renderSection = (subHeaderValue, pnlStyle, pnlHeaderStyle, pnlBodyStyle, childComponent) => {
    return (
        <div>
            <fieldset className="brd-radius fsStyle pad-0px  pad-l-5px pad-b-0px">
                <legend className="legendStyle mar-b-0px font-14px bold txt-clr-gray">{subHeaderValue}</legend>
                <div className={pnlBodyStyle}>
                    {childComponent}
                </div>
            </fieldset>
        </div>
    );
}

    let renderSpinner=()=>{
        return(<div><FormField  type="spinner" /></div>);
    }

export {
    renderHyperLink, renderIcon, renderSpan, renderSubSection, renderAccordion, renderSection, renderSpinner, renderAppSection, renderGrid
};