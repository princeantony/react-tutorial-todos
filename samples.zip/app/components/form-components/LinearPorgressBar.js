﻿import React, {Component, PropTypes} from "react";
import ProgressBar from "react-bootstrap/lib/ProgressBar";

export default class LinearProgressBar extends Component{
    constructor(props) {
        super(props);
        this.state = {
            completed: this.props.min
        };
    }

    componentDidMount() {
        this.timer = setTimeout(() => this.progress(5), this.props.delay);
    }

    componentWillUnmount() {
        clearTimeout(this.timer);
    }

    progress(completed) {
        if (completed > this.props.max) {
            this.setState({completed: this.props.max});
        } else {
            this.setState({completed});
            const diff = Math.random() * 10;
            this.timer = setTimeout(() => this.progress(completed + diff), this.props.delay);
        }
    }

    render() {
        return (<ProgressBar active striped now={this.state.completed} bsClass={this.props.cssClass} />);
    }
}

LinearProgressBar.propTypes={
    delay:PropTypes.number.isRequired,
    min: PropTypes.number,
    max: PropTypes.number,
    displayText: PropTypes.string,
    isStriped: PropTypes.bool,
    isActive: PropTypes.bool,
    cssClass: PropTypes.string,
    customStyle: PropTypes.string,
}

ProgressBar.defaultProps = {
    min: 0,
    max: 100,
    isActive: true,
    isStriped: true,
};


