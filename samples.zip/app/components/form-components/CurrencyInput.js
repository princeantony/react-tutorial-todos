import React, {PropTypes} from 'react'
import mask from './mask.js'

const CurrencyInput = React.createClass({
    propTypes: {
        onChange: PropTypes.func,
        value: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
        decimalSeparator: PropTypes.string,
        thousandSeparator: PropTypes.string,
        precision: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
        inputType: PropTypes.string,
        allowNegative: PropTypes.bool,
        prefix: PropTypes.string,
        suffix: PropTypes.string
    },


   
    getDefaultProps(){
        return {
            onChange: function(maskValue){/*no-op*/},
            ///value: "0",
            decimalSeparator: ".",
            thousandSeparator: ",",
            precision: "2",
            inputType: "text",
            allowNegative: false,
            prefix: '',
            suffix: ''
        }
    },


    getInitialState(){
        let customProps = Object.assign({}, this.props); 
        delete customProps.onChange;
        delete customProps.value;
        delete customProps.decimalSeparator;
        delete customProps.thousandSeparator;
        delete customProps.precision;
        delete customProps.inputType;
        delete customProps.allowNegative;
        delete customProps.prefix;
        delete customProps.suffix;
        return {
            maskedValue: mask(
                this.props.value,
                this.props.precision,
                this.props.decimalSeparator,
                this.props.thousandSeparator,
                this.props.allowNegative,
                this.props.prefix,
                this.props.suffix
            ),
            customProps: customProps
        }
    },


    componentWillReceiveProps(nextProps){
        let customProps = Object.assign({}, nextProps); 
        delete customProps.onChange;
        delete customProps.value;
        delete customProps.decimalSeparator;
        delete customProps.thousandSeparator;
        delete customProps.precision;
        delete customProps.inputType;
        delete customProps.allowNegative;
        delete customProps.prefix;
        delete customProps.suffix;
        this.setState({
            maskedValue: mask(
                nextProps.value,
                nextProps.precision,
                nextProps.decimalSeparator,
                nextProps.thousandSeparator,
                nextProps.allowNegative,
                nextProps.prefix,
                nextProps.suffix
            ),
            customProps: customProps
        });
    },


   
    getMaskedValue(){
        return this.state.maskedValue;
    },


    onFieldChange(event){
        event.preventDefault();
        let maskedValue = mask(
            event.target.value,
            this.props.precision,
            this.props.decimalSeparator,
            this.props.thousandSeparator,
            this.props.allowNegative,
            this.props.prefix,
            this.props.suffix
        );
        this.setState({maskedValue: maskedValue});
        if(this.props.onChange)
            this.props.onChange(event);
    },

    onFieldBlur(event){
        event.preventDefault();
        if(this.props.onBlur)
            this.props.onBlur(event);
    },


    onKeyPress(event){
        event.preventDefault();
        if(this.props.onKeyPress)
            this.props.onKeyPress(event);
    },

    onKeyDown(event){
        event.preventDefault();
        if(this.props.onKeyDown)
            this.props.onKeyDown(event);
    },

    render() {
        return (
            <input {...this.props}
                type={this.props.inputType}
                key={this.props.name}
                ref={this.props.name} 
                name={this.props.name} 
                id={this.props.name} 
                value={this.state.maskedValue}
                className={this.props.className}
                placeholder={this.props.placeholder}
                onChange={this.onFieldChange}
                onBlur={this.onFieldBlur} 
                onKeyPress={this.onKeyPress} 
                onKeyDown={this.onKeyDown} 
                disabled={this.props.isDisabled}
                {...this.state.customProps}
            />
        )
    }
});


export default CurrencyInput
