﻿import React, {PropTypes} from "react";

const Legend = ({displayText, cssClass}) => {
    return (
         <div className="txt-aln-r col-lg-12 text-left-xs">
            <label className={"clr-red " + cssClass}>{displayText}</label>
        </div>
    );
};

Legend.propTypes = {
        displayText:PropTypes.string.isRequired,
        cssClass: PropTypes.string,
        name: PropTypes.string
};

export default Legend;
