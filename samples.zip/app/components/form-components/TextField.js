import React, {Component, PropTypes} from "react";
import CustomLabel from "./Label";

import MaskedInput from "react-maskedinput";
///import CurrencyInput from "./CurrencyInput";
import NumberFormat from "react-number-format";

import { validateNumber, isValidAmount, isValidEmail, isValidLengthOrFormat, isRequired, isMinMaxValid} from "../../utils/Functions";
import {POSITION} from "../../constants/ApplicationConstants";
import { validateFields } from "../../utils/Validation";
import _ from "lodash";

class TextField extends Component
{
    constructor(props) {
        super(props);
       this.state = {
           errors: {},
           displayValue: _.trim(props.displayValue)
       };
       this.onFieldBlur =this.onFieldBlur.bind(this);
       this.onKeyDown =this.onKeyDown.bind(this);
       this.onKeyPress =this.onKeyPress.bind(this);
       this.onFieldChange =this.onFieldChange.bind(this);
    }

    validateTextField(props, isOnBlur)
    {
        let errors = validateFields(props, isOnBlur);
        this.setState({errors: errors});
        if(this.props.hasError)
            this.props.hasError(errors, props);
    }

    componentWillReceiveProps(nextProps)
    {
        if(nextProps.doValidate)
            this.validateTextField(nextProps, false);
    }

    onFieldBlur(e){
        if(this.props.type=="email" || this.props.isNumberFormat || this.props.minValue || this.props.maxValue || this.props.dollarFormat || this.props.isRequired || this.props.isAlphaNumericFormat  || this.props.isPhoneNumber || this.props.type=="currency")
        {
            this.validateTextField(this.props, true);
        }
        if(this.props.onFieldBlur)
            this.props.onFieldBlur(e);
    }



    onKeyDown(e)
    {
        if(this.props.onKeyDown)
            this.props.onKeyDown(e);
    }

    onKeyPress(e)
    {
        if(this.props.onKeyPress)
            this.props.onKeyPress(e);
    }

    onFieldChange(e){
        this.setState({displayValue: e.target.value});
        if(this.props.onFieldChange)
            this.props.onFieldChange(e);
    }

    renderPhoneInput(){
        return(<MaskedInput key={this.props.name} ref={this.props.name} mask={this.props.dataMask} name={this.props.name}  id={this.props.name} className={((!this.props.faClass)?("form-control  normal clr-black font-size-15px"):("form-control  normal clr-black font-size-15px"))}  placeholder={this.props.placeholder} value={this.state.displayValue} onBlur={this.onFieldBlur} onChange={this.onFieldChange} onKeyPress={this.onKeyPress} onKeyDown={this.onKeyDown} disabled={this.props.isDisabled} />);
        }

        renderCurrencyInput(){
            return(<NumberFormat className="form-control" value={this.state.displayValue}  thousandSeparator={true} key={this.props.name}  ref={this.props.name} name={this.props.name} id={(this.props.id != undefined)?this.props.id:this.props.name} onBlur={this.onFieldBlur} onChange={this.onFieldChange} />);
            ///return(<input {...this.props} type="text" key={this.props.name}  ref={this.props.name} name={this.props.name} id={(this.props.id != undefined)?this.props.id:this.props.name} maxLength={this.props.maxLength} className={((!this.props.faClass)?("form-control  brd-radius-4px normal clr-black font-size-15px"):("form-control  normal clr-black font-size-15px"))} placeholder={this.props.placeholder} value={this.state.displayValue} onBlur={this.onFieldBlur} onChange={this.onFieldChange} onKeyPress={this.onKeyPress} onKeyDown={this.onKeyDown} disabled={this.props.isDisabled} />);   
      }

            renderTextInput(){
                return(<input {...this.props} type="text" key={this.props.name}  ref={this.props.name} name={this.props.name} id={(this.props.id != undefined)?this.props.id:this.props.name} maxLength={this.props.maxLength} className={((!this.props.faClass)?("form-control  brd-radius-4px normal clr-black font-size-15px"):("form-control  normal clr-black font-size-15px"))} placeholder={this.props.placeholder} value={this.state.displayValue} onBlur={this.onFieldBlur} onChange={this.onFieldChange} onKeyPress={this.onKeyPress} onKeyDown={this.onKeyDown} disabled={this.props.isDisabled} />);   
     }

    _renderHorizontalLayout(){
        let wrapperClass = "form-group";
        let param = this.props.name;
        if(this.props.id!=undefined){
            param = this.props.id;
        }
        if (this.state.errors[param]) {
            wrapperClass += " " + " has-error";
        }
        return(<div>
                    <div className={wrapperClass}>
                       <div className={"col-md-"+this.props.columnSize}>
                       {this.props.displayText && <CustomLabel value={this.props.displayText}  cssClass="normal clr-lbl font-size-12px" isRequired={this.props.isRequired} help={this.props.help} />}
                       </div>
                    </div>
                    <div className={this.wrapperClass}>
                         <div className={"col-md-"+this.props.columnSize}>
                            <div className="wid-176px input-group">{((this.props.faClass)?(<span className="input-group-addon"><i className={"fa " + this.props.faClass} aria-hidden="true"></i></span>):(""))}
                                {/*((this.props.dataMask)?():())*/}
                                {((this.props.type=="phone")?(this.renderPhoneInput()):((this.props.type=="currency")?(this.renderCurrencyInput()):(this.renderTextInput())))}
                            </div>
                            {(this.props.node!==null)?(this.props.node):("")}
                            {/*this.props.error && <div className="alert alert-danger mar-b-0px"><i className="fa fa-exclamation-triangle" aria-hidden="true"></i>{this.props.error}</div>*/}
            </div>
        </div>
    </div>
);
    }


    _renderVerticalLayout(){
        let wrapperClass = "form-group";
        let param = this.props.name;
        if(this.props.id!=undefined){
            param = this.props.id;
        }
        if (this.state.errors[param]) {
            wrapperClass += " " + " has-error";
        }

        return(<div>
                      <div className={"col-lg-"+this.props.columnSize}>
                                          <div className={wrapperClass}>
                                          {this.props.displayText && <CustomLabel value={this.props.displayText} cssClass="normal clr-lbl font-size-12px" isRequired={this.props.isRequired} help={this.props.help} />}
                                                 <div className="col-md-12 pad-0px mar-0px">
                                                    <div className="wid-176px input-group">{((this.props.faClass)?(<span className="input-group-addon"><i className={"fa " + this.props.faClass} aria-hidden="true"></i></span>):(""))} 
                                          {/*((this.props.dataMask)?():())*/}
                                          {((this.props.type=="phone")?(this.renderPhoneInput()):((this.props.type=="currency")?(this.renderCurrencyInput()):(this.renderTextInput())))}
                                                    </div>
                                                    {(this.props.node!==null)?(this.props.node):("")}
    {/*this.props.error && <div className="alert alert-danger mar-b-0px"><i className="fa fa-exclamation-triangle" aria-hidden="true"></i>{this.props.error}</div>*/}
  </div>
</div>
</div>
</div>);
    }

    _renderTextField()
    {
        return (((this.props.orientation==POSITION.HORIZONTAL)?(<div>{this._renderHorizontalLayout()}</div>):(<div>{this._renderVerticalLayout()}</div>)));
    }

    render()
    {
        return (<div>{this._renderTextField()}</div>);
    }
}


TextField.propTypes = {
    columnSize:PropTypes.number.isRequired,
    orientation:PropTypes.string.isRequired,
    name: PropTypes.string.isRequired,
    displayText: PropTypes.string,
    onFieldChange: PropTypes.func,
    onFieldBlur: PropTypes.func,
    placeholder: PropTypes.string,
    ///displayValue: PropTypes.string,
    error: PropTypes.string,
    isRequired:PropTypes.bool,
    faClass:PropTypes.string,
    dataMask:PropTypes.string,
    node:PropTypes.node,
    help:PropTypes.string
};

TextField.defaultProps = { displayValue: '' };

export default TextField;
