﻿import React, {PropTypes} from "react";
import OverlayTrigger from "react-bootstrap/lib/OverlayTrigger";
import Tooltip from "react-bootstrap/lib/Tooltip";

const renderTooltip = (tooltipId,tooltipText,tooltipDirection,control) => {
    let tooltip=  (<Tooltip id={tooltipId}>{tooltipText}</Tooltip>);
    return(<OverlayTrigger placement={tooltipDirection} overlay={tooltip}>{control}</OverlayTrigger>);
}

renderTooltip.propTypes = {
    tooltipId:PropTypes.string.isRequired
}

export { renderTooltip };
