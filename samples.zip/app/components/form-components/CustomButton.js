﻿import React, {PropTypes} from "react";

const CustomButton = (cssClass, displayText, onClick, isDisabled) => {
    return(<div><input type="button" className={cssClass} value={displayText} onClick={onClick} disabled={isDisabled} /></div>);
}

export default CustomButton;
