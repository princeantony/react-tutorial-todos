import React, {PropTypes} from "react";
import {renderTooltip} from "./Tooltip";
import {renderIcon} from "./Form";
import {POSITION} from "../../constants/ApplicationConstants";

const CustomLabel = ({id, name, value, isRequired, cssClass, help, node}) => {
    return  (<div>{((help)?(renderTooltip((name +"_"+ value),help,POSITION.TOP,(renderIcon("fa fa-info-circle pad-r-5px")))):(""))}<label ref={name} id={id} type="label" className={cssClass}>{value}</label>{((node)?(node):(""))}{((isRequired)?(<span className="clr-red pad-l-5px bold font-size-14px">*</span>):(""))}</div>);
};
CustomLabel.propTypes = {
    name:PropTypes.string,
    cssClass:PropTypes.string,
    help:PropTypes.string,
    isRequired:PropTypes.bool,
}

export default CustomLabel;
            
