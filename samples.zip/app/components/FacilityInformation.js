﻿import React, {PropTypes, Component} from 'react';
import FormField from './form-components/FormField';
import {LEGALENITITY_COMMON_CONSTANT, POSITION, VALIDATION_CONSTANT} from '../constants/ApplicationConstants';
let MonthlyPayment = "";
let PropertyValue = "";
let Comments = "";
class FacilityInformation extends Component {
    constructor(props) {
        super(props);
        this.state = {
            selectedValue: props.paramId == "add"? -1 : ((props.facilityInformation && props.facilityInformation.FacilityType!=undefined)?props.facilityInformation.FacilityType:1)
        }
    }
    onFieldChange(e) {
        this.setState({selectedValue: e.target.value});
    }   

    componentWillReceiveProps(nextProps){
        if(nextProps.facilityInformation!= this.props.facilityInformation)
        {
            this.setState({selectedValue: nextProps.facilityInformation.FacilityType == undefined ? 1 : nextProps.facilityInformation.FacilityType});
        }
    }
     
    render() {
        const {facilityInformation, facilities, paramId, type, doValidate, hasError}=this.props;   
       
        let vertical = POSITION.VERTICAL;
        let horizontal = POSITION.HORIZONTAL;
       
        if(facilityInformation != undefined && facilityInformation != null)
        {   
            MonthlyPayment = facilityInformation.MonthlyPayment;
            PropertyValue = facilityInformation.PropertyValue;
            Comments = facilityInformation.Comments;
        }
        return (
            <div name={type + "_facilitiesDiv"} id={type + "_facilitiesDiv"}>
                <div className="row">
                    {(type === "Business") ? (
                        <FormField columnSize={4} orientation={vertical} id={type+"_FacilityType"}
                                   name="FacilityType" type="select-single"
                                   onFieldChange={this.onFieldChange.bind(this)}
                            displayText={LEGALENITITY_COMMON_CONSTANT.FACILITIES} hasError={hasError} doValidate={doValidate}
                            defaultSelectValue={this.state.selectedValue} 
                            isRequired={true}  displayValue={facilities}/>
                    ) : (<FormField columnSize={4} orientation={vertical} name="FacilityType"
                                    type="radio" displayText={LEGALENITITY_COMMON_CONSTANT.RESIDENCE}
                                    displayValue={_.reject(facilities, {Key: 4})} onFieldChange={this.onFieldChange.bind(this)}
                        defaultOption={this.state.selectedValue} isRequired hasError={hasError} doValidate={doValidate}/>)}
                    {((this.state.selectedValue == 1) || (this.state.selectedValue == 2)) ?
                        (<div><FormField columnSize={4} orientation={vertical}
                                         faClass="fa-usd label-color font-size-14px bold"
                                         id={type +"MonthlyPayment"} name="MonthlyPayment"
                                         type="currency" dollarFormat={true}
                                         displayText={LEGALENITITY_COMMON_CONSTANT.MONTHLY_RENT_MORTGAGE_PAYMENT}
                                         displayValue={MonthlyPayment} isRequired hasError={hasError} doValidate={doValidate} errorMessage={VALIDATION_CONSTANT.FORMAT_NOT_VALID}/>
                        {(this.state.selectedValue == 1) ? 
                                <FormField columnSize={4} orientation={vertical}
                                    faClass="fa-usd label-color font-size-14px bold"
                                    id={type +"PropertyValue"} name="PropertyValue" type="currency" dollarFormat={true}
                                    displayText={LEGALENITITY_COMMON_CONSTANT.PROPERTY_VALUE}
                                    displayValue={PropertyValue}
                                    isRequired hasError={hasError} doValidate={doValidate} errorMessage={VALIDATION_CONSTANT.FORMAT_NOT_VALID}/> : ""}</div>) : ""}
                    {(this.state.selectedValue == 3) ?
                        (<FormField columnSize={8} orientation={vertical} id={type +"Comments"} name="Comments" type="textarea" rows="3" cols="8"
                                    displayText={LEGALENITITY_COMMON_CONSTANT.COMMENTS} displayValue={Comments} isRequired hasError={hasError} doValidate={doValidate}/>) : ""}
                </div>
            </div>
        )
    }
}

FacilityInformation.propTypes = {
    facilities: PropTypes.array.isRequired
}
export default FacilityInformation;
