import React, { PropTypes, Component } from 'react';
import {LEGALENITITY_COMMON_CONSTANT, POSITION} from '../constants/ApplicationConstants';
import FormField from './form-components/FormField';

class MismatchAddress extends Component{
  constructor(props, context) {
          super(props, context); 
      }

    onEditClick(e)
    {

    }
    onMismatchClick(e){
       this.props.onMismatchClick(e.target.name, e.target.value);
    }

    render(){
        const{ leftAddress, rightAddress, onFieldChange }=this.props;
        if(leftAddress.Province == undefined || leftAddress.Province == null )
        {leftAddress.Province = "";}
        if(leftAddress.County == undefined || leftAddress.County == null )
        {leftAddress.County = "";}

        if(rightAddress.Province == undefined || rightAddress.Province == null )
        {rightAddress.Province = "";}
        if(rightAddress.County == undefined || rightAddress.County == null )
        {rightAddress.County = "";}

        let vertical=POSITION.VERTICAL;
        let horizontal=POSITION.HORIZONTAL;
        let type=this.props.type;
        let isBFNADomestic=null;
        let isCCASDomestic=null;
        let rightPanel=this.props.rightPanel;
        let isUpdated=this.props.addressUpdated;
        let leftAddressType=this.props.leftAddressType;
        let rightAddressType=this.props.rightAddressType;
        
        //isBFNADomestic=(this.props.isBFNABusinessDomestic):(isBFNADomestic=this.props.isBFNAHomeDomestic);
        //isCCASDomestic=this.props.isBusinessDomestic):(isCCASDomestic=this.props.isHomeDomestic);

        return(
          <div className="row pad-5px">
          {(type=="GuarantorAddress")?(""):(
            <div className="pad-l-15px italic">{LEGALENITITY_COMMON_CONSTANT.ADDRESS_MISMATCH_MESSAGE}</div>
          )}
            <div className="row col-sm-6">
            {(!isUpdated)?(""):(
                <FormField  columnSize={12} orientation={horizontal}  name={this.props.name}
                id="rdoisMismatchCCAS" type="radio" onFieldChange={this.onMismatchClick.bind(this)}
                displayValue={[{"Key": 1,"Value":""}]}  />
              )}
                <div className={(type=="GuarantorAddress" && !isUpdated)?("row border-div"):("row border-div mar-t-30px")}>
                    <FormField columnSize={4} orientation={horizontal} name={this.props.addressType} type="label" cssClass="pad-l-15px"
                    value={LEGALENITITY_COMMON_CONSTANT.ADDRESS_TYPE+": "+((leftAddressType)?(LEGALENITITY_COMMON_CONSTANT.DOMESTIC):(LEGALENITITY_COMMON_CONSTANT.INTERNATIONAL))} />
                    <div className="row pad-l-15px col-sm-12">
                        <FormField columnSize={4} orientation={horizontal} cssLabelClass="font-size-12px" cssLabelValueClass="" type="label" 
                        value={((leftAddress.Line1 !=null)?(leftAddress.Line1 +", "):(''))+((leftAddress.Line2!=null)?(leftAddress.Line2 +", "):(''))+leftAddress.Province} />
                    </div>
                    <div className="row pad-l-15px col-sm-12">
                        <FormField columnSize={4} orientation={horizontal} cssClass="font-size-12px" cssLabelValueClass="" type="label" 
                        value={((leftAddress.City!=null)?(leftAddress.City +", "):(''))+((leftAddress.County!=null)?(leftAddress.County +", "):(''))+leftAddress.ZipCode}  />
                    </div>
                </div>
            </div>
          {(rightPanel)?
          (<div className="row col-sm-6">
           {(!isUpdated)?(""):(
                <FormField  columnSize={12} orientation={horizontal}  name={this.props.name}
                id="rdoisMismatchCCAS" type="radio" onFieldChange={this.onMismatchClick.bind(this)}
                displayValue={[{"Key": 2,"Value": ""}]}  defaultOption={(type=="GuarantorAddress")?(2):('')}/>
            )}
            <div className={(type=="GuarantorAddress" && !isUpdated)?("row border-div"):("row border-div mar-t-30px")}>
                <FormField columnSize={4} orientation={horizontal} name={this.props.addressType} type="label" cssClass="pad-l-15px"
                value={LEGALENITITY_COMMON_CONSTANT.ADDRESS_TYPE+": "+((rightAddressType)?(LEGALENITITY_COMMON_CONSTANT.DOMESTIC):(LEGALENITITY_COMMON_CONSTANT.INTERNATIONAL))} />
                <div className="row pad-l-15px col-sm-12">
                    <FormField columnSize={4} orientation={horizontal} cssClass="font-size-12px" cssLabelValueClass="" type="label" 
                    value={((rightAddress.Line1 !=null)?(rightAddress.Line1 +", "):(''))+((rightAddress.Line2!=null)?(rightAddress.Line2 +", "):(''))+rightAddress.Province} />
                </div>
                <div className="row pad-l-15px col-sm-12">
                    <FormField columnSize={4} orientation={horizontal} cssClass="font-size-12px" cssLabelValueClass="" type="label" 
                    value={((rightAddress.City!=null)?(rightAddress.City +", "):(''))+((rightAddress.County!=null)?(rightAddress.County +", "):(''))+rightAddress.ZipCode}  />
                </div>
            </div>
        </div>):""}

      </div>)
    }
}
MismatchAddress.propTypes = {
    leftAddress:PropTypes.object.isRequired,
    rightAddress:PropTypes.object.isRequired,
}
MismatchAddress.defaultProps = {
    isUpdated:true,
};
export default MismatchAddress;
