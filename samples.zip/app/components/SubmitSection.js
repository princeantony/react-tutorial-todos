/*eslint-disable import/default */
/* React libraries */
import React, { Component, PropTypes } from "react";
import { render } from "react-dom";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";

import {Modal,ModalHeader,ModalTitle,ModalClose,ModalBody,ModalFooter} from 'react-modal-bootstrap'

/* LoanApp libraries */
import {showSuccess, showWarning, showError, getDisclosures} from "../utils/Functions";

/* Action components */
import {SubmitLoanApplication, CancelLoanApplication} from "../actions/serviceAction";

/* Child components libraries */
import ConfirmationPage from "./ConfirmationPage";
import FormField from "./form-components/FormField";
import { renderSpinner, renderGrid} from "./form-components/Form";

/* Constant components */
import {SUBMIT_CONSTANT, ADDITIONAL_INFORMATION} from "../constants/ApplicationConstants";
import {APPLICATION_URL} from "../constants/ApplicationURL";


let nodeMessage = (<span><label>Are you sure you want to cancel?</label><br/> <label><span className="clr-red">WARNING: </span> If "Yes" is selected, the entire application will be cancelled and no data will be retained.</label> </span>);
let headers=[{name:'Product ID', value:'Id'},{name:'Product', value:'ProductDisplayName'},{name:'Amount', value:'Amount'},{name:'Description', value:'ProductDescription'}];
let displayProductList=[];
let canEnableSubmit = false;
let CreditPullAuthorization = false;
let ApplicationInformationConfirmation = false;
const selectRowProp = {
    mode: ''
};

class SubmitSection extends Component {
    constructor(props, context) {
        super(props, context);
        this.state = {
            isOpenDialog:false,
            isOpenCancelDialog:false,
            displayText:nodeMessage,
            submit:true,
            saving: false,
            isGuarantorDialog: false,
            isOpenMappingDialog:false
        };
    }
    
    /* component lifecycle methods start */
    componentWillReceiveProps(nextProps){
        let _disclosuresList =  getDisclosures(this.props.productsList);
            
        if(_disclosuresList.length>0)
        {
            canEnableSubmit = ((nextProps.AdditionalInformation!=null && nextProps.isDisclosureViewed)?true:false);
        }
        else
        {
            canEnableSubmit = ((this.props.AdditionalInformation!=nextProps.AdditionalInformation || nextProps.AdditionalInformation!=null)?true:false);
        }
    }
    /* component lifecycle methods end */

    /* action methods start */
    OnChangeCheckBox()
    {
        ApplicationInformationConfirmation = document.getElementById("ApplicationInformationConfirmation").checked;
        CreditPullAuthorization =  document.getElementById("CreditPullAuthorization").checked;
        if(ApplicationInformationConfirmation && CreditPullAuthorization && canEnableSubmit )
        {
            this.setState({submit:!canEnableSubmit});
        }
        else
        {
            this.setState({submit: true});
        }
       
    }
    onSubmitButtonClick(){
        this.setState({submit: true, saving: true});
        this.props.loanAppInformation.CreditPullAuthorization = CreditPullAuthorization;
        this.props.loanAppInformation.ApplicationInformationConfirmation = ApplicationInformationConfirmation;
        let BLCProducts = _.filter(this.props.productsList,  function(o){
            return (o.Type=="BLC" && o.ProductId!=0);
        });
        let unmappedProductList =  _.difference((_.map(BLCProducts, 'ProductId')), (_.uniq(_.flatMap(_.map(this.props.collateralList, 'ProductIds'))))); ////*return !o.active;*/ });
        if(unmappedProductList.length>0)
        {
            let showProducts =_.filter(BLCProducts, function(o){
                return _.includes(unmappedProductList, o.ProductId);
            });

            displayProductList=[];
            showProducts.map((product, index) => {
                    let _product={Id:product.ProductId,ProductDisplayName:product.DisplayName, Amount:("$" + ((product.IntegrationCode=="TM-ACH" || product.IntegrationCode=="DSL")?(((product.IntegrationCode=="TM-ACH" && product.IsPrefunding==false)?(product.TotalCreditExposureLimit+"/"+product.TotalDebitExposureLimit):(product.DailySettlementLimitAmt+"/"+product.ForeignExchangeRiskLimitAmt))):(product.RequestedAmount))),ProductDescription:this.getIntegrationCode(product.ProductType.IntegrationCode)};
                    displayProductList.push(_product);
            });
            if(displayProductList.length>0)
            {
                this.setState({isOpenMappingDialog:true});
            }
            this.setState({submit: false, saving: false});
        }
        else
        {
         if(this.props.guarantorList.length>0)
         {
               this.props.actions.SubmitLoanApplication(this.props.loanAppInformation).then(()=>{
                        this.setState({submit: false, saving: false});
                        render(<ConfirmationPage confirmationDetails={this.props.loanAppInformation} Data={this.props.productCommonData} />, document.getElementById("app"));
                }).catch(error=>{
                    this.setState({submit: false, saving: false});
                    console.log(error.response.data.ExceptionMessage);
                });
            }
            else
            {
                    this.setState({isGuarantorDialog:true});
            }
        }
      }

      openAppConfirmCancelDialogbox(){
                          this.props.actions.CancelLoanApplication(this.props.loanAppInformation).then((data)=>{
                              this.setState({isOpenDialog:false, isOpenCancelDialog:true, displayText:SUBMIT_CONSTANT.APP_CANCEL_CONFIRMATION_MESSGAE});
                          }).catch(error=>{
                              console.log(error.response.data.ExceptionMessage);
           });
      }
    /* action methods end */

      getIntegrationCode(productType){
          let ProductTypeDesc = _.find(this.props.productCommonData.ProductTypeList, ["IntegrationCode", productType]);
          return (ProductTypeDesc!=undefined && ProductTypeDesc!=null)?ProductTypeDesc.ProductTypeDescription:"";
      }

           cancelDialogBox(isOpen){
               this.setState({isOpenDialog:isOpen});
           }

    closeAppConfirmCancelDialogbox(){
        this.setState({isOpenDialog:false});
        window.open("", "_self", "");
        window.close();
    }

    closeGuarantorConfirmation(isOpen)
    {
        this.setState({submit: false, saving: false, isGuarantorDialog:isOpen});
    }

    navigateToGuarantors(isOpen)
    {
        this.setState({submit: false, saving: false, isGuarantorDialog:isOpen});
        this.context.router.push(APPLICATION_URL.GUARANTOR_SEARCH_CRITERIA_PAGE + 'G');
    }

    closeMapping(isOpen)
    {
        this.setState({isOpenMappingDialog:isOpen});
    }

    submitLoanApplication(isOpen)
    {
        this.setState({isGuarantorDialog:isOpen});
        this.props.actions.SubmitLoanApplication(this.props.loanAppInformation).then(()=>{
            this.setState({submit: false, saving: false});
            render(<ConfirmationPage confirmationDetails={this.props.loanAppInformation} Data={this.props.productCommonData} />, document.getElementById("app"));
        }).catch(error=>{
            this.setState({submit: false, saving: false});
            console.log(error.response.data.ExceptionMessage);
        });
    }

        render() {
        ///let productMapping = (<div><label className="clr-black font-size-15px">{renderGrid(displayProductList, headers, selectRowProp)}</label></div>);
        let nodeConfirmation =(<span>
                            <button className="btn btn-primary" onClick={this.openAppConfirmCancelDialogbox.bind(this)}>Yes</button>
                            <button className="btn btn-primary" onClick={this.cancelDialogBox.bind(this, false)}>No</button>
                        </span>);
       let nodeConfirmationCancel = (<span><button className="btn btn-primary" onClick={this.closeAppConfirmCancelDialogbox.bind(this)}>Ok</button></span>);
       let guarantoConfirmation = (<span>
                                    <button className="btn btn-primary" onClick={this.submitLoanApplication.bind(this, false)}>Yes</button>
                                    <button className="btn btn-primary" onClick={this.navigateToGuarantors.bind(this, false)}>No</button>
                                </span>);
        
        return(
            <div>
            <div>
                <Modal isOpen={this.state.isOpenMappingDialog} onRequestHide={this.closeMapping.bind(this, false)} backdrop={false}>
                    <ModalHeader>
                        <ModalClose onClick={this.closeMapping.bind(this, false)} />
                        <ModalTitle className="font-size-11px">Error - Unmapped Product(s)</ModalTitle>
                    </ModalHeader>
                    <ModalBody>
                        <label>The following Products don't have any collateral. Please select one or more collateral</label><br/>
                        <div>{renderGrid(displayProductList, headers, selectRowProp)}</div>
                    </ModalBody>
                    <ModalFooter>
                            <button className="btn btn-primary" onClick={this.closeMapping.bind(this, false)}>Ok</button>
                    </ModalFooter>
                </Modal>
            </div>
            <div className={(this.state.saving?"overlay-div":"")}> &nbsp; </div>
            {(this.state.saving?renderSpinner():"")} 
                {/*<div>
                    <FormField type="dialog" node={productMapping} isOpenDialog={this.state.isOpenMappingDialog} Message="Mapping" ModalTitle="Mapping" onClose={this.closeMapping.bind(this, false)} />
                </div>*/}
                <div>
                    <FormField type="dialog" node={guarantoConfirmation} isOpenDialog={this.state.isGuarantorDialog} Message="Do you want to submit the Loan Application without Guarantor(s)" ModalTitle="Guarantor(s)" onClose={this.closeGuarantorConfirmation.bind(this, false)} />
                </div>
                <div>
                    <FormField type="dialog" node={nodeConfirmation} isOpenDialog={this.state.isOpenDialog} Message={this.state.displayText} ModalTitle="Cancel" onClose={this.cancelDialogBox.bind(this, false)} />
                </div>
                <div>
                    <FormField type="dialog" node={nodeConfirmationCancel} isOpenDialog={this.state.isOpenCancelDialog} Message={this.state.displayText} ModalTitle="Cancel" onClose={this.closeAppConfirmCancelDialogbox.bind(this)} />
                </div>
                <div className="col-lg-12 mar-t-m-25px mar-b-15px pull-right pull-left-xs wid-100-per-xs pad-l-0px-xs pad-r-0px-xs">
                {((this.props.legalEntityCommonData != null && this.props.legalEntityCommonData != undefined)?(
                    <div className="row">
                      {((canEnableSubmit)?
                      (<div className="mar-l-m-30px wid-100-per-xs mar-b-10px" >
                                            <input type="checkbox" className="mar-l-0px" name="CreditPullAuthorization"
                                                               id="CreditPullAuthorization" onChange={this.OnChangeCheckBox.bind(this)}
                                                               />  {ADDITIONAL_INFORMATION.CREDIT_PULL_AUTHORIZATION}
                                            <br/>
                                            <input type="checkbox" className="mar-l-0px" name="ApplicationInformationConfirmation"
                                                                   id="ApplicationInformationConfirmation" onChange={this.OnChangeCheckBox.bind(this)}
                                                                   />  {ADDITIONAL_INFORMATION.APPLICATION_INFORMATION_CONFIRMATION}
                                </div>):"")}

                        <div className="pull-left pad-l-5px mar-l-m-30px btn-secondary mar-l-0px-xs wid-100-per-xs text-center-xs">
                           		 <span className="fa fa-times" aria-hidden="true"></span>
						 <input type="button" className="bg-clr-transparent br-none wid-55px pad-l-7px" onClick={this.cancelDialogBox.bind(this, true)} value="Cancel" />
                       </div>
                          <div className={"pull-right pad-r-5px mar-r-m-30px btn-primary pull-left-xs text-center-xs mar-t-10px-xs"+ ((this.state.submit)?"btn-disabled disabled":"")}>
                           		 <span className={"fa fa-check"+ ((this.state.submit)?"disabled":"")} aria-hidden="true"></span>
						 
                             <input type="button" className={"bg-clr-transparent br-none wid-55px pad-l-7px" + (this.state.submit?"disabled":"")}  onClick={this.onSubmitButtonClick.bind(this)} value="Submit" disabled={this.state.submit}/>
                        </div>
                    </div>):"")}
                </div>
            </div>
        );

    }
}

SubmitSection.propTypes = {
    actions: PropTypes.object.isRequired
};

SubmitSection.contextTypes = {
    router: PropTypes.object
};

let mapStateToProps = (state) => {
    return {
        loanAppInformation:state.loanAppReducer.LoanApplication,
        productCommonData: state.loanAppReducer.ProductCommonData,
        AdditionalInformation: state.loanAppReducer.LoanApplication.AdditionalInformation,
        productsList: state.loanAppReducer.LoanApplication.Products,
        legalEntityCommonData: state.loanAppReducer.LegalEntityCommonData,
        guarantorList: state.loanAppReducer.LoanApplication.Guarantors,
        collateralList: state.loanAppReducer.LoanApplication.Collaterals
    };
}

function mapDispatchToProps(dispatch) {
    return  {actions: bindActionCreators({SubmitLoanApplication, CancelLoanApplication},dispatch)};
}

export default connect(mapStateToProps,mapDispatchToProps)(SubmitSection);
