﻿/* React libraries */
import React from "react";

/* Constant components */
import {FOOTER_CONSTANT} from "../constants/ApplicationConstants";

const Footer = () => {
    return (
        <div className="col-lg-12 bg-clr-darknavy pad-t-20px-xs pad-t-0px-sms"><p
    className="text-center txt-clr-white pad-t-4px ht-32px ht-76px-sms ht-60px-xs mar-0px">&copy; {FOOTER_CONSTANT.FOOTER_TEXT}</p></div>
    );
};

export default Footer;
