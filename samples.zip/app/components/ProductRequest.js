/* React libraries */
import React, {Component, PropTypes} from "react";
import _ from 'lodash';
/* Constant components */
import {
    PRODUCTREQUEST_CONSTANT,
    POSITION,
    LEGEND_CONSTANT,
    VALIDATION_CONSTANT,
    PRODUCT_INTEGRATIONCODE
    } from "../constants/ApplicationConstants";

/* Child components libraries */
import {renderSection, renderAccordion, renderSpinner} from "./form-components/Form";
import FormField from "./form-components/FormField";

let horizontal = POSITION.HORIZONTAL;
let vertical = POSITION.VERTICAL;

class ProductRequest extends Component {

    onDoneClick(){
        if(this.props.onNextButtonClick)
            this.props.onNextButtonClick(this);
    }

    render() {
        const {onFieldChange, onFieldBlur, displayName, data, doValidate, commonData, isNextButtonDisable, hasError, isUseOfFundsDisable, maxValue, minValue, isBillPayerEnable, taxId, useOfFundsList} = this.props;
        return (
            <div>
                {renderSection(("Product Request " + (parseInt(displayName))), "panel", "pnl-sub-header-green width-40-per pad-4px font-size-14px bold mar-l-5px", "",
                    ([<div>
                        <form method="post" action="" name="productRequestForm" id="productRequestForm" ref="productRequestForm">
                              
                              {(isNextButtonDisable?renderSpinner():"")}
                            <fieldset className="brd-radius-3px mar-t-m-5px">
                                <div className="col-lg-12 pad-0px mar-0px">
                                    <div className="mar-l-5px mar-r-5px pnl-brd-darkgray brd-radius-10px pad-14px bg-clr-white">
                                        <FormField type="legend" displayText={LEGEND_CONSTANT.REQUIRED_FIELD} />
                                        <FormField type="legend" cssClass="clr-lbl font-size-11px italic" displayText={LEGEND_CONSTANT.EXPOSURE_MESSAGE} />

                                        <div className="row">
                                            <FormField columnSize={4} orientation={vertical} name="LoanType"
                                            defaultSelectValue={3} isDisabled={data.ProductId!=0?true:false}
                                                       dataTextField="Description" dataValueField="Id"
                                                       type="select-single" onFieldChange={onFieldChange}
                                                       displayText={PRODUCTREQUEST_CONSTANT.TYPE_OF_LOAN_REQUEST}
                                                       displayValue={commonData.LoanTypeList} 
                                                       isRequired={true} hasError={hasError} doValidate={doValidate}
                                                       errorMessage={VALIDATION_CONSTANT.LOAN_TYPE_ERROR}/>
                                            <FormField columnSize={4} dataTextField="ProductTypeDescription"
                                                       dataValueField="IntegrationCode"
                                                       defaultSelectValue={data.ProductType.IntegrationCode}
                                                       orientation={vertical} name="ProductType.IntegrationCode"
                                                       type="select-single" onFieldChange={onFieldChange}
                                                       displayText={PRODUCTREQUEST_CONSTANT.PRODUCT_TYPE}
                                                       displayValue={(_.find(commonData.ProductTypeList, ["IntegrationCode", data.ProductType.IntegrationCode])!=undefined && data.IsProductByBFNA==true)?
                                                                     (_.filter(commonData.ProductTypeList, ["ProductTypeCategory", _.find(commonData.ProductTypeList, ["IntegrationCode", data.ProductType.IntegrationCode]).ProductTypeCategory])):(commonData.ProductTypeList)}
                                                       isRequired={true} hasError={hasError} doValidate={doValidate}
                                                       errorMessage={VALIDATION_CONSTANT.PRODUCT_TYPE_ERROR}  />
                                        </div>

                                            {((data.ProductType.IntegrationCode == PRODUCT_INTEGRATIONCODE.ACH)?(
                                                <div className="row"><FormField columnSize={4} orientation={horizontal}
                                            name="IsPrefunding" type="radio" isRequired={true}
                                                                            onFieldChange={onFieldChange} hasError={hasError} doValidate={doValidate}
                                                                            displayText={PRODUCTREQUEST_CONSTANT.PRE_FUNDING}
                                                                            defaultOption={data.IsPrefunding}/>
                                            </div>):(<div></div>))}

    

    {((data.ProductType.IntegrationCode == PRODUCT_INTEGRATIONCODE.ACH && data.IsPrefunding != true && data.IsPrefunding != null) ? (
                                            <div className="row"><FormField columnSize={4} orientation={vertical}
                                            name="TotalCreditExposureLimit" type="currency"
                                                                            help="Determine the Total Credit  Exposure Limit by multiplying the number of expected daily transactions by the average amount per transaction.  Then multiply the result by 3.  If the business is growing you may want to add the annual growth rate to this total"
                                                                            faClass="fa-usd label-color font-size-14px bold"
                                                                            onFieldBlur={onFieldBlur}
                                                                            displayText={PRODUCTREQUEST_CONSTANT.TOTAL_CREDIT_EXPOSURE_LIMIT}
                                                                            displayValue={data.TotalCreditExposureLimit}
                                                                            isRequired={true} dollarFormat={true}
                                                                            hasError={hasError} doValidate={doValidate}
                                                                            minValue={VALIDATION_CONSTANT.DEBIT_CREDIT_MINVALUE}
                                                                            errorMessage={VALIDATION_CONSTANT.ENTER_AMOUNT_IN_RANGE}/>
                                                <FormField columnSize={4} orientation={vertical}
                                                           name="TotalDebitExposureLimit"
                                                           help="Determine the Debit Exposure Limit by multiplying the number of expected daily transactions by the average amount per transaction.  Then multiply the result by 2.  If the business is growing you may want to add the annual growth rate to this total"
                                                           type="currency" faClass="fa-usd label-color font-size-14px bold"
                                                           onFieldBlur={onFieldBlur}
                                                           displayText={PRODUCTREQUEST_CONSTANT.TOTAL_DEBIT_EXPOSURE_LIMIT}
                                                           displayValue={data.TotalDebitExposureLimit}
                                                           isRequired={true} dollarFormat={true}
                                                           minValue={VALIDATION_CONSTANT.DEBIT_CREDIT_MINVALUE}
                                                            hasError={hasError} doValidate={doValidate}
                                                           errorMessage={VALIDATION_CONSTANT.ENTER_AMOUNT_IN_RANGE}/>
                                            </div>) : (<div></div>))}

        {((data.ProductType.IntegrationCode == PRODUCT_INTEGRATIONCODE.FOREIGN_EXCHANGE || data.ProductType.IntegrationCode =="INT-DSL-FCE") ? (
                                                <div className="row"><FormField columnSize={5} orientation={vertical}
                                                name="DailySettlementLimitAmt" type="currency"
                                                                            faClass="fa-usd label-color font-size-14px bold"
                                                                            help="The (DSL) Daily Settlement Limit Amount is the dollar amount of the trade."
                                                                            onFieldBlur={onFieldBlur}
                                                                            displayText={PRODUCTREQUEST_CONSTANT.DAILY_SETTLEMENT_LIMIT_AMOUNT}
                                                                            displayValue={data.DailySettlementLimitAmt}
                                                                            isRequired={true} dollarFormat={true}
                                                                            hasError={hasError} doValidate={doValidate}
                                                                            minValue={VALIDATION_CONSTANT.DSL_FERL_MINVALUE}
                                                                            maxValue={VALIDATION_CONSTANT.DSL_FERL_MAXVALUE}
                                                                            errorMessage={VALIDATION_CONSTANT.ENTER_AMOUNT_IN_RANGE}/>
                                                <FormField columnSize={6} orientation={vertical}
                                                name="ForeignExchangeRiskLimitAmt" type="currency"
                                                           faClass="fa-usd label-color font-size-14px bold"
                                                           help="The (FERL) Foreign Exchange Risk Limit Amount is the Gross Hard Exposure to the Bank of a possible loss due to fluctuation in currency values related to Foreign Exchange."
                                                           onFieldBlur={onFieldBlur}
                                                           displayText={PRODUCTREQUEST_CONSTANT.FOREIGN_EXCHANGE_RIST_LIMIT_AMOUNT}
                                                           displayValue={data.ForeignExchangeRiskLimitAmt}
                                                           isRequired={true} dollarFormat={true}
                                                           hasError={hasError} doValidate={doValidate}
                                                           minValue={VALIDATION_CONSTANT.DSL_FERL_MINVALUE}
                                                           maxValue={VALIDATION_CONSTANT.DSL_FERL_MAXVALUE}
                                                           errorMessage={VALIDATION_CONSTANT.ENTER_AMOUNT_IN_RANGE}/>
                                            </div>) : (<div></div>))}

        {((data.ProductType.IntegrationCode != "-1" && data.ProductType.IntegrationCode != PRODUCT_INTEGRATIONCODE.FOREIGN_EXCHANGE && data.ProductType.IntegrationCode != "INT-DSL-FCE" && data.ProductType.IntegrationCode != PRODUCT_INTEGRATIONCODE.ACH  && data.ProductType.IntegrationCode!=PRODUCT_INTEGRATIONCODE.BUSINESS_REWARDS_MASTERCARD && data.ProductType.IntegrationCode!=PRODUCT_INTEGRATIONCODE.BUSINESS_MASTERCARD) ? (
                                            <div className="row"><FormField columnSize={4} orientation={vertical}
                                                                            name="RequestedAmount" ref="RequestedAmount"
                                                                            type="currency"
                                                                            faClass="fa-usd label-color font-size-14px bold"
                                                                            onFieldBlur={onFieldBlur}
                                                                            displayText={PRODUCTREQUEST_CONSTANT.AMOUNT_REQUESTED}
                                                                            displayValue={data.RequestedAmount}
                                                                            isRequired={true} dollarFormat={true}
                                                                            hasError={hasError} doValidate={doValidate}
                                                                            minValue={minValue}
                                                                            maxValue={maxValue}
                                                                            errorMessage={VALIDATION_CONSTANT.ENTER_AMOUNT_IN_RANGE} /></div>) : (<div></div>))}
        {((data.ProductType.IntegrationCode!=PRODUCT_INTEGRATIONCODE.BUSINESS_REWARDS_MASTERCARD && data.ProductType.IntegrationCode!=PRODUCT_INTEGRATIONCODE.BUSINESS_MASTERCARD)?(<div className="row">
                                        <FormField columnSize={4} orientation={vertical}
                                                                        name="UseOfFunds"
                                                                        defaultSelectValue={data.UseOfFunds}
                                                                        type="select-single" isRequired={true}
                                                                        dataTextField="Description"
                                                                        dataValueField="PurposeCode"
                                                                        onFieldChange={onFieldChange}
                                                                        displayText={PRODUCTREQUEST_CONSTANT.USE_OF_FUNDS_PURPOSE}
                                                                        displayValue={useOfFundsList}
                                                                        help="This explains how the business will be using loan proceeds."
                                                                        hasError={hasError} doValidate={doValidate}
                                                                        isDisabled={isUseOfFundsDisable} />
                                        </div>):(<div></div>))}

                                        {((data.ProductType.IntegrationCode == PRODUCT_INTEGRATIONCODE.ACH)?(
                                                   <div className="row">
                                                   <FormField columnSize={4} orientation={vertical} name="ACHRiskIDRoutingNumber"
                                                   type="select-single" onFieldChange={onFieldChange}
                                                   dataTextField="Description"
                                                   dataValueField="Id"
                                            displayText={PRODUCTREQUEST_CONSTANT.ACH_RISK_ROUTING_NUMBER}
                                            displayValue={data.ACHRiskIDRoutingNumberList} />
                                                <FormField columnSize={4} orientation={vertical} name="ACHRiskIDTaxIDNumber"
                                                                                       type="text" onFieldBlur={onFieldBlur}
                                                                                       displayText={PRODUCTREQUEST_CONSTANT.ACH_RISK_ID_TAX_ID_NUMBER}
                                                                                       displayValue={taxId} />
                                     </div>):(<div></div>))}

                                        {((data.ProductType.IntegrationCode != PRODUCT_INTEGRATIONCODE.ACH && data.ProductType.IntegrationCode != PRODUCT_INTEGRATIONCODE.COMMERCIAL_CARD && data.ProductType.IntegrationCode != PRODUCT_INTEGRATIONCODE.FOREIGN_EXCHANGE && data.ProductType.IntegrationCode != PRODUCT_INTEGRATIONCODE.LETTER_OF_CREDIT && data.ProductType.IntegrationCode != PRODUCT_INTEGRATIONCODE.BUSINESS_MASTERCARD && data.ProductType.IntegrationCode != PRODUCT_INTEGRATIONCODE.BUSINESS_REWARDS_MASTERCARD) ? (
                                        <div className="row"><FormField columnSize={4} orientation={horizontal}
                                                                        name="IsRefinancingExistingDebit" type="radio"
                                                                        onFieldChange={onFieldChange}
                                                                        displayText={PRODUCTREQUEST_CONSTANT.REFINANCING_EXISTING_DEBT}
                                                                        defaultOption={data.IsRefinancingExistingDebit}/>
                                        </div>) : (<div></div>) )}
                                        {((data.ProductType.IntegrationCode != PRODUCT_INTEGRATIONCODE.ACH || data.ProductType.IntegrationCode != PRODUCT_INTEGRATIONCODE.COMMERCIAL_CARD || data.ProductType.IntegrationCode != PRODUCT_INTEGRATIONCODE.FOREIGN_EXCHANGE || data.ProductType.IntegrationCode != PRODUCT_INTEGRATIONCODE.LETTER_OF_CREDIT || data.ProductType.IntegrationCode != PRODUCT_INTEGRATIONCODE.BUSINESS_MASTERCARD || data.ProductType.IntegrationCode != PRODUCT_INTEGRATIONCODE.BUSINESS_REWARDS_MASTERCARD) ? (
                                        <div>
                                        {((data.IsRefinancingExistingDebit == true) ? (
                                            <div className="row"><FormField columnSize={4} orientation={horizontal}
                                                                            name="IsDebtRefinancingFifthThird"
                                                                            type="radio"
                                                                            onFieldChange={onFieldChange}
                                                                            displayText={PRODUCTREQUEST_CONSTANT.IS_DEBT_BEING_REFINANCED_FIFTH_THIRD_DEBT}
                                                                            defaultOption={data.IsDebtRefinancingFifthThird}/>
                                            </div>) : (<div></div>))}
                                                                            {((data.IsRefinancingExistingDebit == true  && data.IsDebtRefinancingFifthThird != null) ? (
                                            <div>
                                        {((data.IsRefinancingExistingDebit == true && data.IsDebtRefinancingFifthThird == true) ? (
                                            <div className="row"><FormField columnSize={4} orientation={vertical}
                                                                            name="AmtOfFtbTotalHardExposureBeingRefinanced"
                                                                            type="currency"
                                                                            faClass="fa-usd label-color font-size-14px bold"
                                                                            onFieldBlur={onFieldBlur}
                                                                            displayText={PRODUCTREQUEST_CONSTANT.AMOUNT_FIFTH_THIRD_HARDEXPOSURE_BEING_REFINANCED}
                                                                            displayValue={data.AmtOfFtbTotalHardExposureBeingRefinanced} />
                                                <FormField columnSize={4} orientation={vertical}
                                                           name="AmtOfFtbTotalSoftExposureBeingRefinanced" type="currency"
                                                           faClass="fa-usd label-color font-size-14px bold"
                                                           onFieldBlur={onFieldBlur}
                                                           displayText={PRODUCTREQUEST_CONSTANT.AMOUNT_FIFTH_THIRD_SOFTEXPOSURE_BEING_REFINANCED}
                                                           displayValue={data.AmtOfFtbTotalSoftExposureBeingRefinanced} />

                                                    <FormField columnSize={4} orientation={vertical} name="AccountNumber"
                                                    type="select-single" onFieldChange={onFieldChange}
                                                    displayText={PRODUCTREQUEST_CONSTANT.ACCOUNT_NUMBER}
                                                    displayValue={[]} />
                                            </div>) : (
                                            <div className="row"><FormField columnSize={4} orientation={vertical}
                                                                            name="AmtOfNonFtbTotalHardExposureBeingRefinanced"
                                                                            type="currency"
                                                                            faClass="fa-usd label-color font-size-14px bold"
                                                                            onFieldBlur={onFieldBlur}
                                                                            displayText={PRODUCTREQUEST_CONSTANT.AMOUNT_NON_FIFTH_THIRD_HARDEXPOSURE_BEING_REFINANCED}
                                                                            displayValue={data.AmtOfNonFtbTotalHardExposureBeingRefinanced}/>
                                                <FormField columnSize={4} orientation={vertical}
                                                           name="AmtOfNonFtbTotalSoftExposureBeingRefinanced"
                                                           type="currency" faClass="fa-usd label-color font-size-14px bold"
                                                           onFieldBlur={onFieldBlur}
                                                           displayText={PRODUCTREQUEST_CONSTANT.AMOUNT_NON_FIFTH_THIRD_SOFTEXPOSURE_BEING_REFINANCED}
                                                           displayValue={data.AmtOfNonFtbTotalSoftExposureBeingRefinanced}/><FormField
                                                    columnSize={4} orientation={vertical} name="FinancialInstitution"
                                                    type="text" onFieldBlur={onFieldBlur}
                                                    displayText={PRODUCTREQUEST_CONSTANT.FINANCIAL_INSTITUTION}
                                                    displayValue={data.FinancialInstitution}/>
                                            </div>))} </div> ) : (''))} </div>) : (<div></div>) )}


                                            {((data.ProductType.IntegrationCode == PRODUCT_INTEGRATIONCODE.COMMERCIAL_REAL_ESTATE  || data.ProductType.IntegrationCode == PRODUCT_INTEGRATIONCODE.LINE_OF_CREDIT || data.ProductType.IntegrationCode == PRODUCT_INTEGRATIONCODE.TERM_LOAN) ? (
                                             <div className="row"><FormField columnSize={4} orientation={horizontal}
                                                name="SBA" type="radio"
                                                onFieldChange={onFieldChange}
                                                displayText={PRODUCTREQUEST_CONSTANT.SBA}
                                                defaultOption={data.SBA}/>
                </div>) : (<div></div>))}
                                            

                                            {((data.ProductType.IntegrationCode!=PRODUCT_INTEGRATIONCODE.BUSINESS_REWARDS_MASTERCARD && data.ProductType.IntegrationCode!=PRODUCT_INTEGRATIONCODE.BUSINESS_MASTERCARD)?(<div className="row"><FormField columnSize={4} orientation={horizontal}
                                                name="IsPurposeFarmRelated" type="radio"
                                                onFieldChange={onFieldChange} hasError={hasError} doValidate={doValidate}
                                                displayText={PRODUCTREQUEST_CONSTANT.IS_PURPOSE_FARM_RELATED}
                                                defaultOption={data.IsPurposeFarmRelated}
                                                isRequired={true}/></div>):(<div></div>))}
                                        {/*<div className="row"><FormField columnSize={12} orientation={horizontal}
                                                                        name="IsAnyRegOInsidersAssociated" type="radio"
                                                                        onFieldChange={onFieldChange}
                                                                        displayText={PRODUCTREQUEST_CONSTANT.IS_ANY_REG_O_INSIDERS_ASSOCIATED_WITH_THIS_REQUEST}
                                                                        help="Is there any Reg O (insider) associated with this loan request?"
                                                                        defaultOption={data.IsAnyRegOInsidersAssociated}/>
                                        </div>*/}


                                        <div className="row">
                                        <FormField columnSize={4} orientation={vertical} name="PromoCode"
                                                       type="text" onFieldBlur={onFieldBlur}
                                                       displayText={PRODUCTREQUEST_CONSTANT.PROMO_CODE}
                                                       displayValue={data.PromoCode}
                                                       isAlphaNumericFormat={true} digitLength={16} maxLength={16}
                                                       hasError={hasError} doValidate={doValidate}
                                                       errorMessage={VALIDATION_CONSTANT.PROMO_CODE_ERROR}/>
                                        </div>
                                    
                                        {(!isBillPayerEnable)?(renderAccordion('fa fa-user-circle', (PRODUCTREQUEST_CONSTANT.BILL_PAYER_SELECTION), "panel accordion-brd-color font-size-12px", "accordion-panel pad-4px bold", (
                                                <input type="checkbox" className="mar-l-5px" name="IsBillPayerRegistered"
                                                       id="IsBillPayerRegistered"
                                                       value={data.IsBillPayerRegistered}
                                                       defaultChecked={data.IsBillPayerRegistered}
                                                       onChange={onFieldChange}/>), "",
                                            ((data.IsBillPayerRegistered) ? (([
                                                <div className="row">
                                                    <FormField columnSize={4} orientation={vertical}
                                                               name="BillPayer.DdaOrSavNumber" type="select-single"
                                                               onFieldChange={onFieldChange}
                                                               displayText={PRODUCTREQUEST_CONSTANT.DDA_SAV}
                                                               displayValue={data.BillPayer.DdaOrSavNumberList}/>
                                                    <FormField columnSize={4} orientation={vertical}
                                                               name="BillPayer.RoutingNumber" type="text"
                                                               onFieldBlur={onFieldBlur}
                                                               displayText={PRODUCTREQUEST_CONSTANT.ROUTING_NUMBER}
                                                               displayValue={data.BillPayer.RoutingNumber}/>
                                                    <FormField columnSize={4} orientation={vertical}
                                                               name="BillPayer.AccountNumber" type="text"
                                                               onFieldBlur={onFieldBlur}
                                                               displayText={PRODUCTREQUEST_CONSTANT.ACCOUNT_NUMBER}
                                                               displayValue="" />
                                                </div>
                                              ])) : (<div></div>))
                                        )):('')}


                                        <div className="row">
                                           <div className="pull-right pull-left-sm pad-r-5px mar-r-5px btn-primary bg-btn-clr-navy text-center-xs ">
                           		 <span className=" fa fa-lg fa-floppy-o" aria-hidden="true"></span>
						  <input type="button" className="bg-clr-transparent br-none wid-55px pad-l-7px"  value="Save"
                                                       onClick={this.onDoneClick.bind(this)} disabled={isNextButtonDisable}/>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </fieldset>
                            <div className={(isNextButtonDisable?"overlay-div":"")}> &nbsp; </div>
                        </form>
                    </div>]))}
            </div>);
    }
}

export default ProductRequest;
