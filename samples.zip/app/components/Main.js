﻿/*eslint-disable no-undef */
/* React libraries */
import React, { Component, PropTypes } from "react";
import { bindActionCreators } from "redux";
import {connect} from "react-redux";

/* Action components */
import {GetSearchResults} from "../actions/searchAction";

/* Child components libraries */
import FormField from "./form-components/FormField";
import {renderSpinner} from "./form-components/Form";
import {APPLICATION_URL} from "../constants/ApplicationURL";

/* LoanApp libraries */
import {showError} from "../utils/Functions";


class Main extends Component {
    constructor(props, context) {
        super(props, context);
        this.state={
            ajaxCallsInProgress:true
        };
    }

    /* component lifecycle methods start */
    componentDidMount(){
        let customerName="", SSNTIN="";
        if(this.props.legalEntityDetails.StructureCode!="I")
        {
            customerName=this.props.legalEntityDetails.LegalName;
            SSNTIN=this.props.legalEntityDetails.SocialSecurityNumber;
        }
        else
        {
            customerName= this.props.legalEntityDetails.FirstName + " " + this.props.legalEntityDetails.MiddleName + " " + this.props.legalEntityDetails.LastName;
            SSNTIN=this.props.legalEntityDetails.SocialSecurityNumber;
        }
        this._GetSearchResults(SSNTIN, customerName);
    }
    /* component lifecycle methods end */

    /* action methods start */
    _GetSearchResults(SSNTIN, customerName)
    {
        this.props.actions.GetSearchResults(SSNTIN, customerName, 1)
              .then(() => {
                  if(this.props.searchResults.length==0)
                  {
                      this.context.router.push(APPLICATION_URL.BORROWER_URL+ "add");
                  }
                  else if(this.props.searchResults.length==1)
                  {
                      if(this.props.searchResults[this.props.searchResults.length-1].LegalEntityId>0)
                      {
                          this.context.router.push(APPLICATION_URL.BORROWER_URL+this.props.searchResults[this.props.searchResults.length-1].LegalEntityId);
                      }
                  }
                  else
                  {
                      this.context.router.push(APPLICATION_URL.SEARCH_URL);
                  }
                  this.setState({ajaxCallsInProgress:false});
              }).catch(error => {
                  console.log(error.response.data.ExceptionMessage);
              });
    }
    /* action methods end */

    render() {
        if(this.state.ajaxCallsInProgress)
            return (renderSpinner());
    }
}

Main.propTypes = {
    searchResults: PropTypes.object.isRequired,
    legalEntityDetails: PropTypes.object.isRequired,
    actions: PropTypes.object.isRequired
};

Main.contextTypes = {
    router: PropTypes.object
};

let mapStateToProps = (state) => {
    return {
        searchResults:state.loanAppReducer.SearchResults,
        legalEntityDetails: state.loanAppReducer.LoanAppInputData.Borrower,
    }
}

function mapDispatchToProps(dispatch) {
    return  {actions: bindActionCreators({GetSearchResults}, dispatch)};
}

export default connect(mapStateToProps,mapDispatchToProps)(Main);