/* React libraries */
import React, {Component, PropTypes} from "react";

/* Constant components */
import {
    ADDITIONAL_INFORMATION,
    POSITION,
    LEGEND_CONSTANT,
    FORMAT_CONSTANT,
    VALIDATION_CONSTANT
} from "../constants/ApplicationConstants";

/* Child components libraries */
import {renderSection, renderAccordion} from "./form-components/Form";
import FormField from "./form-components/FormField";

class AdditionalInformation extends Component {
    onDoneClick(e) {
            if (this.props.onNextButtonClick) {
                this.props.onNextButtonClick(this);
            }
    }

    render() {
        const {additionalInfo, onFieldChange, onNextButtonClick, displayGroupEmail, onFieldBlur, whichEntity, doValidate, hasError}=this.props;
        let horizontal = POSITION.HORIZONTAL;
        let vertical = POSITION.VERTICAL;

        return (
            <div>
                {renderSection(ADDITIONAL_INFORMATION.ADDITIONAL_INFORMATION_HEADER, "panel", "pnl-sub-header-green width-30-per pad-4px font-size-14px bold mar-l-5px", "",
                    ([<div>
                        <form method="post" action="" key="additionalInformationForm" name="additionalInformationForm"
                              id="additionalInformationForm" ref="additionalInformationForm">
                            <fieldset className="brd-radius-3px mar-t-m-5px">
                                <div className="col-lg-12 pad-0px mar-0px">
                                    <div
                                        className="row mar-l-5px mar-r-5px pnl-brd-darkgray brd-radius-10px pad-14px pad-t-0px pad-b-0px">
                                        <div className="row pad-t-0px pad-b-0px"><FormField type="legend"
                                                                                            displayText={LEGEND_CONSTANT.REQUIRED_FIELD}/>
                                        </div>
                                        <div className="pad-b-5px pad-l-5px pad-r-5px font-size-11px">

                                            {renderAccordion('fa ', (<div><span>{ADDITIONAL_INFORMATION.ADDITIONAL_RECIPIENT_EMAIL_COOMUNICATION}</span><br/><span className="font-size-10px font-weight-normal-LA">{ADDITIONAL_INFORMATION.ADDITIONAL_RECIPIENT_EMAIL_COOMUNICATION_SUB}</span></div>), "panel accordion-brd-color font-size-12px", "accordion-panel pad-4px bold", "", "",
                                                (<div>

                                                    <div className="row">
                                                        <FormField columnSize={4} orientation={vertical}
                                                                   key="RecipientOfEmailCommunication"
                                                                   name="RecipientOfEmailCommunication"
                                                                   type="label-group"
                                                                   displayText={ADDITIONAL_INFORMATION.RECIPIENT_EMAIL_COMMUNICATION}
                                                                   displayValue={additionalInfo.RecipientEmail}/>

                                                    </div>
                                                    <div className="row pad-l-14px">
                                                        <FormField type="label" cssClass="clr-lbl"
                                                                   value={ADDITIONAL_INFORMATION.ADDITIONAL_RECIPENT_EMAIL_COMMUNICATION}/>
                                                    </div>
                                                    <div className="row">
                                                          {(displayGroupEmail) ?
                                                            (<div className="col-md-4"><label className="clr-black font-size-15px">{additionalInfo.GroupEmail}</label></div>):("")}
                                                        <FormField columnSize={4} orientation={vertical}
                                                                   key="AdditionalRecipient1Email"
                                                                   name="AdditionalRecipient1Email"
                                                                   faClass="fa-envelope label-color" type="email" emailFormat={true}
                                                                   dispalyValue={additionalInfo.AdditionalRecipient1Email}
                                                                   hasError={hasError} doValidate={doValidate}
                                                                   errorMessage={VALIDATION_CONSTANT.ADDITIONAL_INFO_EMAIL_MESSAGE} onFieldBlur={onFieldBlur} />
                                                        <FormField columnSize={4} orientation={vertical}
                                                                   key="AdditionalRecipient2Email"
                                                                   name="AdditionalRecipient2Email"
                                                                   faClass="fa-envelope label-color" type="email" emailFormat={true}
                                                                   dispalyValue={additionalInfo.AdditionalRecipient2Email}
                                                                   hasError={hasError} doValidate={doValidate}
                                                                   errorMessage={VALIDATION_CONSTANT.ADDITIONAL_INFO_EMAIL_MESSAGE} onFieldBlur={onFieldBlur} />
                                                    </div>
                                                </div>)
                                            )}

                                        </div>
                                                            <div className="pad-b-5px pad-l-5px pad-r-5px font-size-11px">
                                                                {renderAccordion('fa ', (<div><span>{ADDITIONAL_INFORMATION.ADDITIONAL_PRIMARY_CONTACT}</span><br/><span className="font-size-10px font-weight-normal-LA">{ADDITIONAL_INFORMATION.ADDITIONAL_PRIMARY_CONTACT_SUB}</span></div>), "panel accordion-brd-color font-size-12px", "accordion-panel pad-4px bold", "", "",
                                                                    ([<div>
                                                                    <div className="row">


                                                                 <div className="row">
                                                                 <FormField columnSize={4} orientation={vertical}
                                                                    key="PrimaryContactFirstName"
                                                                    name="PrimaryContactFirstName" type="text"
                                                                    displayText={ADDITIONAL_INFORMATION.PRIMARY_CONTACT_FIRST_NAME}
                                                                    displayValue={additionalInfo.PrimaryContactFirstName} onFieldBlur={onFieldBlur} />
                                                         <FormField columnSize={4} orientation={vertical}
                                                                    key="PrimaryContactLastName"
                                                                    name="PrimaryContactLastName" type="text"
                                                                    displayText={ADDITIONAL_INFORMATION.PRIMARY_CONTACT_LAST_NAME}
                                                                    displayValue={additionalInfo.PrimaryContactLastName} onFieldBlur={onFieldBlur} />

                                                            <FormField columnSize={4} orientation={vertical}
                                                                    key="PrimaryContactEmailAddress"
                                                                    name="PrimaryContactEmailAddress"
                                                                    faClass="fa-envelope label-color" type="email"
                                                                    displayText={ADDITIONAL_INFORMATION.PRIMARY_CONTACT_EMAIL_ADDRESS}
                                                                    displayValue={additionalInfo.PrimaryContactEmailAddress}
                                                                    hasError={hasError} doValidate={doValidate}
                                                                    errorMessage={VALIDATION_CONSTANT.EMAIL_MESSAGE} onFieldBlur={onFieldBlur} />

                                                                    </div> 
                                                                 <FormField columnSize={4} orientation={vertical}
                                                                    key="PrimaryContactPhoneNumber"
                                                                    name="PrimaryContactPhoneNumber"
                                                                    faClass="fa-phone label-color" type="phone"
                                                                    dataMask={FORMAT_CONSTANT.US_PHONE_NUMBER_MASK}
                                                                    displayText={ADDITIONAL_INFORMATION.PRIMARY_CONTACT_PHONE_NUMBER}
                                                                    displayValue={additionalInfo.PrimaryContactPhoneNumber} isPhoneNumber={true}
                                                                    hasError={hasError} doValidate={doValidate} onFieldBlur={onFieldBlur} />
                                                     </div>
                                                   </div>])
                                                         )}
                                                     </div>
                                                                                <div className="pad-b-5px pad-l-5px pad-r-5px font-size-11px">
                                                                                    {renderAccordion('fa fa-newspaper-o', (ADDITIONAL_INFORMATION.LOAN_APP_SPECIAL_INSTRUCTION), "panel accordion-brd-color font-size-12px", "accordion-panel pad-4px bold", "", "",
                                                                                        (<div>
                                                                                        <div className="row">
                                                                                         <FormField columnSize={5} orientation={vertical}
                                                                                        name="WhichEntities" type="select-single"
                                                                                        defaultSelectValue={(additionalInfo.WhichEntities == undefined) ? -1: additionalInfo.WhichEntities}
                                                                            displayText={ADDITIONAL_INFORMATION.WHICH_ENTITIES}
    displayValue={whichEntity} isRequired={true}
    hasError={hasError} doValidate={doValidate} onFieldChange={onFieldChange} />
                </div>
                        <div className="row">
                            <FormField columnSize={12} orientation={vertical}
                key="SpecialInstructions"
                name="SpecialInstructions" type="textarea"
                rows="3" cols="15"
                displayText={ADDITIONAL_INFORMATION.SPECIAL_INSTRUCTION}
                displayValue={additionalInfo.SpecialInstructions}
                maxLength={250}
                hasError={hasError} doValidate={doValidate}
                errorMessage={VALIDATION_CONSTANT.SPECIALINSTRUCTION_ERROR} onFieldBlur={onFieldBlur} />
 </div>
                                                    
</div>
                )
            )}
        </div>
        <div className="pull-right pad-r-5px mar-r-5px btn-primary bg-btn-clr-navy">
            <span className=" fa fa-lg fa-floppy-o" aria-hidden="true"></span>
            <input type="button"
        className="bg-clr-transparent br-none wid-55px pad-l-7px"
        value="Save" onClick={this.onDoneClick.bind(this)}/>
</div>
</div>
</div>
</fieldset>
</form>
</div>]))}
            </div>);
    }
}

export default AdditionalInformation;
