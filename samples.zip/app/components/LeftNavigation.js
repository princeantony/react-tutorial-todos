/*eslint-disable import/default */
/* React libraries */
import React, { PropTypes, Component } from "react";
import { Link } from "react-router";
import { connect } from "react-redux";
import {bindActionCreators} from "redux";

/* Plugin libraries */
import _ from "lodash";

/* Constant components */
import {MESSAGE_CONSTANT, DISCLOSURE_LINKS} from "../constants/ApplicationConstants";
import {APPLICATION_URL} from "../constants/ApplicationURL";

/* LoanApp libraries */
import {GetOwners, GetGuarantorOwners} from "../actions/ownerAction";
import {showSuccess, showWarning, showError, getDisclosures, getPath, reArrangeDisplayNameProperty} from "../utils/Functions";

/* Child components libraries */
import LeftNavItems from "./child-components/LeftNavItems";
import {renderSpan} from "./form-components/Form";
import ConfirmWindow from "../containers/DialogContainer";
import FormField from "./form-components/FormField";

/* Action components */
import {RemoveCollateral} from "../actions/collateralAction";
import {RemoveCardholderLegalEntity} from '../actions/cardholderAction';
import {RemoveBorrowerOwner, RemoveGuarantorOwner, RemoveGuarantor} from "../actions/ownerAction";
import {RemoveProduct} from "../actions/productAction";
import {LeftNavigationControlIsDirty} from "../actions/commondataAction";


/* Variable declaration start */
let isDialogYesClicked = false;
let currentIndex = 0;
let childIndex = 0;
let fromItem = "";
/* Variable declaration end */

class LeftNavigation extends Component {
    constructor(props, context) {
        super(props, context);
        this.state={
            isBorrowerCollapsed:true,
            isOwnerCollapsed:true,
            isProductCollapsed:true,
            isGuarantorCollapsed:true,
            isCollateralCollapsed:true,
            isCollateralDisable:true,
            isCardholderDisable:true,
            isOwnerControlsEnable:true,
            isajaxcallInProgress:false,
            isCardholderCollapsed:true,
            isOpenDialog: false,
            isAdditionalInformationSaved: false,
            activeTab: "Borrower",
            savedStatus:(this.props.savedStatus == undefined?{Borrower: false}:Object.assign({}, props.savedStatus)),
            isDirtyStatus: false,
            linkUrl: '',
            index: 0,
            parentIndex:0,
            displayText:'',
            isNavDialog:false
        };
    }

    /* component lifecycle methods start */
    componentWillReceiveProps(nextProps){
        if(this.props.productsList!=nextProps.productsList)
        {
            this.setState({isCollateralDisable : this.isLeftNavDisable(nextProps.productsList, "BLC")});
            this.setState({isCardholderDisable : this.isLeftNavDisable(nextProps.productsList, "BCC")});
        }
        if(this.props.additionalInformation != nextProps.additionalInformation)
        {
            this.setState({isAdditionalInformationSaved: true});
        }
            if(this.props.savedStatus != nextProps.savedStatus)
            {
                this.setState({savedStatus : nextProps.savedStatus});
            }
            if(this.props.isDirtyStatus!=nextProps.isDirtyStatus)
            {
                this.setState({isDirtyStatus: nextProps.isDirtyStatus});
            }
    }

    /* component lifecycle methods end */
    onYesClick(){
        this.setState({activeTab: this.state.displayText, isNavDialog:false});
        let _casePath=getPath(this.state.linkUrl);
        this.context.router.push(APPLICATION_URL.LOANAPP_ROUTE+ _casePath + "/" + this.state.index + "/" + this.state.parentIndex);
        this.props.actions.LeftNavigationControlIsDirty(false);
    }

    onNoClick(){
        this.setState({isNavDialog:false});
        this.props.actions.LeftNavigationControlIsDirty(true);
    }



    checkOwnersList(ownersList){
        return ((_.some(ownersList, ['IsExisting', true]))?(true):((_.some(ownersList, ['RelatedEntity.IsNew', true]))?false:true));
    }

    isBCCOrBLCProductExist(productList){
        this.setState({isCollateralDisable : this.isLeftNavDisable(productList, "BLC")});
        this.setState({isCardholderDisable : this.isLeftNavDisable(productList, "BCC")});
    }

    onOwnersClick(activeText){
        this.setState({activeTab: activeText});
        this.setState({isOwnerCollapsed:!this.state.isOwnerCollapsed});
        if(this.props.ownersList.length==0)
        {
            this.setState({isajaxcallInProgress:true});
            this.props.actions.GetOwners(this.props.borrowerInformation.Id).then(()=>{
                this.setState({isOwnerControlsEnable:((this.props.ownersList!=null && this.props.ownersList.length>0)?false:true)});
                this.setState({isajaxcallInProgress:false});
            }).catch(error=>{
                this.setState({isajaxcallInProgress:false});
                console.log(error.response.data.ExceptionMessage);
            });
        }
    }

    onProductsClick(activeText){
        this.setState({isProductCollapsed:!this.state.isProductCollapsed});
        this.setState({activeTab: activeText});
    }

    onGuarantorsClick(activeText){
        this.setState({isGuarantorCollapsed:!this.state.isGuarantorCollapsed});
        this.setState({activeTab: activeText});
    }

    onCollateralClick(activeText){
        this.setState({isCollateralCollapsed:!this.state.isCollateralCollapsed});
        this.setState({activeTab: activeText});
    }

    onCardholderClick(activeText){
        this.setState({isCardholderCollapsed:!this.state.isCardholderCollapsed});
        this.setState({activeTab: activeText});
    }

    onGuarantorOwnerClick(id, index){
        ((this.props.guarantorList[index].isCollapsed!=undefined)?_.set(this.props.guarantorList[index], 'isCollapsed', !this.props.guarantorList[index].isCollapsed):_.set(this.props.guarantorList[index],'isCollapsed',false));
        this.forceUpdate();
        if(this.props.guarantorList[index].RelatedEntity.OwnershipTies.length==0)
        {
            this.setState({isajaxcallInProgress:true});
            this.props.actions.GetGuarantorOwners(id, index).then(()=>{
                _.set(this.props.guarantorList[index], 'isShowControls',((this.props.guarantorList[index].RelatedEntity.OwnershipTies!=null && this.props.guarantorList[index].RelatedEntity.OwnershipTies.length>0)?false:true));
                this.setState({isajaxcallInProgress:false});
            }).catch(error=>{
                this.setState({isajaxcallInProgress:false});
                console.log(error.response.data.ExceptionMessage);
            });
        }
    }

    isLeftNavDisable(productList, typeOfProduct)
    {
        let _product=_.find(productList,   function(o) { return o.Type == typeOfProduct && o.ProductId!=0});
        return (_product!=undefined && _product!=null && _product.ProductId!=0)?false:true;
    }

    handleDialogYesClick(isYesClicked)
    {
        this.setState({isOpenDialog: false});
        if(isYesClicked)
        {
            switch(fromItem)
            {
                case 'Borrower Owner(s)' : this.onRemoveBorrowerOwnerList(currentIndex);
                    break;

                case 'Guarantors' : this.onRemoveGuarantorList(currentIndex);
                    break;

                case 'Collateral' : this.onRemoveCollateralList(currentIndex);
                    break;

                case 'Cardholder' : this.onRemoveCardholderList(currentIndex);
                    break;

                case 'Guarantor' : this.onRemoveGuarantorOwnerList(currentIndex, childIndex);
                    break;

                case 'Products' : this.onRemoveProductList(currentIndex);
                    break;
            }
        }
    }

    onDisclosureLinkClick(isViewed, url)
    {
        if(this.props.onDisclosureLinkClick)
        {
            this.props.onDisclosureLinkClick(isViewed);
        }
        window.open(url,'_blank');
    }

    getDisclosures()
    {
        let _disclosuresList = getDisclosures(this.props.productsList);
        return _disclosuresList.map((product, index)=>{
            let url="#";
            if(product.IntegrationCode=="BLOC")
            {
                url=DISCLOSURE_LINKS.LOC_PRODUCT;
                return(<div><a className="link cursor-pointer" onClick={this.onDisclosureLinkClick.bind(this, true, url)}>{_.find(this.props.productTypeList, ['IntegrationCode', product.IntegrationCode]).ProductTypeDescription}</a><br/></div>);
        }
        else if(product.IntegrationCode=="MASTERCARD" && product.LoanType!=3)
        {
            url =(product.LoanType==20)?(DISCLOSURE_LINKS.MASTERCARD_INCREASE):(DISCLOSURE_LINKS.MASTERCARD_NON_INCREASE);
            return(<div><a className="link cursor-pointer" onClick={this.onDisclosureLinkClick.bind(this, true, url)}>{_.find(this.props.productTypeList, ['IntegrationCode', product.IntegrationCode]).ProductTypeDescription}</a><br/></div>);
    }
            else if(product.IntegrationCode=="MASTERCARD-TRAV" && product.LoanType!=3)
            {
                url =(product.LoanType==20)?(DISCLOSURE_LINKS.REWARD_MASTER_CARD_INCREASE):(DISCLOSURE_LINKS.REWARD_MASTER_CARD_NON_INCREASE);
                return(<div><a className="link cursor-pointer" onClick={this.onDisclosureLinkClick.bind(this, true, url)}>{_.find(this.props.productTypeList, ['IntegrationCode', product.IntegrationCode]).ProductTypeDescription}</a><br/></div>);
                }
    });
}

removeCardholders(productList){
    let _product=_.find(productList,   function(o) { return o.Type == "BCC"});
    if(_product==undefined || _product==null)
    {
        if(this.props.cardholderList.length>0)
        {
            this.props.cardholderList=[];
            this.props.actions.RemoveCardholderLegalEntity(this.props.cardholderList);
        }
    }
}

    onLeftMenuClick(linkUrl, index, parentIndex, displayText)
    {
       if(this.state.isDirtyStatus==true)
        {
           this.setState({isNavDialog:true});
            this.state.linkUrl=linkUrl;
            this.state.index= index;
            this.state.parentIndex=parentIndex;
            this.state.displayText=displayText;
        }
        else
       {
           this.setState({isNavDialog:false, activeTab: displayText});
            let _casePath=getPath(linkUrl);
            this.context.router.push(APPLICATION_URL.LOANAPP_ROUTE+ _casePath + "/" + index + "/" + parentIndex);
       }
    }

onCommonRemoveClick(_index,_from,_childIndex)
{
    currentIndex = _index;
    fromItem = _from;
    childIndex = _childIndex;
    this.setState({isOpenDialog: true});
}

onRemoveCollateralList(index){
    if(this.props.collateralList.length>0)
    {
        this.props.actions.RemoveCollateral(this.props.collateralList, index).then(() => {
            showSuccess(MESSAGE_CONSTANT.COLLATERAL_REMOVE_SUCCESS);
            this.onLeftMenuClick(APPLICATION_URL.COLLATERAL, 0, 0, "");
            this.forceUpdate();
        }).catch(error => {
            console.log(error.response.data.ExceptionMessage);
        });
    }
}

onRemoveCardholderList(index){
    if(this.props.cardholderList.length>1)
    {
        this.onLeftMenuClick(APPLICATION_URL.CARDHOLDER, 0, 0);
        this.props.cardholderList.splice(index, 1);
        this.props.actions.RemoveCardholderLegalEntity(this.props.cardholderList);
        showSuccess(MESSAGE_CONSTANT.CARDHOLDER_REMOVE_SUCCESS);
        this.forceUpdate();
    }
}

onRemoveBorrowerOwnerList(index){
    if(!this.props.ownersList[index].IsNew)
    {
        this.context.router.push(APPLICATION_URL.BORROWER_OWNER_SEARCH_CRITERIA + 'BO');
        this.props.actions.RemoveBorrowerOwner(this.props.ownersList, index).then(() => {
            this.forceUpdate();
            showSuccess(MESSAGE_CONSTANT.OWNER_REMOVE_SUCCESS);
        }).catch(error => {
            console.log(error.response.data.ExceptionMessage);
        });
    }
    else
    {
        this.context.router.push(APPLICATION_URL.BORROWER_OWNER_SEARCH_CRITERIA + 'BO');
        this.props.ownersList.splice(index, 1);
        this.forceUpdate();
        showSuccess(MESSAGE_CONSTANT.OWNER_REMOVE_SUCCESS);
    }
}

onRemoveGuarantorOwnerList(parentIndex, childIndex){
    if(!this.props.guarantorList[parentIndex].RelatedEntity.OwnershipTies[childIndex].IsNew)
    {
        this.context.router.push(APPLICATION_URL.GUARANTOR_OWNER_SEARCH_CRITERIA + parentIndex + '/GO');
        this.props.actions.RemoveGuarantorOwner(this.props.guarantorList, parentIndex, childIndex).then(() => {
            this.forceUpdate();
            showSuccess(MESSAGE_CONSTANT.OWNER_REMOVE_SUCCESS);
        }).catch(error => {
            console.log(error.response.data.ExceptionMessage);
        });
    }
    else
    {
        this.context.router.push(APPLICATION_URL.GUARANTOR_OWNER_SEARCH_CRITERIA + parentIndex + '/GO');
        this.props.guarantorList[parentIndex].RelatedEntity.OwnershipTies.splice(childIndex, 1);
        this.forceUpdate();
        showSuccess(MESSAGE_CONSTANT.OWNER_REMOVE_SUCCESS);
    }
}

onRemoveGuarantorList(index)
{
    let isOwnersExist=_.some(this.props.guarantorList[index].RelatedEntity.OwnershipTies, 'IsExisting', true);
    if(this.props.guarantorList[index].RelatedEntity.OwnershipTies.length>0 && !isOwnersExist)
    {
        showError(MESSAGE_CONSTANT.GUARANTOR_REMOVE_ERROR);
    }
    else
    {
        if(!this.props.guarantorList[index].IsNew)
        {
            this.context.router.push(APPLICATION_URL.GUARANTOR_SEARCH_CRITERIA_PAGE + 'G');
            this.props.actions.RemoveGuarantor(this.props.guarantorList, index).then(() => {
                this.forceUpdate();
                showSuccess(MESSAGE_CONSTANT.GUARANTOR_REMOVE_SUCCESS);
            }).catch(error => {
                console.log(error.response.data.ExceptionMessage);
            });
        }
        else
        {
            this.context.router.push(APPLICATION_URL.GUARANTOR_SEARCH_CRITERIA_PAGE + 'G');
            this.props.guarantorList.splice(index, 1);
            this.forceUpdate();
            showSuccess(MESSAGE_CONSTANT.GUARANTOR_REMOVE_SUCCESS);
        }
    }
}

onRemoveProductList(index)
{
    if(this.props.productsList.lenght==1 && this.props.guarantorList.length>0)
    {
        showError(MESSAGE_CONSTANT.PRODUCT_REMOVE_ERROR);
    }
    else
    {
        if(!this.props.productsList[index].IsNew)
        {
            this.context.router.push(APPLICATION_URL.PRODUCT_REQUEST_URL+0);
            this.props.actions.RemoveProduct(this.props.collateralList, this.props.productsList, index).then(() => {
                this.isBCCOrBLCProductExist(this.props.productsList);
                this.removeCardholders(this.props.productsList);
                this.props.productsList = reArrangeDisplayNameProperty(this.props.productsList, "Product Request ");
                this.forceUpdate();
                showSuccess(MESSAGE_CONSTANT.PRODUCT_REMOVE_SUCCESS);
            }).catch(error => {
                console.log(error.response.data.ExceptionMessage);
            });
        }
        else
        {
            this.context.router.push(APPLICATION_URL.PRODUCT_REQUEST_URL+0);
            this.props.productsList.splice(index, 1);
            this.isBCCOrBLCProductExist(this.props.productsList);

            this.props.productsList = reArrangeDisplayNameProperty(this.props.productsList, "Product Request ");
            this.forceUpdate();
            showSuccess(MESSAGE_CONSTANT.PRODUCT_REMOVE_SUCCESS);
        }
    }
}

render() {
    let brrowerClass = (this.state.activeTab == "Borrower"? "left-nav-header":"")
        let nodeNavConfirmation = (<span>
                                                             <button className="btn btn-primary" onClick={this.onYesClick.bind(this)}>Yes</button>
                                                             <button className="btn btn-primary" onClick={this.onNoClick.bind(this)}>No</button>
                                                          </span>);

      return(<div className={(this.state.isajaxcallInProgress)?"disabled":""}>
                <div><FormField type="dialog" node={nodeNavConfirmation} isOpenDialog={this.state.isNavDialog} Message={MESSAGE_CONSTANT.NAVIGATION_CONFIRMATION} ModalTitle="Warning" onClose={this.onNoClick.bind(this)} /></div>
        <div className="pad-t-6px left-nav-caption mar-b-m-6px bold">
		    <span className="font-11px pad-l-20px">APPLICATION NAVIGATOR</span>
        </div>
        <div className="left-menu pad-b-0px br-clr-gray bg-clr-lightgray  mar-b-25px ">
          <div id="borrowerSection" className={(this.props.borrowerInformation.Id==0)?"disabled pad-t-0px pad-b-0px mar-b-m-5px":" pad-t-0px pad-b-0px mar-b-m-5px"}>
                    <div className={("left-submenu pad-t-6px pad-b-6px br-b-gray mar-b-m-4px "+brrowerClass)}>
						 <span className="fa fa-user mar-r-8px pull-left pad-l-20px pad-t-2px mar-l-10px" aria-hidden="true"></span>
                         <span className="pad-l-5px" onClick={this.onLeftMenuClick.bind(this,APPLICATION_URL.BORROWER_URL, "active", 0,"Borrower")} to={APPLICATION_URL.BORROWER_URL +"active"}>{renderSpan((this.props.borrowerInformation.Id==0)?'bold gray '+brrowerClass :'bold '+brrowerClass,'','Borrower')}</span>
                         <span className={(!this.state.savedStatus.Borrower?("fa fa-exclamation-triangle fa-lg clr-orange mar-r-5px pull-right cursor-pointer "): ("fa fa-check clr-green cursor-pointer mar-r-5px pull-right cursor-pointer")+" cursor-pointer mar-r-5px pull-right")}
                          aria-hidden="true"></span>
                    </div>
                    {/*Business Owner Section*/}
                    {((this.props.borrowerInformation.EntityStructure.StructureCode!=="" && this.props.borrowerInformation.EntityStructure.StructureCode!=="I")?(
                        <div>
                            <div className="pad-l-35px pad-t-5px pad-t-0px pad-b-0px">
                            <LeftNavItems   id="OwnersSection"
                                            disabled={(this.props.borrowerInformation.IsNew==false && this.props.borrowerInformation.Id!=0)?false:true}
                                            collapsed={this.state.isOwnerCollapsed}
                                            displayValue={this.props.ownersList}
                                            displayText="Owner"
                                            url={APPLICATION_URL.BORROWER_OWNER}
                                            onFieldClick={this.onOwnersClick.bind(this)}
                                            groupLabelText="Borrower Owner(s)"
                                            addNewUrl={APPLICATION_URL.BORROWER_OWNER_SEARCH_CRITERIA}
                                            addNewUrlParam="BO"
                                            showControls={this.state.isOwnerControlsEnable}
                                            addNewLinkText="Add New Owner"
                                            onRemoveClick={this.onCommonRemoveClick.bind(this)}
                                            onLeftMenuClick={this.onLeftMenuClick.bind(this)}
                                            imgClassName = "fa-user"
                                            parentImgClassName = "fa-users"
                                            activeTab={this.state.activeTab}
                                            saveStatus={(this.state.savedStatus.BorrowerOwner == undefined ? false:this.state.savedStatus.BorrowerOwner )}
                                            isRemove={true} />
                            </div>
                    </div>):(<div></div>))}
                    {/*End Business Owner Section*/}
           </div> {/*End Borrower Section*/}
           {/*Product Request Section  && this.checkOwnersList(this.props.ownersList)*/}
           <LeftNavItems id="ProductRequestSection"
           disabled={(this.props.borrowerInformation.EntityStructure.StructureCode!=="" && this.props.borrowerInformation.EntityStructure.StructureCode!="I")?((this.props.borrowerInformation.IsNew==false && this.props.borrowerInformation.Id!=0 && this.props.ownersList!=null && this.props.ownersList.length>0)?(false):(true)):((this.props.borrowerInformation.IsNew==false && this.props.borrowerInformation.Id!=0 && this.props.productsList.length>0)?(false):(true))}
                  collapsed={this.state.isProductCollapsed}
                  displayValue={this.props.productsList}
                  displayText="Product Request"
                  url={APPLICATION_URL.PRODUCT_REQUEST_URL}
                  onLeftMenuClick={this.onLeftMenuClick.bind(this)}
                  onFieldClick={this.onProductsClick.bind(this)}
                  groupLabelText="Products"
                  onRemoveClick={this.onCommonRemoveClick.bind(this)}
                  onLeftMenuClick={this.onLeftMenuClick.bind(this)}
                  addNewUrl={APPLICATION_URL.PRODUCT_REQUEST_URL}
                  addNewLinkText="Add New Product"
                  activeTab={this.state.activeTab}
                  imgClassName = "fa-suitcase mar-r-6px"
                  parentImgClassName = "fa-suitcase mar-r-6px"
                  saveStatus={(this.state.savedStatus.Product == undefined ? false:this.state.savedStatus.Product )}/>
                  {/*End Product Request Section*/}
        {/*Guaranotr Section*/}
      <LeftNavItems id="GuarantorSection"
                    disabled={(this.props.borrowerInformation.EntityStructure.StructureCode!=="" &&  this.props.borrowerInformation.EntityStructure.StructureCode!=="I")?((this.props.ownersList!=null && this.props.ownersList.length>0 && this.props.productsList.length>0 &&  _.some(this.props.productsList, function(o) { return o.ProductId!=0; }))?(false):(true)):((this.props.borrowerInformation.Id!==0 && this.props.productsList.length>0 && _.some(this.props.productsList, function(o) { return o.ProductId!=0; }))?(false):(true))}
                    collapsed={this.state.isGuarantorCollapsed}
                    displayValue={this.props.guarantorList}
                    displayText="Guarantor"
                    url={APPLICATION_URL.GUARANTOR}
                    onFieldClick={this.onGuarantorsClick.bind(this)}
                    groupLabelText="Guarantors"
                    addNewUrl={APPLICATION_URL.GUARANTOR_SEARCH_CRITERIA_PAGE}
                    addNewUrlParam="G"
                    addNewLinkText="Add New Guarantor"
                    isOwner={true}
                    isRemove={true}
                    activeTab={this.state.activeTab}
                    imgClassName="fa-user mar-r-9px"
                    parentImgClassName = "fa-users mar-r-9px"
                    onGuarantorOwnerClick={this.onGuarantorOwnerClick.bind(this)}
                    onOwnerRemoveClick={this.onRemoveGuarantorOwnerList.bind(this)}
                    saveStatus={(this.state.savedStatus.Guarantor == undefined ? false:this.state.savedStatus.Guarantor )}
                    ownerStatus={(this.state.savedStatus.GuarantorOwner == undefined ? false:this.state.savedStatus.GuarantorOwner )}
                    onRemoveClick={this.onCommonRemoveClick.bind(this)}
                    onLeftMenuClick={this.onLeftMenuClick.bind(this)} />
    {/*End Guaranotr Section*/}
        {/*Collateral Section*/}
        {(!this.state.isCollateralDisable)?(
        <LeftNavItems id="CollateralSection"
                    disabled={this.state.isCollateralDisable}
                    collapsed={this.state.isCollateralCollapsed}
                    displayValue={this.props.collateralList}
                    displayText="Collateral"
                    isRemove={true}
                    url={APPLICATION_URL.COLLATERAL}
                    onFieldClick={this.onCollateralClick.bind(this)}
                    groupLabelText="Collateral"
                    imgClassName="fa-newspaper-o mar-r-5px"
                    parentImgClassName ="fa-newspaper-o mar-r-5px"
                    addNewUrl={APPLICATION_URL.COLLATERAL}
                    saveStatus={(this.state.savedStatus.Collateral == undefined ? false:this.state.savedStatus.Collateral )}
                    addNewLinkText="Add New Collateral" 
                    activeTab={this.state.activeTab} 
                    onRemoveClick={this.onCommonRemoveClick.bind(this)}
                    onLeftMenuClick={this.onLeftMenuClick.bind(this)} />):(<div></div>)}
{/*End Collateral Section*/}
{(!this.state.isCardholderDisable)?(
    <LeftNavItems id="CardholderSection" disabled={this.state.isCardholderDisable}
collapsed={this.state.isCardholderCollapsed}
displayValue={this.props.cardholderList}
displayText="Cardholder"
imgClassName="fa-credit-card mar-r-5px"
parentImgClassName ="fa-credit-card mar-r-5px"
url={APPLICATION_URL.CARDHOLDER}
onFieldClick={this.onCardholderClick.bind(this)}
saveStatus={(this.state.savedStatus.Cardholder == undefined ? false:this.state.savedStatus.Cardholder )}
                    groupLabelText="Cardholder"
                    addNewUrl={APPLICATION_URL.CARDHOLDER}
                    addNewUrlParam="add"
                    activeTab={this.state.activeTab}
                    addNewLinkText="Add New Cardholder" onRemoveClick={this.onCommonRemoveClick.bind(this)}  onLeftMenuClick={this.onLeftMenuClick.bind(this)} />
                    ):(<div></div>)}
        <div  className={((this.state.activeTab == "Additional")?'left-nav-header pad-t-6px pad-b-6px left-submenu':'pad-t-6px pad-b-6px left-submenu') + (((_.some(this.props.collateralList, ['IsNew', false]))||(_.some(this.props.cardholderList, ['IsNew', false]))) ? "" : " disabled")}>
            <i className="fa fa-envelope pad-l-30px" aria-hidden="true"></i>
            <span className="pad-l-5px bold" onClick={this.onLeftMenuClick.bind(this,APPLICATION_URL.ADDITIONAL_INFORMATION, 0, 0, "Additional")} to={APPLICATION_URL.ADDITIONAL_INFORMATION}>{renderSpan((this.state.activeTab == "Additional")?'borrower-active':'','','Additional Information')} </span>
            <span className={(!this.state.isAdditionalInformationSaved ?  "fa fa-exclamation-triangle fa-lg clr-orange mar-r-5px pull-right cursor-pointer": "fa fa-check clr-green cursor-pointer mar-r-5px pull-right cursor-pointer")} aria-hidden="true"></span>
        </div>
</div>

    <div>
        {(getDisclosures(this.props.productsList).length>0)?(<div className="mar-t-0px mar-l-0px br-clr-gray ln-ht-30px bg-clr-lightblue mar-b-20px">
            <span className="bold pad-l-10px">
                <i className="fa fa-file-text-o pad-r-10px" aria-hidden="true"></i>
                <span className="font-12px">Print Application Disclosures</span>
            </span>
            <span>
                <div className="mar-l-40px">
                    {this.getDisclosures()}
                </div>
            </span>
        </div>):(<div></div>)}
    </div>
<ConfirmWindow
message={MESSAGE_CONSTANT.DELETE_CONFIRM}
isOpenDialog={this.state.isOpenDialog}
handleDialogYesClick = {this.handleDialogYesClick.bind(this)}
modalTitle="Confirm Removal"/>
</div>)
}
}

LeftNavigation.propTypes = {
    borrowerInformation:PropTypes.object.isRequired,
    actions: PropTypes.object.isRequired
}

LeftNavigation.contextTypes = {
    router: PropTypes.object
};


let mapStateToProps = (state) => {
    return {
        borrowerInformation: state.loanAppReducer.LoanApplication.Borrower,
        productsList: state.loanAppReducer.LoanApplication.Products,
        ownersList: state.loanAppReducer.LoanApplication.Borrower.OwnershipTies,
        guarantorList: state.loanAppReducer.LoanApplication.Guarantors,
        collateralList: state.loanAppReducer.LoanApplication.Collaterals,
        cardholderList:state.loanAppReducer.LoanApplication.Cardholders,
        productTypeList: ((state.loanAppReducer.ProductCommonData!=undefined && state.loanAppReducer.ProductCommonData!=null)?(state.loanAppReducer.ProductCommonData.ProductTypeList):([])),
        savedStatus: state.loanAppReducer.SavedStatus,
        additionalInformation: state.loanAppReducer.LoanApplication.AdditionalInformation,
        borrowercommondata: state.loanAppReducer.LegalEntityCommonData,
        isDirtyStatus: state.loanAppReducer.status
    };
}

function mapDispatchToProps(dispatch) {
    return  {actions: bindActionCreators({GetOwners,
                                          RemoveCardholderLegalEntity,
                                          GetGuarantorOwners,
                                          RemoveBorrowerOwner,
                                          RemoveGuarantorOwner,
                                          RemoveGuarantor,
                                          RemoveCollateral,
                                          RemoveProduct,
                                          LeftNavigationControlIsDirty},
                                          dispatch)};
}

export default connect(mapStateToProps,mapDispatchToProps)(LeftNavigation);
