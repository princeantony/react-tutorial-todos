import React, { PropTypes, Component } from 'react';
import {LEGALENITITY_COMMON_CONSTANT, POSITION} from '../constants/ApplicationConstants';
import FormField from './form-components/FormField';
import {VALIDATION_CONSTANT} from "../constants/ApplicationConstants"; 

let borrowerinfo = {};
class DomesticAddress extends Component{
    
    onFieldChange(e){
        if(e.target.name=="State")
        {
            borrowerinfo.State=e.target.value;
        }
        this.props.onFieldChange(e); 
    }
    OnCancelClick(e){
        this.props.OnCancelClick(e);
    }
    OnClearClick(e){
        this.props.OnClearClick(e);
    }
    OnUpdateClick(e){
        this.props.OnUpdateClick(e);
    }

    
    render(){
        const{borrowerinformation, commonData, onFieldChange, name, isDisabled, addressType, doValidate, hasError}=this.props;
        let vertical=POSITION.VERTICAL;
        let horizontal=POSITION.HORIZONTAL;
        
        if(borrowerinformation != undefined && borrowerinformation != null)
        {
            borrowerinfo = Object.assign({}, borrowerinformation);
        }
        
        let required=false;
        (addressType=="borrowerAddressType")?(required=false):(required=true);
        
        return(<div className={isDisabled?"disabled":"" } name={name} id={name}>
            <div className="row">
                <FormField columnSize={4} orientation={vertical}  name="Line1" type="text"
                displayText={LEGALENITITY_COMMON_CONSTANT.ADDRESS_Line1}  displayValue={borrowerinfo.Line1} isRequired={required} hasError={hasError} doValidate={doValidate}/>
                <FormField columnSize={4} orientation={vertical}  name="Line2" type="text"
                displayText={LEGALENITITY_COMMON_CONSTANT.ADDRESS_Line2} displayValue={borrowerinfo.Line2} />
                <FormField columnSize={4} orientation={vertical}  name="City" type="text"
                displayText={LEGALENITITY_COMMON_CONSTANT.CITY}
                           displayValue={borrowerinfo.City} isRequired={required} hasError={hasError} doValidate={doValidate}/>
            </div>
            <div className="row">
                <FormField columnSize={4} orientation={vertical} name="State"
                type="select-single" onFieldChange={this.onFieldChange.bind(this)}
                dataValueField="StateAbbrevation" dataTextField="StateName"
                defaultSelectValue={borrowerinfo.State}
                displayText={LEGALENITITY_COMMON_CONSTANT.STATE} displayValue={commonData} isRequired={required} hasError={hasError} doValidate={doValidate}/>
                <FormField columnSize={4} orientation={vertical}  name="ZipCode" type="text"
                displayText={LEGALENITITY_COMMON_CONSTANT.ZIP_POSTAL_CODE} displayValue={borrowerinfo.ZipCode} isRequired={required} hasError={hasError} doValidate={doValidate} isNumberFormat={true} digitLength={5} maxLength={5} errorMessage={VALIDATION_CONSTANT.ZIPCODE_ERROR}/>

        {(addressType=="guarantorAddressType")?(
    <div className="pull-right mar-r-43px mar-t-15px">
        <input type="button" id="btnUpdate"  name={name+"_Update"} className="btn btn-primary" onClick={this.OnUpdateClick.bind(this)}  value="Update" />
        <input type="button" id="btnClear"  name={name +"_Clear"} className="btn btn-primary mar-l-15px"  value="Clear" onClick={this.OnClearClick.bind(this)}/>
            <input type="button" id="btnCancel" name={name + "_Cancel"} onClick={this.OnCancelClick.bind(this)} className="btn btn-primary mar-l-15px"  value="Cancel" />
    </div>
                ):''}
            </div>
        </div>)
    }
}
export default DomesticAddress;
