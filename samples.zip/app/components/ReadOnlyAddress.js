import React, { PropTypes, Component } from 'react';
import {LEGALENITITY_COMMON_CONSTANT, POSITION} from '../constants/ApplicationConstants';
import FormField from './form-components/FormField';

class ReadOnlyAddress extends Component{
  constructor(props, context) {
          super(props, context); 
      }

    onMismatchClick(e){
       this.props.onMismatchClick(e.target.name, e.target.value);
    }

    render(){
        const{ leftAddress, rightAddress, onMismatchClick, name, isAddressesSame, leftAddressVisible, rightAddressVisible, defaultOption }=this.props;
        let vertical=POSITION.VERTICAL;
        let horizontal=POSITION.HORIZONTAL;
        return(
          <div className="row pad-5px">
            {(isAddressesSame)?(""):(
                <div className="pad-l-15px italic">{LEGALENITITY_COMMON_CONSTANT.ADDRESS_MISMATCH_MESSAGE}</div>
            )}
            {(leftAddressVisible)? 
            (<div className="row col-sm-6">
                <FormField  columnSize={12} orientation={horizontal}  name={name}
                 type="radio" onFieldChange={this.onMismatchClick.bind(this)}
                 displayValue={[{"Key": 1,"Value":""}]}  defaultOption={(defaultOption == undefined || defaultOption == null)?"":defaultOption} />

                <div className="row border-div mar-t-25px">
                    <FormField columnSize={5} orientation={horizontal} name={this.props.addressType} type="label-group"
                    displayText={LEGALENITITY_COMMON_CONSTANT.ADDRESS_TYPE+": "} displayValue={((leftAddress.IsInternational)?(LEGALENITITY_COMMON_CONSTANT.INTERNATIONAL):
                 (LEGALENITITY_COMMON_CONSTANT.DOMESTIC))} />
                    <div className="pad-l-15px col-sm-12 mar-t-5px">
                        <FormField columnSize={4} orientation={horizontal} cssLabelClass="font-size-12px" cssLabelValueClass="" type="label" 
                        value={((leftAddress.Line1 !=null && leftAddress.Line1 !='')?(leftAddress.Line1 +", "):(''))+((leftAddress.Line2 !=null && leftAddress.Line2 !='' )?(leftAddress.Line2 +", "):(''))+((leftAddress.Province != null && leftAddress.Province != undefined ?(leftAddress.Province +", "):('')))} />
                    </div>
                    <div className="pad-l-15px col-sm-12">
                        <FormField columnSize={4} orientation={horizontal} cssClass="font-size-12px" cssLabelValueClass="" type="label" 
                        value={((leftAddress.City !=null && leftAddress.City !='' )?(leftAddress.City +", "):(''))+((leftAddress.Country != null && leftAddress.Country !='' && leftAddress.Country != undefined)?(leftAddress.Country +", "):(''))+leftAddress.ZipCode}  />
                    </div>
                </div>
            </div>):""}
          {(rightAddressVisible)?
          (<div className="row col-sm-6">
                <FormField  columnSize={12} orientation={horizontal}  name={name}
                 type="radio" onFieldChange={this.onMismatchClick.bind(this)}
                displayValue={[{"Key": 2,"Value": ""}]}  defaultOption={defaultOption}/>
            <div className="row border-div mar-t-25px">
                <FormField columnSize={5} orientation={horizontal} name={this.props.addressType} type="label-group"
                displayText={LEGALENITITY_COMMON_CONSTANT.ADDRESS_TYPE+": "} displayValue={((rightAddress.IsInternational)?(LEGALENITITY_COMMON_CONSTANT.INTERNATIONAL):
           (LEGALENITITY_COMMON_CONSTANT.DOMESTIC))} />
                <div className="pad-l-15px col-sm-12 mar-t-5px">
                    <FormField columnSize={4} orientation={horizontal} cssClass="font-size-12px" cssLabelValueClass="" type="label" 
                    value={((rightAddress.Line1 !=null && rightAddress.Line1 !='')?(rightAddress.Line1 +", "):(''))+((rightAddress.Line2 !=null && rightAddress.Line2 !='')?(rightAddress.Line2 +", "):(''))+((rightAddress.Province != null && rightAddress.Province != undefined ?(rightAddress.Province +", "):('')))} />
                </div>
                <div className="pad-l-15px col-sm-12">
                    <FormField columnSize={4} orientation={horizontal} cssClass="font-size-12px" cssLabelValueClass="" type="label" 
                    value={((rightAddress.City !=null && rightAddress.City !='')?(rightAddress.City +", "):(''))+((rightAddress.Country != null && rightAddress.Country !='')?(rightAddress.Country +", "):(''))+rightAddress.ZipCode}  />
                </div>
            </div>
        </div>):""}

      </div>)
    }
}
ReadOnlyAddress.propTypes = {
    leftAddress:PropTypes.object.isRequired,
    rightAddress:PropTypes.object.isRequired,
}
ReadOnlyAddress.defaultProps = {
    isAddressesSame:true,
};
export default ReadOnlyAddress;
