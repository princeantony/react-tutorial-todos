/* React libraries */
import React, {Component, PropTypes} from "react";
import {bindActionCreators} from "redux";
import {connect} from "react-redux";

/* Plugin libraries */
import _ from "lodash";

/* LoanApp libraries */
import {parseBool, getFormattedData, showSuccess, showWarning, showError, getDisplayName, formatData, getAffiliate} from "../utils/Functions";

/* Action components */
import {CreateGuarantorLegalEntityTie, SaveGuarantorRelatedEntity, GetGuarantorLegalEntityTie, IsInValidPOBox} from "../actions/legalEntityAction";
import {GetLightAddress, AddAddress } from "../utils/AddressFunctions";
import {UpdateActionStatus} from "../actions/commondataAction";

/* Constant components */
import {BORROWER_CONSTANT, GUARANTOR_CONSTANT, LEGALENITITY_COMMON_CONSTANT, VALIDATION_CONSTANT, LEGEND_CONSTANT, POSITION, MESSAGE_CONSTANT} from "../constants/ApplicationConstants";

/* Child components libraries */
import {renderAccordion, renderSection, renderSpinner} from "./form-components/Form";
import FormField from "./form-components/FormField";
import MultipleAddress from "./MultipleAddress";
import EditableAddress from "./EditableAddress"
import BusinessInformation from "./child-components/BusinessInformation";
import PhoneNumbers from "./child-components/PhoneNumbers";
import OtherInformation from "./child-components/OtherInformation";

/* Variable declaration start */
let isReadonly = true;
let isIndividual = false;
let vertical = POSITION.VERTICAL;
let horizontal = POSITION.HORIZONTAL;
let existingAddress = null;
let saveNewBusinessAddress = false;
let saveNewHomeAddress = false;
let _guarantorId = 0;
let _tempGuarantor={};
let entityStructureForGuarantor = [];
let guarantorFrom = "";
let errorCollection = {};
let defaultData={};
/* Variable declaration end */

class Guarantor extends Component {
    constructor(props, context) {
        super(props, context);

        this.state = {
            guarantorInformationData: Object.assign({}, props.guarantorinformation),
            errors: {},
            saving: false,
            isGuarantorInfoLoaded:false,
            mobileErrorMessage: false,
            isAddressEditClicked:false,
            guarantorAddressNew: null,
            defaultAddressOption:"",
            saveNewGuarantorAddress: false,
            isInternationalAddress: false,
            guarantorAddressCount: 1,
            doValidate: false,
            doValidateAddress: false,
            savedStatus: Object.assign({}, props.savedStatus)
        };

        this.onFieldChange = this.onFieldChange.bind(this);
        this.onFieldBlur = this.onFieldBlur.bind(this);
        this.onMismatchClick = this.onMismatchClick.bind(this);
        this.onEntityChange = this.onEntityChange.bind(this);
        this.hasError = this.hasError.bind(this);
    }

    getLatestGuarantor(){
        if(this.props.guarantorList!=undefined && this.props.guarantorList!=null && this.props.guarantorList.length>0)
            return this.props.guarantorList[this.props.guarantorList.length-1];
    }

    componentWillMount() {
        guarantorFrom = this.props.params.id;
        if(guarantorFrom=="add")
        {
            this.setState({isGuarantorInfoLoaded:false});
            this.props.actions.CreateGuarantorLegalEntityTie(2, 0, this.props.legalEntityId, this.props.userID).then(() => {
                let latestGuarantor=this.getLatestGuarantor();
                this.setState({guarantorInformationData: latestGuarantor});
                defaultData = Object.assign({}, latestGuarantor);
                this.setState({isGuarantorInfoLoaded:true});
                entityStructureForGuarantor = this.props.guarantorcommondata.EntityStructures;
                entityStructureForGuarantor = _.reject(entityStructureForGuarantor, function(o) { return o.StructureCode == "I"; });
                saveNewBusinessAddress = this.state.guarantorInformationData.RelatedEntity.PrimaryAddress;
                saveNewHomeAddress = this.state.guarantorInformationData.RelatedEntity.SecondaryAddress;
            }).catch(error => {
                this.setState({isGuarantorInfoLoaded:true});
                console.log(error.response.data.ExceptionMessage);
            });

        }
        else if(guarantorFrom != undefined)
        {
            this.setState({isGuarantorInfoLoaded:false});
            let guarantor = getGuarantorById(this.props.guarantorList, guarantorFrom);
            if(guarantor==null)
            {
                this.props.actions.GetGuarantorLegalEntityTie(2, guarantorFrom, this.props.legalEntityId, this.props.userID).then(() => {
                    let latestGuarantor = this.getLatestGuarantor();
                    this.setState({guarantorInformationData: latestGuarantor});
                    defaultData = Object.assign({}, latestGuarantor);
                    this.setState({isGuarantorInfoLoaded:true});
                }).catch(error => {
                    this.setState({isGuarantorInfoLoaded:true});
                    console.log(error.response.data.ExceptionMessage);
                });
            }
            else
            {
                defaultData=Object.assign({}, guarantor);
                this.setState({guarantorInformationData: guarantor});
                this.setState({isGuarantorInfoLoaded:true});
            }
        }
    }

    componentWillReceiveProps(nextProps){
        if(this.props.guarantorinformation!=nextProps.guarantorinformation)
        {
            this.setState({guarantorInformationData:nextProps.guarantorinformation});
            defaultData = Object.assign({}, nextProps.guarantorinformation);
        }
    }

    shouldComponentUpdate(nextProps, nextState) {
        return (nextState.isGuarantorInfoLoaded)
    }
    componentWillUpdate(nextProps, nextState) {
        if (nextState.isGuarantorInfoLoaded) {
            isIndividual = this.props.guarantorinformation.IsIndividual;
        }
    }

    componentDidUpdate(prevProps, prevState){
        if(prevState.doValidateAddress != this.state.doValidateAddress){
            this.state.doValidateAddress = false;
            if(_.size(errorCollection)>0)
            {
                this.setState({saving: false});
                showError(VALIDATION_CONSTANT.GUARANTOR_ERROR_MESSAGE);
            }
            else
            {
                if(this.state.isAddressEditClicked){
                    this.UpdateAddress();
                }
            }
        }
        if(prevState.doValidate != this.state.doValidate)
        {
            this.state.doValidate = false;
            if(_.size(errorCollection)>0)
            {
                this.setState({saving: false});
                showError(VALIDATION_CONSTANT.GUARANTOR_ERROR_MESSAGE);
            }
            else
            {
                this.saveGuarantorDetails();
            }
        }
    }

    onEntityChange(e){
        let structureCode = e.target.value;
        this.state.guarantorInformationData.RelatedEntity.EntityStructure = _.find(this.props.guarantorcommondata.EntityStructures, ['StructureCode', structureCode]);
    }

    updateGuarantor(e) {
        const fieldName = e.target.name;
        let fielValue=getFormattedData(e);

        _tempGuarantor= this.state.guarantorInformationData;
        _.set(_tempGuarantor.RelatedEntity, fieldName, fielValue);
        this.setState({guarantorInformationData: _tempGuarantor});
    }

    onFieldChange(e){
        this.updateGuarantor(e);
    }

    onFieldBlur(e) {
        if(e.target.name=="Line1")
        {
            this.props.actions.IsInValidPOBox(e.target.value).then((data)=>{
                if(data)
                showError(MESSAGE_CONSTANT.POSTBOX_ERROR_MESSAGE);
            }).catch(error=>{console.log(error.response.data.ExceptionMessage);});
        }
    }

    redirect() {
        this.setState({saving: false});
        showSuccess(MESSAGE_CONSTANT.GUARANTOR_REQUEST_SAVE_SUCCESS);
        showWarning(MESSAGE_CONSTANT.GUARANTOR_REQUEST_ADD_LINK);
    }

    onEditClick(e){
        //this.state.doValidate = false;
        this.setState({isAddressEditClicked:true})
        if(this.state.guarantorAddressNew == null){
            this.setState({guarantorAddressNew: existingAddress});
        }
        this.setState({isInternationalAddress:existingAddress.IsInternational})
    }

    onCancelClick(e){
        if(this.state.guarantorAddressCount == 1){
            this.setState({guarantorAddressNew: null});
        }
        this.setState({isAddressEditClicked:false});
    }

    onClearClick(e){
        let formData=$("#GuarantorAddress_Editable :input").serializeArray();
        let _tempGuarantorAddress = null;
        {formData && formData.map((data, index) => {
            _.set(_tempGuarantorAddress, data.name, data.value='');
        })}
        this.state.guarantorAddressNew = Object.assign({}, _tempGuarantorAddress);
    }

    onAddressTypeClick(_isInternational){
        //if(e.target.name=="GuarantorAddress_EditableAddressType" || e.target.name=="GuarantorAddress_InputAddressType")
        //    this.setState({isInternationalAddress:!this.state.isInternationalAddress});
        this.state.guarantorAddressNew.IsInternational = _isInternational;
    }

    onUpdateClick(e){
        e.preventDefault();
        errorCollection = {};
        this.setState({doValidateAddress: true});
    }
    UpdateAddress(){
        this.setState({isAddressEditClicked:false});
        let formData=$("#GuarantorAddress_Editable :input").serializeArray();
        let _tempGuarantorAddress = Object.assign({}, this.state.guarantorAddressNew);
        {formData && formData.map((data, index) => {
            _.set(_tempGuarantorAddress, data.name, data.value);
        })}
        this.state.guarantorAddressNew = Object.assign({}, _tempGuarantorAddress);
        this.setState({
            saveNewGuarantorAddress: true,
            defaultAddressOption:2,
            guarantorAddressCount:2
        });
        if((this.props.collateralinfo && this.props.collateralinfo.OwnerOfCollateral!=null && this.props.collateralinfo.OwnerOfCollateral == 1) && (this.state.guarantorInformationData.RelatedEntity.Relationship.Id==this.props.collateralinfo.Owner.Relationship.Id)){
            showWarning(GUARANTOR_CONSTANT.ADDRESS_CHANGE_INFORMATION);
        }
    }

    onMismatchClick(name, value) {
        if (name == "AddressIndividual_true" || name=="AddressIndividual_false" )
            this.state.saveNewGuarantorAddress = value == "2"? true: false;
    }

    hasError(error, e, isOnBlur){
        let fieldName=e.name;
        if(e.id!=undefined && e.id!=null)
            fieldName = e.id;
        if(error[fieldName])
            _.set(errorCollection, fieldName, error[fieldName]);
        else
            _.unset(errorCollection, fieldName);
    }

    saveGuarantorDetails()
    {
        let formData=$("form :input").serializeArray();
        let _tempGuarantor=this.state.guarantorInformationData.RelatedEntity;
        {formData && formData.map((data, index) => {
            data.value=formatData(data.value);
           /* if(data.value == "true" || data.value == "false")
                data.value = parseBool(data.value);*/
            /*else if ((!isNaN(data.value)) && (data.value != ""))
                data.value = Number(data.value);*/
            if(data.name == "Affiliate")
            {
                _.set(_tempGuarantor, data.name, getAffiliate(this.props.guarantorcommondata.Affilliates, data.value));   
            }
            else
            {
                _.set(_tempGuarantor, data.name, data.value);
            }
        })}

       let propsId=this.props.params.id;
       let guarantorIndex;

       if(propsId == "add"){
           let _tempGuarantorAddress = {};
           let formData=$("#GuarantorAddress_Editable :input").serializeArray();
           {formData && formData.map((data, index) => {
               /*if(data.value == "true" || data.value == "false")
                   data.value = parseBool(data.value);*/
                data.value=formatData(data.value);
               _.set(_tempGuarantorAddress, data.name, data.value);
           })}
           _.set(_tempGuarantorAddress,"AddressTypeId" , "E");
           _.set(this.state.guarantorInformationData.RelatedEntity, "Addresses[0]", _tempGuarantorAddress);
       }
       if(this.state.saveNewGuarantorAddress && this.state.guarantorAddressNew)
       {
           AddAddress(_tempGuarantor.Addresses, this.state.guarantorAddressNew,"T");
           _.set(_tempGuarantor, "PrimaryAddress", true);
       }
       this.setState({saving: true});
       if(propsId=="add")
       {
           guarantorIndex=this.props.guarantorList.length-1;
       }
       else
       {
           let guarantor = getGuarantorById(this.props.guarantorList, propsId);
           guarantorIndex=(guarantor)?propsId:this.props.guarantorList.length-1;
       }
       this.props.actions.SaveGuarantorRelatedEntity(this.state.guarantorInformationData, guarantorIndex)
       .then(() => {
           this.setState({guarantorInformationData: this.props.guarantorinformation});
            if(this.state.savedStatus.Guarantor == undefined)
           {
               let newStatus = this.state.savedStatus;
               _.set(newStatus, "Guarantor", true);
               this.props.actions.UpdateActionStatus(newStatus);
            }
            this.setState({
                guarantorAddressNew: null,
                guarantorAddressCount: 1
            });
           this.redirect();
       })
       .catch(error => {
           console.log(error.response.data.ExceptionMessage);
           this.setState({saving: false});
       });
    }

    _onDone(e){
        e.preventDefault();
        errorCollection = {};
        this.setState({doValidate: true});
    }

    _renderUpdateGuarantor(){
        if(this.state.guarantorInformationData && this.state.guarantorInformationData.RelatedEntity && this.state.guarantorInformationData.RelatedEntity.Addresses){
            existingAddress = _.find(this.state.guarantorInformationData.RelatedEntity.Addresses, {'AddressTypeId': this.state.guarantorInformationData.RelatedEntity.PrimaryAddress? "T" :'E'});
        }
        return(
            <div>
                {renderSection('Guarantor '+ (getDisplayName(this.props.guarantorList, this.props.params.id)),'panel','pnl-sub-header-green width-30-per pad-4px font-size-14px bold mar-l-5px','',
                    ([<div>
                        <form method="post" action="" key="guarantorForm" name="guarantorForm" id="guarantorForm" ref="guarantorForm" >
                         <div className={(this.state.saving?"overlay-div":"")}> &nbsp;
                                </div>
                                {(this.state.saving?renderSpinner():"")}
                            <fieldset className="brd-radius-3px mar-t-m-5px">
                                <div className="col-lg-12 pad-0px mar-0px">
                                    <div className="mar-l-5px mar-r-5px pnl-brd-darkgray brd-radius-10px pad-14px pad-t-0px pad-b-0px">
                                         <FormField type="legend" displayText={LEGEND_CONSTANT.REQUIRED_FIELD} />
                                         {!isIndividual && <FormField type="legend" cssClass="clr-lbl font-size-11px italic" displayText={LEGEND_CONSTANT.NON_INDIVIDUAL_GUARANTORS_MESSAGE} />}

                                        <div className="pad-b-5px pad-l-5px pad-r-5px pad-t-50px font-size-11px">
                                             {/*Type Of Guarantor*/}
                                                <div className="mar-t-20px mar-l-5px mar-r-5px brd-radius-1px">
                                                    <div className="row">
                                                        <FormField columnSize={4} orientation={horizontal} name="EntityStructure.StructureCode" type="radio" displayText={LEGALENITITY_COMMON_CONSTANT.TYPE_OF_CUSTOMER}  defaultOption={(((this.state.guarantorInformationData.RelatedEntity.EntityStructure.StructureCode!=null)?((this.state.guarantorInformationData.RelatedEntity.EntityStructure.StructureCode.trim()!="I")?("C"):("I")):("")))} displayValue={[{"Key":"I","Value":"Individual"},{"Key":"C","Value":"Corporate"}]} onFieldChange={this.onFieldChange} isDisabled={(this.props.params.id!=="add")?true:false} />
                                                     </div>
                                                </div>
                                                {((this.state.guarantorInformationData.RelatedEntity.EntityStructure.StructureCode!=null)?(<div>
                                                     <div><BusinessInformation customerLabel="Guarantor" entityStructure={entityStructureForGuarantor} onEntityChange={this.onEntityChange}  isIndividual={isIndividual} isBorrower={false} isEditable={((this.props.params.id=="add")?(true):(false))} initialData={defaultData.RelatedEntity} data={this.state.guarantorInformationData.RelatedEntity} onFieldChange={this.onFieldChange} hasError={this.hasError} doValidate={this.state.doValidate}/></div>
                                                     <div>

                                                     {/* Guarantor New Address part start here*/}
                                                     {(this.props.params.id=="add")?(
                                                        (renderAccordion('fa fa-address-card', (isIndividual ? LEGALENITITY_COMMON_CONSTANT.HOME_ADDRESS : LEGALENITITY_COMMON_CONSTANT.BUSINESS_ADDRESS),"panel accordion-brd-color font-size-12px", "accordion-panel pad-4px bold", "","",
                                                         <div>
                                                            <EditableAddress addressType="InputAddressType" disabled={false}  name={"InputAddress"} type={"GuarantorAddress"}
                                                                commonData={this.props.guarantorcommondata} onAddressTypeClick={this.onAddressTypeClick.bind(this)}
                                                                isInternational={isIndividual ? this.state.isInternationalAddress : this.state.isInternationalAddress}
                                                                onFieldBlur={this.onFieldBlur.bind(this)}
                                                                hasError={this.hasError} doValidate={this.state.doValidateAddress}/>
                                                         </div>
                                                      ))
                                                     ):(<div>
                                                     {(existingAddress != null && existingAddress != undefined) ?
                                                        (renderAccordion('fa fa-address-card', (isIndividual? LEGALENITITY_COMMON_CONSTANT.HOME_ADDRESS : LEGALENITITY_COMMON_CONSTANT.BUSINESS_ADDRESS),"panel accordion-brd-color font-size-12px", "accordion-panel pad-4px bold", "","",
                                                         <div>
                                                             {(!this.state.isAddressEditClicked)?(
                                                                 <div>
                                                                     <MultipleAddress name={"AddressIndividual_" + isIndividual}
                                                                        defaultOption={this.state.defaultAddressOption}
                                                                        existingAddress={existingAddress}
                                                                        newAddress={this.state.guarantorAddressNew? this.state.guarantorAddressNew : null}
                                                                        addressCount={this.state.guarantorAddressCount}
                                                                        onMismatchClick={this.onMismatchClick.bind(this)}
                                                                        hasError={this.hasError} doValidate={this.state.doValidate}/>

                                                                      <a name="Address_Edit" className={(this.state.guarantorAddressCount == 1)?("link mar-l-342px edit-link-style"):("link mar-r-20px pull-right edit-link-style")}
                                                                        onClick={this.onEditClick.bind(this)}>Edit</a>
                                                                 </div>
                                                                ):''}
                                                                {(this.state.isAddressEditClicked)?(
                                                                    <EditableAddress addressType="EditableAddressType" disabled={false}  name={"AddressIndividual_" + isIndividual}
                                                                        addressInformation={this.state.guarantorAddressNew} type={"GuarantorAddress"}
                                                                        commonData={this.props.guarantorcommondata}
                                                                        isInternational={this.state.isInternationalAddress}
                                                                        onCancelClick={this.onCancelClick.bind(this)}
                                                                        onUpdateClick={this.onUpdateClick.bind(this)}
                                                                        onClearClick={this.onClearClick.bind(this)}
                                                                        onAddressTypeClick={this.onAddressTypeClick.bind(this)}
                                                                        onFieldBlur={this.onFieldBlur.bind(this)}
                                                                        hasError={this.hasError} doValidate={this.state.doValidateAddress} />
                                                                 ):''}
                                                           </div>
                                                      )):''}
                                                    </div>)}
                                                     {/* Guarantor New Address part ends here*/}
                                                     </div>
                                                     <div><PhoneNumbers initialData={defaultData.RelatedEntity} data={this.state.guarantorInformationData.RelatedEntity} errorMessage={this.state.mobileErrorMessage} hasError={this.hasError} doValidate={this.state.doValidate}/></div>
                                                     <div><OtherInformation isIndividual={isIndividual} isBorrower={false}
                                                     initialData={defaultData.RelatedEntity} paramId={guarantorFrom}
                                                             affiliate = {this.props.guarantorcommondata.Affilliates} customerLabel="Guarantor"
                                                             affiliateDefault = {this.state.guarantorInformationData.RelatedEntity.Affiliate.Code}
                                                             data={this.state.guarantorInformationData.RelatedEntity} onFieldChange={this.onFieldChange}
                                                             statesList={this.props.guarantorcommondata.States}
                                                             hasError={this.hasError} doValidate={this.state.doValidate} />
                                                     </div>
                                                    <div className={this.state.isAddressEditClicked?"disabled pull-right pad-r-5px mar-r-5px btn-primary bg-btn-clr-navy mar-t-15px":"pull-right pad-r-5px mar-r-5px btn-primary bg-btn-clr-navy mar-t-15px"}>
                                                        <span className=" fa fa-lg fa-floppy-o" aria-hidden="true"></span>
                                                        <input type="button" className="bg-clr-transparent br-none wid-55px pad-l-7px" value="Save" onClick={this._onDone.bind(this)} disabled={this.state.saving} />
                                                    </div>
                                          </div>):(<div></div>))}
                                      </div>
                                </div>
                    </div>
                </fieldset>
            </form>
        </div>]))}
    </div>);
}

    render() {
        if(!this.state.isGuarantorInfoLoaded)
        {
            return (renderSpinner());
        }
        isIndividual = (this.state.guarantorInformationData.RelatedEntity.EntityStructure.StructureCode == "I"? true: false);
        return (<div>{this._renderUpdateGuarantor()}</div>);
    }
}

Guarantor.propTypes = {
    guarantorinformation: PropTypes.object.isRequired,
    guarantorcommondata: PropTypes.object.isRequired,
    actions: PropTypes.object.isRequired
};

Guarantor.contextTypes = {
    router: PropTypes.object
};

function getGuarantorById(guarantors, id) {
    let guarantor =_.nth(guarantors, id);
    return (guarantor)? guarantor: null;
}

let mapStateToProps = (state, ownProps) => {
    let _guarantor={};
    let guarantorId=ownProps.params.id;

    if (state.loanAppReducer.LoanApplication.Guarantors.length > 0) {
        _guarantor = getGuarantorById(state.loanAppReducer.LoanApplication.Guarantors, guarantorId);
        if(_guarantor==null)
            _guarantor = state.loanAppReducer.LoanApplication.Guarantors[state.loanAppReducer.LoanApplication.Guarantors.length-1];
    }

    let _collateral={};
    if (state.loanAppReducer.LoanApplication.Collaterals.length > 0) {
        _collateral = getGuarantorById(state.loanAppReducer.LoanApplication.Collaterals, ownProps.params.id);
    }

    return {
        guarantorinformation: _guarantor,
        guarantorcommondata: state.loanAppReducer.LegalEntityCommonData,
        guarantorList:state.loanAppReducer.LoanApplication.Guarantors,
        legalEntityId:state.loanAppReducer.LoanApplication.Borrower.Id,
        savedStatus: state.loanAppReducer.SavedStatus,
        collateralinfo: _collateral,
        userID: state.loanAppReducer.LoanApplication.ApplicationSummary.EmployeeId
    };
}

function mapDispatchToProps(dispatch) {
    return {actions: bindActionCreators({CreateGuarantorLegalEntityTie, SaveGuarantorRelatedEntity, GetGuarantorLegalEntityTie, IsInValidPOBox,UpdateActionStatus}, dispatch)};

}

export default connect(mapStateToProps,mapDispatchToProps)(Guarantor);
