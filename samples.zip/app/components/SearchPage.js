﻿/*eslint-disable no-undef */

/* React libraries */
import React, {Component, PropTypes} from "react";
import {bindActionCreators} from "redux";
import {connect} from "react-redux";

/* Child Components*/
import FormField from "./form-components/FormField";
import SearchGrid from "./child-components/search/SearchGrid";


/* Constant components */
import {SEARCH_CONSTANT} from "../constants/ApplicationConstants";
import {APPLICATION_URL} from "../constants/ApplicationURL";

/* Action components */
import {GetSearchResults} from "../actions/searchAction";
import {showError} from "../utils/Functions";

/* variable declaration start */
let _legalEntityId = "add";
/* variable declaration end */

class SearchPage extends Component {
    constructor(props, context) {
        super(props, context);
        this.state = {
            isContinueEnable: false,
            isAddNewBorrowerDisable:true,
            legalEntityInformation: Object.assign({}, props.legalEntityDetails),
            pageNumber: 1
        };
    }

    /* action methods start */
    SearchMoreResult() {
        this.state.pageNumber+=1;
        this.setState({isAddNewBorrowerDisable:false});
        let customerName = "", SSNTIN = "";
        if (this.props.legalEntityDetails.StructureCode!="I") {
            customerName = this.state.legalEntityInformation.LegalName;
            SSNTIN = this.state.legalEntityInformation.SocialSecurityNumber;
        }
        else {
            customerName = this.state.legalEntityInformation.FirstName + " " + this.state.legalEntityInformation.MiddleName + " " + this.state.legalEntityInformation.LastName;
            SSNTIN = this.state.legalEntityInformation.SocialSecurityNumber;
        }
        this.props.actions.GetSearchResults(SSNTIN, customerName, this.state.pageNumber).then(()=>{
        }).catch(error=>{console.log(error.response.data.ExceptionMessage);});

    }
    /* action methods end */

    onRowSelect(row, isSelected){
        if (isSelected) {
            _legalEntityId = row.LegalEntityId;
            this.setState({isContinueEnable: true});
        }
        else {
            _legalEntityId = "add";
            this.setState({isContinueEnable: false});
        }
    }

    _navigateToBorrower(legalEntityId){
            this.context.router.push(APPLICATION_URL.BORROWER_URL + legalEntityId);
    }

    
    _renderSearchGrid() {
        return (<SearchGrid searchcustomerPageHeaderText={SEARCH_CONSTANT.SEARCH_RESULT}
                 displayValue={this.props.searchResults}  isHover={true} 
                 isSort={((this.props.searchresults == 0) ? (false) : (true))} 
                 isSearch={false} selectType="radio" 
                 onRowSelect={this.onRowSelect.bind(this)}
                 onAddButtonClick={this._navigateToBorrower.bind(this, "add")} 
                 SearchMoreResult={this.SearchMoreResult.bind(this)} 
                 isContinueDisable={(!this.state.isContinueEnable)} 
                     isAddNewBorrowerDisable={this.state.isAddNewBorrowerDisable}
                 onContinueButtonClick={this._navigateToBorrower.bind(this, _legalEntityId)} 
                 addNewButtonDisplayText="Borrower" /> );
        }

    render() {
        return (<div>{this._renderSearchGrid()}</div>);
    }
}

SearchPage.propTypes = {
    searchResults: PropTypes.object.isRequired,
    legalEntityDetails: PropTypes.object.isRequired,
    actions: PropTypes.object.isRequired
};

SearchPage.contextTypes = {
    router: PropTypes.object
};

let mapStateToProps = (state) => {
    return {
        searchResults: state.loanAppReducer.SearchResults,
        legalEntityDetails: state.loanAppReducer.LoanAppInputData.Borrower
    }
}

function mapDispatchToProps(dispatch) {
    return {actions: bindActionCreators({GetSearchResults}, dispatch)};
}

export default connect(mapStateToProps, mapDispatchToProps)(SearchPage);