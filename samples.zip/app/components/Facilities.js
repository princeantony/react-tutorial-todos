﻿import React, { PropTypes, Component } from 'react';
import FormField from './form-components/FormField';
import {LEGALENITITY_COMMON_CONSTANT, POSITION} from '../constants/ApplicationConstants';
let MonthlyRent = "";
let Property = "";
let Comments = "";
class Facilities extends Component{
    constructor(props) {
        super(props);
        this.state = {
            selectedValue: 1
        }
    }
    onFieldChange(e){
        this.setState({selectedValue:e.target.value});
    }
    componentWillMount() {
        if(this.props.facilityItems != undefined && this.props.facilityItems.Facility != undefined && this.props.facilityItems.Facility != null)
        {
            
            if(this.props.addressType == "home")
            {
                this.setState({selectedValue:Number(this.props.facilityItems.Facility.home)})
                MonthlyRent = this.props.facilityItems.Facility.homeMonthlyRent;
                Property = this.props.facilityItems.Facility.homeProperty;
                Comments = this.props.facilityItems.Facility.homeComments;
            }
            if(this.props.addressType == "business")
            {
                this.setState({selectedValue:Number(this.props.facilityItems.Facility.business)})
                 MonthlyRent = this.props.facilityItems.Facility.businessMonthlyRent;
                Property = this.props.facilityItems.Facility.businessProperty;
                Comments = this.props.facilityItems.Facility.businessComments;
            }
        }
    }
    render(){
        const{ addressType, facilityItems, isIndividual }=this.props;
         let facilities = (!this.props.isIndividual? _.reject(this.props.facilities, { 'Key': 4}) : this.props.facilities);
        let vertical=POSITION.VERTICAL;
        let horizontal=POSITION.HORIZONTAL;
        let Recidence=[{"Key": 1,"Value": "Own"},{"Key": 2,"Value": "Rent"},{"Key": 3,"Value": "Other"}];
        return(<div  name={addressType+"_facilitiesDiv"} id={addressType+"_facilitiesDiv"}>
                <div className="row">
                    {(addressType === "business")?(
                        <FormField columnSize={4} orientation={vertical} id={addressType}
                                   name={addressType} type="select-single"
                                   onFieldChange={this.onFieldChange.bind(this)}
                                   displayText={LEGALENITITY_COMMON_CONSTANT.FACILITIES}
                                   defaultSelectValue={this.state.selectedValue}
                                   displayValue={facilities} isRequired />
                                ):(<FormField columnSize={4} orientation={horizontal} name={addressType}
                                  type="radio" displayText={LEGALENITITY_COMMON_CONSTANT.RESIDENCE}
                                  displayValue={Recidence} onFieldChange={this.onFieldChange.bind(this)} 
                                    defaultOption={this.state.selectedValue}
                                  isRequired />)}

                </div>
                <div className="row">
                    {(this.state.selectedValue == 1)?
                    (<div><FormField columnSize={4} orientation={vertical} name={addressType+"MonthlyRent"} type="text" displayText={LEGALENITITY_COMMON_CONSTANT.MONTHLY_RENT_MORTGAGE_PAYMENT}  displayValue={MonthlyRent} isRequired />
                            <FormField columnSize={4} orientation={vertical} name={addressType+"Property"} type="text"  displayText={LEGALENITITY_COMMON_CONSTANT.PROPERTY_VALUE} displayValue={Property} isRequired /></div>):""}
                   {(this.state.selectedValue == 2)?
                        (<FormField columnSize={4} orientation={vertical} name={addressType+"MonthlyRent"} type="text" displayText={LEGALENITITY_COMMON_CONSTANT.MONTHLY_RENT_MORTGAGE_PAYMENT}   displayValue={MonthlyRent} isRequired />):""}
                    {(this.state.selectedValue == 3)?
                        (<FormField columnSize={4} orientation={vertical} name={addressType+"Comments"} type="text" displayText={LEGALENITITY_COMMON_CONSTANT.COMMENTS}  displayValue={Comments} isRequired />):""}
                </div>
            </div>
        )
    }
}

Facilities.propTypes = {
    facilities :PropTypes.array.isRequired
}
export default Facilities;
