﻿/*eslint-disable no-undef */
import React, { Component, PropTypes } from "react";
import { bindActionCreators } from "redux";
import {connect} from "react-redux";
import FormField from "./form-components/FormField";
import {SEARCH_CONSTANT, POSITION} from "../constants/ApplicationConstants";
import {renderSection, renderSpinner} from "./form-components/Form";
import {APPLICATION_URL} from "../constants/ApplicationURL";
import SearchGrid from "./child-components/search/SearchGrid";


let _legalEntityId = "add";
class GuarantorSearch extends Component {
    constructor(props, context) {
        super(props, context);
        this.state = {
            isContinueEnable:false,
        };
    }

    onRowSelect(row, isSelected){
        if(isSelected)
        {
            _legalEntityId= row.LegalEntityId;
            this.setState({isContinueEnable: true});
        }
        else
        {
            _legalEntityId="add";
            this.setState({isContinueEnable: false});
        }
    }

    _naviagetUpdate(){
        if(_legalEntityId>0)
        {
            if(this.props.params.id=="C")
            {
                this.context.router.push(APPLICATION_URL.COLLATERAL+_legalEntityId);
            }
            else if(this.props.params.id=="G"){
                this.context.router.push(APPLICATION_URL.GUARANTOR+_legalEntityId);
            }
        }
    }

    _naviagetAdd(){
        _legalEntityId="add";
        if(this.props.params.id=="C")
        {
            this.context.router.push(APPLICATION_URL.COLLATERAL+_legalEntityId);
        }
        else if(this.props.params.id=="G"){
            this.context.router.push(APPLICATION_URL.GUARANTOR+_legalEntityId);
        }
    }

    _navigateToSearchCriteria(){
        this.context.router.push(APPLICATION_URL.SEARCH_CRITERIA_PAGE+this.props.params.id);
    }

    _renderSearchGrid(){
        return(
            <div>
                    <SearchGrid searchHeaderText={SEARCH_CONSTANT.CUSTOMER_SEARCH} 
                    displayValue={this.props.searchresults} 
                    addNewButtonDisplayText="Guarantor" isHover={true} isSort={((this.props.searchresults == 0) ? (false) : (true))} 
                    isSearch={false} selectType="radio"
                    onRowSelect={this.onRowSelect.bind(this)} 
                    onAddButtonClick={this._naviagetAdd.bind(this)} 
                    isContinueDisable={(!this.state.isContinueEnable)} 
                    onContinueButtonClick={this._naviagetUpdate.bind(this)}
                    showErrorMessage={true}  searchAgain={true} 
                    onSearchAgainClick={this._navigateToSearchCriteria.bind(this)} />
              </div>
                );
            }

    render() {
        if(this.props.searchresults==undefined || this.props.searchresults==null)
        {
            return (renderSpinner());
        }
        return (<div>{this._renderSearchGrid()}</div>);
    }
}

GuarantorSearch.propTypes = {
    searchresults: PropTypes.object.isRequired,
    actions: PropTypes.object.isRequired
};

GuarantorSearch.contextTypes = {
    router: PropTypes.object
};

let mapStateToProps = (state) => {
    return {
        searchresults:state.loanAppReducer.SearchResults
    }
}



export default connect(mapStateToProps)(GuarantorSearch);



