import { combineReducers } from "redux";
import { routerReducer as routing } from "react-router-redux";
import loanAppReducer from "./loanappreducer";

const rootReducer = combineReducers({
    loanAppReducer,
    routing
})
export default rootReducer;
