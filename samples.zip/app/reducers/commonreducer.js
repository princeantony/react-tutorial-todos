import * as types from '../constants/ActionTypes';
export default function commonReducer(state = null, action) {
    switch (action.type) {
        case types.GET_LOANAPP_STATIC_DATA:
            return Object.assign({}, state  , {States:  action.apiResult.States, Countries:  action.apiResult.Countries, Facilities:  action.apiResult.Facilities });
      default:
      return state;
  }
}
