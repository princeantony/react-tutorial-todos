/*eslint-disable no-undef */
import * as types from "../constants/ActionTypes";

let initialState = LoanAppInitialData;

export default function loanAppReducer(state = initialState, action) {
    switch (action.type) {

        /* Search Results */
        case types.GET_SEARCH_INFORMATION_SUCCESS:
            return Object.assign({}, state, {SearchResults:action.apiResult});

            /* Legal Entity */
        case types.UPDATE_BORROWER_SUCCESS:
            return Object.assign({}, state, {LoanApplication: Object.assign({},state.LoanApplication, {Borrower:action.Borrower})});

        case types.GET_GUARANTOR:
            return Object.assign({}, state, {LoanApplication: Object.assign({}, state.LoanApplication,  {Guarantors: [...state.LoanApplication.Guarantors,action.Guarantor]})});

        case types.GET_GUARANTORS:
            return Object.assign({}, state, {LoanApplication: Object.assign({}, state.LoanApplication,  {Guarantors: action.Guarantors})});

        case types.SAVE_GUARANTOR:
            return Object.assign({}, state, {LoanApplication: Object.assign({},state.LoanApplication, {Guarantors: [...state.LoanApplication.Guarantors.slice(0, parseInt(action.Index)),Object.assign({}, state.LoanApplication.Guarantors[parseInt(action.Index)], action.Guarantor),...state.LoanApplication.Guarantors.slice(parseInt(action.Index) + 1)]})});

        case types.UPDATE_GUARANTOR_SUCCESS:
            return Object.assign({}, state, {LoanApplication: Object.assign({},state.LoanApplication, {Guarantors:[action.Guarantor]})});

        case types.GET_LEGALENTITY_COMMON_DATA:
            return Object.assign({}, state,  {LegalEntityCommonData: action.LegalEntityCommonData});

            /* Product Information*/
        case types.CREATE_PRODUCT_INFORMATION:
            return Object.assign({}, state, {LoanApplication: Object.assign({}, state.LoanApplication, {Products: [...state.LoanApplication.Products.slice(0, parseInt(action.Index)), Object.assign({}, state.LoanApplication.Products[parseInt(action.Index)], action.Product), ...state.LoanApplication.Products.slice(parseInt(action.Index) + 1)]})});

        case types.UPDATE_PRODUCT:
            return Object.assign({}, state,  {LoanApplication: action.UpdatedLoanAppWithProd});

        case types.GET_PRODUCT_COMMON_DATA:
            return Object.assign({}, state,  {ProductCommonData: action.ProductCommonData});

        case types.GET_PRODUCT:
            return Object.assign({}, state, {LoanApplication: Object.assign({}, state.LoanApplication,  {Products: [...state.LoanApplication.Products,action.Product]})});

        case types.GET_PRODUCTS:
            return Object.assign({}, state, {LoanApplication: Object.assign({}, state.LoanApplication,  {Products: action.Products})});

            /* Loan Application Submit */
        case types.UPDATE_LOANAPPLICATION:
            return Object.assign({}, state, {LoanApplication: Object.assign({},state.LoanApplication,{isSubmitSuccess:action.isSubmitSuccess})});

        case types.UPDATE_FINANCIALNEEDS_DOCUMENT_STATUS:
            return Object.assign({}, state, {LoanApplication: Object.assign({},state.LoanApplication,{isDocumentGenerated:action.isDocumentGenerated})});

        case types.CREATE_CARDHOLDER:
            return Object.assign({}, state, {LoanApplication: Object.assign({},state.LoanApplication, {Cardholders: [...state.LoanApplication.Cardholders,action.Cardholders]})});

        case types.UPDATE_CARDHOLDER:
            return Object.assign({}, state, {LoanApplication: Object.assign({},state.LoanApplication, {Cardholders: [...state.LoanApplication.Cardholders.slice(0, parseInt(action.Index)),Object.assign({}, state.LoanApplication.Cardholders[parseInt(action.Index)], action.Cardholders),...state.LoanApplication.Cardholders.slice(parseInt(action.Index) + 1)]})});

        case types.REMOVE_CARDHOLDER:
            return Object.assign({}, state, {LoanApplication: Object.assign({},state.LoanApplication, {Cardholders:action.Cardholders})});

            /* Collateral Information */
        case types.CREATE_COLLATERAL_SUCCESS:
            return Object.assign({}, state, {LoanApplication: Object.assign({},state.LoanApplication, {Collaterals: [...state.LoanApplication.Collaterals.slice(0, parseInt(action.Index)),Object.assign({}, state.LoanApplication.Collaterals[parseInt(action.Index)], action.Collateral),...state.LoanApplication.Collaterals.slice(parseInt(action.Index) + 1)]})});

        case types.GET_COLLATERAL_COMMON_DATA:
            return Object.assign({}, state,  {CollateralCommonData: action.CollateralCommonData});

        case types.UPDATE_COLLATERAL_OWNER_SUCCESS:
            return Object.assign({}, state, {LoanApplication: Object.assign({}, state.LoanApplication, {Collaterals: [...state.LoanApplication.Collaterals.slice(0, parseInt(action.Index)),Object.assign({}, state.LoanApplication.Collaterals[parseInt(action.Index)], {Owner: action.LegalEntity}),...state.LoanApplication.Collaterals.slice(parseInt(action.Index) + 1)]})});

        case types.GET_COLLATERALS:
            return Object.assign({}, state, {LoanApplication: Object.assign({}, state.LoanApplication,  {Collaterals: action.Collaterals})});

        case types.GET_COLLATERAL:
            return Object.assign({}, state, {LoanApplication: Object.assign({}, state.LoanApplication,  {Collaterals: [...state.LoanApplication.Collaterals,action.Collateral]})});
            /* Owners Information */
        case types.GET_OWNERS:
            return Object.assign({}, state, {LoanApplication: Object.assign({},state.LoanApplication, {Borrower: Object.assign({}, state.LoanApplication.Borrower, {OwnershipTies:action.Owners})})});

        case types.GET_OWNER:
            return Object.assign({}, state, {LoanApplication: Object.assign({},state.LoanApplication, {Borrower: Object.assign({}, state.LoanApplication.Borrower, {OwnershipTies: [...state.LoanApplication.Borrower.OwnershipTies,action.Owner]})})});

        case types.SAVE_OWNER:
            return Object.assign({}, state, {LoanApplication: Object.assign({},state.LoanApplication, {Borrower: Object.assign({}, state.LoanApplication.Borrower, {OwnershipTies: [...state.LoanApplication.Borrower.OwnershipTies.slice(0, parseInt(action.Index)),Object.assign({}, state.LoanApplication.Borrower.OwnershipTies[parseInt(action.Index)], action.Owner),...state.LoanApplication.Borrower.OwnershipTies.slice(parseInt(action.Index) + 1)]})})});

        case types.OWNER_ASSIGNEMENT_UPDATE:
            return Object.assign({}, state, {LoanApplication: Object.assign({},state.LoanApplication, {Borrower: Object.assign({}, state.LoanApplication.Borrower, {OwnershipTies: [...state.LoanApplication.Borrower.OwnershipTies.slice(0, parseInt(action.OwnerIndex)),Object.assign({}, state.LoanApplication.Borrower.OwnershipTies[parseInt(action.OwnerIndex)], action.Owner),...state.LoanApplication.Borrower.OwnershipTies.slice(parseInt(action.OwnerIndex) + 1)]})})});

        case types.GET_GUARANTOR_OWNERS:
            return Object.assign({}, state, {LoanApplication: Object.assign({}, state.LoanApplication, {Guarantors:  [...state.LoanApplication.Guarantors.slice(0, parseInt(action.Index)),Object.assign({}, state.LoanApplication.Guarantors[parseInt(action.Index)], {RelatedEntity: Object.assign({}, state.LoanApplication.Guarantors[parseInt(action.Index)].RelatedEntity, {OwnershipTies: action.Owners})}), ...state.LoanApplication.Guarantors.slice(parseInt(action.Index)+1)]})});

        case types.GET_GUARANTOR_OWNER:
            return Object.assign({}, state, {LoanApplication: Object.assign({}, state.LoanApplication, {Guarantors: [...state.LoanApplication.Guarantors.slice(0, parseInt(action.Index)),Object.assign({}, state.LoanApplication.Guarantors[parseInt(action.Index)], {RelatedEntity: Object.assign({}, state.LoanApplication.Guarantors[parseInt(action.Index)].RelatedEntity, {OwnershipTies: [...state.LoanApplication.Guarantors[parseInt(action.Index)].RelatedEntity.OwnershipTies,action.Owner]})}),...state.LoanApplication.Guarantors.slice(parseInt(action.Index)+1)]})});

        case types.SAVE_GUARANTOR_OWNER:
            return Object.assign({}, state, {LoanApplication: Object.assign({}, state.LoanApplication, {Guarantors: [...state.LoanApplication.Guarantors.slice(0, parseInt(action.GuarantorIndex)),Object.assign({}, state.LoanApplication.Guarantors[parseInt(action.GuarantorIndex)], {RelatedEntity: Object.assign({}, state.LoanApplication.Guarantors[parseInt(action.GuarantorIndex)].RelatedEntity, {OwnershipTies: [...state.LoanApplication.Guarantors[parseInt(action.GuarantorIndex)].RelatedEntity.OwnershipTies.slice(0, parseInt(action.OwnerIndex)),Object.assign({}, state.LoanApplication.Guarantors[parseInt(action.GuarantorIndex)].RelatedEntity.OwnershipTies[parseInt(action.OwnerIndex)], action.Owner),...state.LoanApplication.Guarantors[parseInt(action.GuarantorIndex)].RelatedEntity.OwnershipTies.slice(parseInt(action.OwnerIndex) + 1)]})}),...state.LoanApplication.Guarantors.slice(parseInt(action.GuarantorIndex)+1)]})});

        case types.GUARANTOR_OWNER_ASSIGNEMENT_UPDATE:
            return Object.assign({}, state, {LoanApplication: Object.assign({}, state.LoanApplication, {Guarantors: [...state.LoanApplication.Guarantors.slice(0, parseInt(action.GuarantorIndex)),Object.assign({}, state.LoanApplication.Guarantors[parseInt(action.GuarantorIndex)], {RelatedEntity: Object.assign({}, state.LoanApplication.Guarantors[parseInt(action.GuarantorIndex)].RelatedEntity, {OwnershipTies: [...state.LoanApplication.Guarantors[parseInt(action.GuarantorIndex)].RelatedEntity.OwnershipTies.slice(0, parseInt(action.OwnerIndex)),Object.assign({}, state.LoanApplication.Guarantors[parseInt(action.GuarantorIndex)].RelatedEntity.OwnershipTies[parseInt(action.OwnerIndex)], action.Owner),...state.LoanApplication.Guarantors[parseInt(action.GuarantorIndex)].RelatedEntity.OwnershipTies.slice(parseInt(action.OwnerIndex) + 1)]})}),...state.LoanApplication.Guarantors.slice(parseInt(action.GuarantorIndex)+1)]})});

        case types.CREATE_NEW_ADDITIONAL_INFORMATION:
            return Object.assign({}, state, {LoanApplication: Object.assign({},state.LoanApplication, {AdditionalInformation: [...state.LoanApplication.AdditionalInformation,action.AdditionalInformation]})});

        case types.UPDATE_ADDITIONAL_INFORMATION:
            return Object.assign({}, state, {LoanApplication: Object.assign({},state.LoanApplication, {AdditionalInformation:action.AdditionalInformation})});

         case types.SET_SAVED_ITEM:
             return Object.assign({}, state,  {SavedStatus: action.statusItems});

        case types.SET_IS_DIRTY_ITEM: 
            return Object.assign({}, state,  {status: action.status});

        default:
            return state;
    }
}
