﻿/*eslint-disable no-undef */
import * as types from '../constants/ActionTypes';


export default function confirmationReducer(state = null, action) {
    switch (action.type) {
        case types.SAVE_CONFIRMATION_DATA:
            {
                return Object.assign({}, state,  action.ConfirmationData);
            }
        default:
            return state;
    }
}
