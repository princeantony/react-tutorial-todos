﻿/*eslint-disable no-undef */

let initialState=[];
initialState = objs;

export default function loadSearchResults(state = initialState, action) {
    switch (action.type) {
        default:
            return state;
    }
}