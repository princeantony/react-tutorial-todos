﻿/* React libraries */
import React, {PropTypes, Component} from "react";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";

/* plugin libraries */
import _ from "lodash";

/* LoanApp libraries */
import {parseBool, getFormattedData, showSuccess, showWarning, showError, getDisplayName, formatData} from "../utils/Functions";


/* Constant components */
import {MESSAGE_CONSTANT, VALIDATION_CONSTANT} from "../constants/ApplicationConstants";
import {APPLICATION_URL} from "../constants/ApplicationURL";

/* Action components */
import {CreateCardholder,SaveCardholder} from "../actions/cardholderAction";
import {IsInValidPOBox} from "../actions/legalEntityAction";
import {UpdateActionStatus, LeftNavigationControlIsDirty} from "../actions/commondataAction";

/* Child components libraries */
import Cardholder from "../components/Cardholder";
let _tempCardholder={};
let errorCollection = {};
let cardholderAddressFields= {"AddressTypeId":"E", "Line1":"", "Line2":"", "City":"","County":"", "ZipCode":"", "State":""};
let actionType=null;
/* variable declaration end */

class CardholderContainer extends Component{
    constructor(props, context) {
        super(props, context);
        this.state = {
            cardholderInformationData: Object.assign({}, props.cardholderinformation),
            saving: false,
            doValidate : false,
            savedStatus :Object.assign({}, props.savedStatus)
        };

        this.onFieldChange = this.onFieldChange.bind(this);
        this.onFieldBlur = this.onFieldBlur.bind(this);
    }


    /* component lifecycle methods start */
    componentWillMount() {
        if(this.props.params.id=="add"){
            this._createNewCardholder((this.props.cardholderList.length==undefined)?0:this.props.cardholderList.length);
        }
    }

    componentWillReceiveProps(nextProps)
    {
        if(actionType!="SET_IS_DIRTY_ITEM")
        {
            if(this.props.params.id!=nextProps.params.id && nextProps.params.id=="add"){
                this._createNewCardholder((this.props.cardholderList.length==undefined)?0:this.props.cardholderList.length);
            }
            else if(this.props.params.id!=nextProps.params.id && nextProps.params.id!="add")
            {
                this.setState({cardholderInformationData:nextProps.cardholderinformation});
            }
            if(this.props.cardholderinformation!=nextProps.cardholderinformation)
            {
                this.setState({cardholderInformationData:nextProps.cardholderinformation});
            }
        }
    }
   
    componentDidUpdate(prevProps, prevState){
        if(prevState.doValidate != this.state.doValidate)
        {
            this.state.doValidate = false;
            if(_.size(errorCollection)>0)
                showError(VALIDATION_CONSTANT.CARDHOLDER_ERROR_MESSAGE);
            else
            {
                this.props.actions.SaveCardholder(this.state.cardholderInformationData, this.props.params.id);
                showSuccess(MESSAGE_CONSTANT.CARDHOLDER_REQUEST_SAVE_SUCCESS);
                showWarning(MESSAGE_CONSTANT.CARDHOLDER_REQUEST_ADD_LINK);
                
                 if(this.state.savedStatus.Cardholder == undefined)
                {
                    let newStatus = this.state.savedStatus;
                    _.set(newStatus, "Cardholder", true);
                    this.props.actions.UpdateActionStatus(newStatus);
                }
            }
            this.setState({saving: false});
        }
    }   
    /* component lifecycle methods end */

    /* action methods start */
    _createNewCardholder(index)
    {
        this.props.actions.CreateCardholder(index).then(() => {
            this.setState({cardholderInformationData: Object.assign({}, this.props.cardholderinformation)});
            this.context.router.push(APPLICATION_URL.CARDHOLDER+(this.props.cardholderList.length-1));
        }).catch(error => {
            console.log(error.response.data.ExceptionMessage);
        });
    }

    
    /* action methods end */

    hasError(error, e){
        let fieldName=e.name;
        if(error[fieldName])
            _.set(errorCollection, fieldName, error[fieldName]);
        else
            _.unset(errorCollection, fieldName);
    }

    /* component events start */
    onFieldBlur(e)
    {
        let actionDisatchpObj = this.props.actions.LeftNavigationControlIsDirty(true);
        actionType=actionDisatchpObj.type;
        if(e.target.name=="Line1")
        {
            this.props.actions.IsInValidPOBox(e.target.value).then((data)=>{
                if(data)
                showError(MESSAGE_CONSTANT.POSTBOX_ERROR_MESSAGE);
            }).catch(error=>{console.log(error.response.data.ExceptionMessage);});
        }
    }

    onFieldChange(e){
        let actionDisatchpObj = this.props.actions.LeftNavigationControlIsDirty(true);
        actionType=actionDisatchpObj.type;
        this.updateCardholder(e);
    }
    
    
    updateCardholder(e) {
        const fieldName = e.target.name;
        let fielValue=getFormattedData(e);
        _tempCardholder= this.state.cardholderInformationData;
        _.set(_tempCardholder, fieldName, fielValue);
        this.setState({cardholderInformationData: _tempCardholder});
    }
    
    hasError(error, e, isOnBlur){
        let fieldName=e.name;
        if(e.id!=undefined && e.id!= null)
            fieldName = e.id;
        if(error[fieldName])
            _.set(errorCollection, fieldName, error[fieldName]);
        else
            _.unset(errorCollection, fieldName);
    }

    _onDone(e){
        this.setState({saving: true});
        /* Fetch data from form collection*/
        let legalEntityDetails=$("#legalEntityDetails :input").serializeArray();
        let addressDetails=$("#addressDetails :input").serializeArray();
        let cardholderAddressFields= {"AddressTypeId":"E", "Line1":"", "Line2":"", "City":"","County":"", "ZipCode":"", "State":""};

        if(legalEntityDetails.length>0)
        {
            _tempCardholder=this.state.cardholderInformationData;
            legalEntityDetails && legalEntityDetails.map((data, index) => {
                data.value=formatData(data.value);
                _.set(_tempCardholder, data.name, data.value);
            });
            this.setState({cardholderInformationData: _tempCardholder});
        }
        
        if(addressDetails.length>0)
        {
            addressDetails && addressDetails.map((data, index) => {
                _.set(cardholderAddressFields, data.name, data.value);
            });
            this.state.cardholderInformationData.Addresses[0]=cardholderAddressFields;
        }
        errorCollection = {};
        this.setState({doValidate: true});
    }
    /* component events end */

    render() {
        return(<div><Cardholder onFieldChange={this.onFieldChange} 
                            index={this.props.params.id} 
                            data={this.state.cardholderInformationData} 
                            commonData={this.props.legalEntityCommonData} 
                            isNextButtonDisable={this.state.saving} 
                            onNextButtonClick={this._onDone.bind(this)} 
                            hasError={this.hasError} doValidate={this.state.doValidate}
                            onFieldBlur={this.onFieldBlur}  displayName={getDisplayName(this.props.cardholderList, this.props.params.id)}
                            /></div>);
        }
}

CardholderContainer.propTypes = {
    cardholderinformation: PropTypes.object.isRequired,
    legalEntityCommonData: PropTypes.object.isRequired,
    actions: PropTypes.object.isRequired
};

CardholderContainer.contextTypes = {
    router: PropTypes.object
};

function getCardHolder(cardholderList, index) {
    let cardholder =_.nth(cardholderList, index);
    return (cardholder)?cardholder:null; 
}

let mapStateToProps = (state, ownProps) => {
    let _cardholder={};
    if(ownProps.params.id!="add")
    {
        if (state.loanAppReducer.LoanApplication.Cardholders.length>0) {
            _cardholder = getCardHolder(state.loanAppReducer.LoanApplication.Cardholders, ownProps.params.id);
        }
    }
    return {
        cardholderinformation: _cardholder,
        legalEntityCommonData: state.loanAppReducer.LegalEntityCommonData,
        loanAppInformation:state.loanAppReducer.LoanApplication,
        cardholderList:((state.loanAppReducer.LoanApplication.Cardholders.length>0)?(state.loanAppReducer.LoanApplication.Cardholders):({})),
        savedStatus: state.loanAppReducer.SavedStatus
    }
}

function mapDispatchToProps(dispatch) {
    return  {
        actions: bindActionCreators({CreateCardholder,SaveCardholder, IsInValidPOBox, UpdateActionStatus, LeftNavigationControlIsDirty}, dispatch)
    };
}

export default connect(mapStateToProps,mapDispatchToProps)(CardholderContainer);