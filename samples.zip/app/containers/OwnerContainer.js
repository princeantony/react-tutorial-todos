﻿/* React libraries */
import React, { Component, PropTypes } from "react";
import {bindActionCreators} from "redux";
import {connect} from "react-redux";

/* plugin libraries */
import _ from "lodash";

/* LoanApp libraries */
import {parseBool, getFormattedData, isLegalEntityIndividual, showSuccess, showWarning, showError, getDisplayName, getURLPath, getAffiliate, formatData} from "../utils/Functions";
import {renderSpinner} from "../components/form-components/Form";

/* Child components libraries */
import Owner from "../components/Owner";

/* Constant components */
import {MESSAGE_CONSTANT, VALIDATION_CONSTANT} from "../constants/ApplicationConstants";

/* Action components */
import {GetOwnerLegalEntity, GetGuarantorOwnerLegalEntity, CreateOwner, SaveRelatedEntity, CreateOwnerForGuarantor, SaveGuarantorRelatedEntity, GetRelatedEntityByAssignementType, GetGuarantorRelatedEntityByAssignementType} from "../actions/ownerAction";
import {IsInValidPOBox} from "../actions/legalEntityAction";
import {UpdateActionStatus} from "../actions/commondataAction";

/* variable declaration start*/
let entityStructureForOwner=[];
let isIndividual = false;
let _legalEntityFrom, _path, _propsId, ownerIndex;
let errorCollection = {};
let _tempAddress;
/* variable declaration end */

class OwnerContainer extends Component {
    constructor(props, context) {
        super(props, context);

        this.state = {
            ownerInformationData: Object.assign({}, props.ownerInformation),
            ownerInformationInitialData: Object.assign({}, props.ownerInformation),
            errors: {},
            saving: false,
            ajaxCallsInProgress:true,
            mobileErrorMessage: false,
            doValidate: false,
            savedStatus :Object.assign({}, props.savedStatus)
        };
        this.onFieldChange = this.onFieldChange.bind(this);
        this.onFieldBlur = this.onFieldBlur.bind(this);
    }



 componentWillMount() {
        _path = getURLPath(location.pathname);
        _legalEntityFrom = _path[3];
        _propsId = this.props.params.id;

        if(_legalEntityFrom=="BorrowerOwner")
        {
            if(_propsId=="add")
            {
                this.setState({ajaxCallsInProgress:true});
                this.createOwnerById(1, 0, this.props.legalEntity.Id, false);
                entityStructureForOwner = this.props.ownerCommonData.EntityStructures;
                entityStructureForOwner = _.reject(entityStructureForOwner, function(o) { return o.StructureCode == "I"; });
            }
            else if(_propsId!=undefined)
            {
                this.setState({ajaxCallsInProgress:true});
                let owner = getOwnerById(this.props.ownersList, _propsId);
                if(owner==null)
                {
                    this.getOwnerLegalEntityById(1, _propsId, this.props.legalEntity.Id, false);
                }
                else
                {
                    this.setState({ownerInformationData: owner});
                    this.setState({ajaxCallsInProgress:false});
                }
            }
        }
        else if(_legalEntityFrom=="GuarantorOwner")
        {
            let guarantorLegalEntityIndex=_path[4];
            if(_propsId=="add")
            {
                this.setState({ajaxCallsInProgress:true});
                this.createOwnerById(1, 0, this.props.legalEntity.Id, true, guarantorLegalEntityIndex);
            }
            else if(_propsId !== undefined)
            {
                this.setState({ajaxCallsInProgress:true});
                let owner = getOwnerById(this.props.ownersList, _propsId);
                if(owner==null)
                {
                    this.getOwnerLegalEntityById(1, _propsId, this.props.legalEntity.Id, true, guarantorLegalEntityIndex);
                }
                else
                {
                    this.setState({ownerInformationData: owner, ajaxCallsInProgress:false});
                }
            }
        }
    }

    componentWillReceiveProps(nextProps){
        if(this.props.ownerInformation!=nextProps.ownerInformation)
        {
            this.setState({ownerInformationInitialData:Object.assign({},nextProps.ownerInformation)});
            this.setState({ownerInformationData:Object.assign({},nextProps.ownerInformation)});
        }
    }
    
    componentDidUpdate(prevProps, prevState){
        if(prevState.doValidate != this.state.doValidate)
        {
            this.state.doValidate = false;
            if(_.size(errorCollection)>0)
            {
                if(_legalEntityFrom=="BorrowerOwner")
                {
                    showError(VALIDATION_CONSTANT.BORROWER_OWNER_ERROR_MESSAGE);
                }
                else if(_legalEntityFrom=="GuarantorOwner")
                {
                    showError(VALIDATION_CONSTANT.GUARANTOR_OWNER_ERROR_MESSAGE);
                }
            }
            else
            {
                this.updateOwnerFormData();
            }
        }
    }
    /* component lifecycle methods end */

/* action methods start */
    getOwnerLegalEntityById(assignmentTypeId, ownerId, legalEntityId, isLEGuarantor, guarantorIndex=0){
        if(isLEGuarantor)
        {
            this.props.actions.GetGuarantorOwnerLegalEntity(assignmentTypeId, ownerId, legalEntityId, guarantorIndex, this.props.userID).then(() => {
                let owner=this.getLatestOwner();
                this.setState({ownerInformationData: owner, ownerInformationInitialData: owner, ajaxCallsInProgress:false});
            }).catch(error => {
                this.setState({ajaxCallsInProgress:false});
                console.log(error.response.data.ExceptionMessage);
            });
        }
        else{
            this.props.actions.GetOwnerLegalEntity(assignmentTypeId, ownerId, legalEntityId, this.props.userID).then(() => {
                let owner=this.getLatestOwner();
                this.setState({ownerInformationData: owner, ownerInformationInitialData: owner, ajaxCallsInProgress:false});
            }).catch(error => {
                this.setState({ajaxCallsInProgress:false});
                console.log(error.response.data.ExceptionMessage);
            });
        }
    }

        getRelatedEntityByAssignementType(assignmentTypeId, ownerId, legalEntityId, isLEGuarantor, ownerIndex, guarantorIndex=0, relatedEntity=null){
            if(isLEGuarantor)
            {
                this.props.actions.GetGuarantorRelatedEntityByAssignementType(assignmentTypeId, ownerId, legalEntityId, ownerIndex, guarantorIndex, this.props.userID).then(() => {
                    this.setState({ownerInformationData: this.props.ownersList[ownerIndex]});
                    this.setState({ownerInformationInitialData: this.props.ownersList[ownerIndex]});
                    this.state.ownerInformationData.RelatedEntity=relatedEntity;
                    this.setState({ajaxCallsInProgress:false});
                }).catch(error => {
                    this.setState({ajaxCallsInProgress:false});
                    console.log(error.response.data.ExceptionMessage);
                });
            }
            else
            {
                this.props.actions.GetRelatedEntityByAssignementType(assignmentTypeId, ownerId, legalEntityId, ownerIndex, this.props.userID).then(() => {
                    this.setState({ownerInformationData: this.props.ownersList[ownerIndex]});
                    this.setState({ownerInformationInitialData: this.props.ownersList[ownerIndex]});
                    this.state.ownerInformationData.RelatedEntity=relatedEntity;
                    this.setState({ajaxCallsInProgress:false});
                }).catch(error => {
                    this.setState({ajaxCallsInProgress:false});
                    console.log(error.response.data.ExceptionMessage);
                });
            }
        }

        createOwnerById(assignmentTypeId, ownerId, legalEntityId, isLEGuarantor, guarantorIndex=0){
            if(isLEGuarantor)
            {
                this.props.actions.CreateOwnerForGuarantor(assignmentTypeId, ownerId, legalEntityId, guarantorIndex, this.props.userID).then(() => {
                    this.setState({ownerInformationData: this.props.ownersList[this.props.ownersList.length-1]});
                    this.setState({ownerInformationInitialData: this.props.ownersList[this.props.ownersList.length-1]});
                    this.setState({ajaxCallsInProgress:false});
                }).catch(error => {
                    this.setState({ajaxCallsInProgress:false});
                    console.log(error.response.data.ExceptionMessage);
                });
            }
            else
            {
                this.props.actions.CreateOwner(assignmentTypeId, ownerId, legalEntityId, this.props.userID).then(() => {
                    this.setState({ownerInformationData: this.props.ownersList[this.props.ownersList.length-1]});
                    this.setState({ownerInformationInitialData: this.props.ownersList[this.props.ownersList.length-1]});
                    this.setState({ajaxCallsInProgress:false});
                }).catch(error => {
                    this.setState({ajaxCallsInProgress:false});
                    console.log(error.response.data.ExceptionMessage);
                });
            }
        }


        saveRelatedEntityTie(ownerLegalEntityInformation, ownersIndex, isLEGuarantor, guarantorIndex=0){
            this.setState({saving: true});
            if(isLEGuarantor){
                this.props.actions.SaveGuarantorRelatedEntity(ownerLegalEntityInformation, guarantorIndex, ownersIndex).then(() => {
                    showSuccess(MESSAGE_CONSTANT.OWNER_REQUEST_SAVE_SUCCESS);
                    showWarning(MESSAGE_CONSTANT.OWNER_NEXT_CLICK);
                    this.setState({ownerInformationData: this.props.ownerInformation});  /// Nedd to be verified
                     if(this.state.savedStatus.GuarantorOwner == undefined)
                        {
                            let newStatus = this.state.savedStatus;
                            _.set(newStatus, "GuarantorOwner", true);
                            this.props.actions.UpdateActionStatus(newStatus);
                        }
                    this.setState({saving: false});
                }).catch(error => {
                    this.setState({saving: false});
                    console.log(error.response.data.ExceptionMessage);
                });
            }
            else{
                this.props.actions.SaveRelatedEntity(ownerLegalEntityInformation, ownersIndex).then(() => {
                    showSuccess(MESSAGE_CONSTANT.OWNER_REQUEST_SAVE_SUCCESS);
                    showWarning(MESSAGE_CONSTANT.OWNER_NEXT_CLICK);
                    this.setState({ownerInformationData: this.props.ownerInformation}); /// Nedd to be verified
                    if(this.state.savedStatus.BorrowerOwner == undefined)
                        {
                            let newStatus = this.state.savedStatus;
                            _.set(newStatus, "BorrowerOwner", true);
                            this.props.actions.UpdateActionStatus(newStatus);
                        }
                    this.setState({saving: false});
                }).catch(error => {
                    this.setState({saving: false});
                    console.log(error.response.data.ExceptionMessage);
                });
            }
        }

      
        /* action methods end */

        getLatestOwner(){
            if(this.props.ownersList!=undefined && this.props.ownersList!=null && this.props.ownersList.length>0)
                return this.props.ownersList[this.props.ownersList.length-1];
        }

        updateOwner(e) {
            let fieldName=e.target.name;
            let fieldValue = getFormattedData(e);

            let relatedEntity= this.state.ownerInformationData.RelatedEntity;
            let ownerDetails ={};
            if(fieldName == "AssignmentTypeId")
            {
                if(_propsId=="add")
                {
                    ownerIndex=this.props.ownersList.length-1;
                }
                else
                {
                    let owner = getOwnerById(this.props.ownersList, _propsId);
                    ownerIndex=(owner)?_propsId:this.props.ownersList.length-1;
                }
                if(_legalEntityFrom=="BorrowerOwner")
                {
                    this.getRelatedEntityByAssignementType(fieldValue, this.state.ownerInformationData.RelatedEntity.Id, this.props.legalEntity.Id, false, ownerIndex, 0,relatedEntity);
                }
                else if(_legalEntityFrom=="GuarantorOwner")
                {
                    let guarantorLegalEntityIndex=_path[4];
                    this.getRelatedEntityByAssignementType(fieldValue, this.state.ownerInformationData.RelatedEntity.Id, this.props.legalEntity.Id, true, ownerIndex, guarantorLegalEntityIndex, relatedEntity);
                }
            }
            else{
                ownerDetails = this.state.ownerInformationData.RelatedEntity;
                _.set(ownerDetails, fieldName, fieldValue);
                this.setState({ownerInformationData : Object.assign({},this.state.ownerInformationData, {RelatedEntity:ownerDetails})});
            }
        }

        /* component events start */
        onFieldChange(e){
            this.updateOwner(e);
        }

        onFieldBlur(e){
            let fieldName=e.target.name;
            let fieldValue = getFormattedData(e);

            if(fieldName=="DisplayPercentage"){
                let updatedString = _.round(fieldValue, 3);
                let ownerDetails = this.state.ownerInformationData;
                _.set(ownerDetails, fieldName, updatedString);
                this.setState({ownerInformationData: ownerDetails});
                e.target.value = updatedString;
            }
            else if(fieldName=="Line1"){
                this.props.actions.IsInValidPOBox(fieldValue).then((data)=>{
                    if(data)
                    showError(MESSAGE_CONSTANT.POSTBOX_ERROR_MESSAGE);
                }).catch(error=>{console.log(error.response.data.ExceptionMessage);});
            }
        }

	 hasError(error, e, isOnBlur){
            let fieldName=e.name;
            if(error[fieldName])
                _.set(errorCollection, fieldName, error[fieldName]);
            else
                _.unset(errorCollection, fieldName);
        }

	 updateOwnerFormData(){
	        this.setState({saving: true});

	        /* Fetch data from form collection*/
	        let formData=$("#ownershipTie :input").serializeArray();
            let _updatedOwner = this.state.ownerInformationData.RelatedEntity;
            
            {formData && formData.map((data, index) => {
                data.value=formatData(data.value);

                if(data.name=="Affiliate")
                {
                    _.set(_updatedOwner, data.name, getAffiliate(this.props.ownerCommonData.Affilliates, data.value));
                }
                else
                {
                    _.set(_updatedOwner, data.name, data.value);
                }
            })}

           
            if(_propsId=="add")
            {
                ownerIndex=this.props.ownersList.length-1;
                _.set(_updatedOwner, "Addresses[0]", _tempAddress);
            }
            else
            {
                if(_tempAddress !=null && _tempAddress !=undefined ){
                    _.set(_updatedOwner, "Addresses", _tempAddress);
                    _.set(_updatedOwner, "PrimaryAddress", true);
                }
                let owner = getOwnerById(this.props.ownersList, _propsId);
                ownerIndex=(owner)?_propsId:this.props.ownersList.length-1;
            }

            if(_legalEntityFrom=="BorrowerOwner")
            {
                this.saveRelatedEntityTie(this.state.ownerInformationData, ownerIndex, false);
            }
            else if(_legalEntityFrom=="GuarantorOwner")
            {
                this.saveRelatedEntityTie(this.state.ownerInformationData, ownerIndex, true, _path[4]);
            }
        }

        _onDone(e,tempAddress){
            _tempAddress = tempAddress;
            errorCollection = {};
            this.setState({doValidate: true});
        }

        _renderOwner(){
            return(<div>
                    <Owner
                    onFieldChange={this.onFieldChange}
                    onFieldBlur={this.onFieldBlur}
                    data={this.state.ownerInformationData}
                    onNextButtonClick={this._onDone.bind(this)}
                    isNextButtonDisable={this.state.saving}
                    initialData={this.state.ownerInformationInitialData}
                    index={_propsId} displayName={getDisplayName(this.props.ownersList, _propsId)}
                    mobileErrorMessage={this.state.mobileErrorMessage}
                    entityStructure={entityStructureForOwner}
                    isIndividual={isIndividual}
                    legalEntitycommondata={this.props.ownerCommonData}
                    isBorrowerOwner={(_legalEntityFrom=="BorrowerOwner")}
                    hasError={this.hasError.bind(this)} doValidate={this.state.doValidate}
                    legalEntityDetails={this.props.legalEntity} /> 
                            
                </div>);
                }

    render() {
        if(this.state.ajaxCallsInProgress)
            return (renderSpinner());

        isIndividual = isLegalEntityIndividual(this.state.ownerInformationData.RelatedEntity.EntityStructure.StructureCode);
        return (<div>{this._renderOwner()}</div>);
    }
}

OwnerContainer.propTypes = {
    ownerInformation: PropTypes.object.isRequired,
    ownerCommonData: PropTypes.object.isRequired,
    actions: PropTypes.object.isRequired
};

OwnerContainer.contextTypes = {
    router: PropTypes.object
};

let getOwnerById = (owners, ownerId) =>{
    let owner=null;
    if(owners!=undefined && owners!=null && owners.length>0)
        owner =_.nth(owners, ownerId);
    return (owner)? owner: null;
}

let mapStateToProps = (state, ownProps) => {
    const ownerId = ownProps.params.id;
    let _owner={};

    let _path = getURLPath(location.pathname);
    _legalEntityFrom = _path[3];

    if(_legalEntityFrom=="BorrowerOwner"){
        if (state.loanAppReducer.LoanApplication.Borrower.OwnershipTies.length > 0) {
            _owner = getOwnerById(state.loanAppReducer.LoanApplication.Borrower.OwnershipTies, ownerId);
            if(_owner==null)
                _owner = state.loanAppReducer.LoanApplication.Borrower.OwnershipTies[state.loanAppReducer.LoanApplication.Borrower.OwnershipTies.length-1];
        }
    }
    else if(_legalEntityFrom=="GuarantorOwner"){
        if (state.loanAppReducer.LoanApplication.Guarantors[_path[4]].RelatedEntity.OwnershipTies.length > 0) {
            _owner = getOwnerById(state.loanAppReducer.LoanApplication.Guarantors[_path[4]].RelatedEntity.OwnershipTies, ownerId);
            if(_owner==null)
                _owner = state.loanAppReducer.LoanApplication.Guarantors[_path[4]].RelatedEntity.OwnershipTies[state.loanAppReducer.LoanApplication.Guarantors[_path[4]].RelatedEntity.OwnershipTies.length-1];
        }
    }

    return {
        ownerInformation: _owner,
        ownerCommonData: state.loanAppReducer.LegalEntityCommonData,
        ownersList:((_legalEntityFrom=="BorrowerOwner")?(state.loanAppReducer.LoanApplication.Borrower.OwnershipTies):(state.loanAppReducer.LoanApplication.Guarantors[_path[4]].RelatedEntity.OwnershipTies)),
        legalEntity:((_legalEntityFrom=="BorrowerOwner")?(state.loanAppReducer.LoanApplication.Borrower):(state.loanAppReducer.LoanApplication.Guarantors[_path[4]].RelatedEntity)),
        savedStatus: state.loanAppReducer.SavedStatus,
        userID: state.loanAppReducer.LoanApplication.ApplicationSummary.EmployeeId
    };
}


function mapDispatchToProps(dispatch) {
    return {actions: bindActionCreators({CreateOwner,
                                        GetOwnerLegalEntity,
                                        SaveRelatedEntity,
                                        CreateOwnerForGuarantor,
                                        GetGuarantorOwnerLegalEntity,
                                        SaveGuarantorRelatedEntity,
                                        GetRelatedEntityByAssignementType,
                                        GetGuarantorRelatedEntityByAssignementType,
                                        IsInValidPOBox,
                                        UpdateActionStatus
                                    }, dispatch)};
}

export default connect(mapStateToProps,mapDispatchToProps)(OwnerContainer);
