﻿/* React libraries */
import React, {Component, PropTypes} from "react";
import {connect} from "react-redux";
import {bindActionCreators} from "redux";

/* plugin libraries */
import _ from "lodash";

/* Constant components */
import {
    LEGEND_CONSTANT,
    VALIDATION_CONSTANT,
    MESSAGE_CONSTANT, PRODUCT_INTEGRATIONCODE, PRODUCTREQUEST_CONSTANT
} from "../constants/ApplicationConstants"; 

/* Child components libraries */
import ProductRequest from "../components/ProductRequest";


/* LoanApp libraries */
import {renderSpinner} from "../components/form-components/Form";
import {parseBool, getFormattedData, getDisplayName, showSuccess, showWarning, showError, getProductMinValue, getProductMaxValue, isUndefinedOrNull, formatData} from "../utils/Functions";
import FormField from "../components/form-components/FormField";

/* Action components */
import {CreateProduct, SaveProduct, AddNewProduct, RemoveCollateralProductMapping} from "../actions/productAction";
import {GetProductCommonData, UpdateActionStatus, LeftNavigationControlIsDirty} from "../actions/commondataAction";

/* variable declaration start */
let _tempProductRequest = {};
let errorCollection = {};
let product;
let collateralList = [];
let actionType=null;
/* variable declaration end */

class ProductRequestContainer extends Component{
    constructor(props, context) {
        super(props, context);
        this.state = {
            productRequestInformation: Object.assign({}, props.productrequest),
            saving: false,
            doValidate : false,
            ajaxCallsInProgress: true,
            isUseOfFundsDisable:true,
            savedStatus:(this.props.savedStatus == undefined?{Product: false}:Object.assign({}, props.savedStatus)),
            isOpenDialog: false,
            isSubmit: false,
            useOfFundsList: (props.productCommonData!=undefined && props.productCommonData!=null)?(props.productCommonData.UseOfFundsList):([])
        };

        this.onFieldChange = this.onFieldChange.bind(this);
        this.onFieldBlur = this.onFieldBlur.bind(this);
        this.hasError = this.hasError.bind(this);
    }

    /* component lifecycle methods start */
    componentWillMount()
    {
        let _paramId=this.props.params.id;
        if(isUndefinedOrNull(this.props.productCommonData))
        {
            this.getProductCommonData();
            let _product = getProductRequestById(this.props.productList, _paramId);
            if(_product==null)
                this.addNewProduct();
        }
        else
        {
            let _product = getProductRequestById(this.props.productList, _paramId);
            if(_product==null)
                this.addNewProduct();
            else
            {
                if(_product.ProductId!=0)
                    this.setState({isUseOfFundsDisable:false});
                
                this.setState({productRequestInformation: Object.assign({}, _product), ajaxCallsInProgress: false});
            }
        }
    }

    componentWillReceiveProps(nextProps)
    {
        if(actionType!="SET_IS_DIRTY_ITEM")
        {
            if(this.props.productrequest!=null && nextProps.productrequest!=null && this.props.productrequest!=nextProps.productrequest) 
                this.setState({productRequestInformation: Object.assign({}, nextProps.productrequest)});
            if(this.props.params.id!=nextProps.params.id && nextProps.params.id==this.props.productList.length)
            {
                let _product=getProductRequestById(this.props.productList, nextProps.params.id);
                if(_product==null)
                    this.addNewProduct();
                else
                {
                    if(_product.ProductId!=0)
                        this.setState({isUseOfFundsDisable:false});
                
                    this.setState({productRequestInformation: Object.assign({},_product), ajaxCallsInProgress: false});
                }
            }
           
        }
    }

    componentDidUpdate(prevProps, prevState){
        if(this.state.isSubmit)
        {
            this.state.isSubmit = false;
            if(_.size(errorCollection)>0)
            {
                showError(VALIDATION_CONSTANT.PRODUCT_ERROR_MESSAGE);
                this.setState({saving: false});
            }
            else
            {
                let prevProduct=prevProps.productList[this.props.params.id];
                product = prevProduct;
                collateralList =  this.getCollateralProductMapping(product.ProductId);
                if(this.state.productRequestInformation.ProductType.IntegrationCode != prevProduct.ProductType.IntegrationCode  && collateralList.length>0) ///product.ProductType.IntegrationCode != prevProduct.ProductType.IntegrationCode  &&
                {
                    this.setState({isOpenDialog:true});
                }
                else 
                {
                    this.SaveProductInformation(true);
                    this.state.doValidate = false;
                }
            }
        }
    }

    /* component lifecycle methods end */

    /* event methods start */
    onFieldChange(e) {
        this.setState({isSubmit: false});
        const fieldName=e.target.name;
        this.state.productRequestInformation.IsDirty=true;
        let actionDisatchpObj = this.props.actions.LeftNavigationControlIsDirty(true);
        actionType=actionDisatchpObj.type;
        this.updateProduct(e);
        if(fieldName=="LoanType" || fieldName=="IsPrefunding"){
            this.enableUseOffunds();
        }
        else if(fieldName=="ProductType.IntegrationCode"){
            if(e.target.value!=PRODUCT_INTEGRATIONCODE.ACH)
            {
                this.setState({useOfFundsList:_.reject(this.props.productCommonData.UseOfFundsList, ['PurposeCode', 1033])});
            }
            else{
                this.setState({useOfFundsList: this.props.productCommonData.UseOfFundsList});
            }
        }
        else if(fieldName=="UseOfFunds"){
            if(this.state.productRequestInformation.ProductId==0 && this.state.productRequestInformation.ProductType.IntegrationCode!=PRODUCT_INTEGRATIONCODE.FOREIGN_EXCHANGE && this.state.productRequestInformation.ProductType.IntegrationCode!=PRODUCT_INTEGRATIONCODE.FOREIGNEXCHANGE_FER && this.state.productRequestInformation.ProductType.IntegrationCode!=-1)
            {
                let _isMultipleLOCorBCCExist = this.isMultipleLOCorBCCExist();

                if(!_isMultipleLOCorBCCExist)
                    this.SaveProductInformation(false);
            }
        }
    }

    onFieldBlur(e) {
        const fieldName=e.target.name;
        this.state.productRequestInformation.IsDirty=true;
        let actionDisatchpObj = this.props.actions.LeftNavigationControlIsDirty(true);
        actionType=actionDisatchpObj.type;
        if(fieldName=="TotalCreditExposureLimit" || fieldName=="TotalDebitExposureLimit" || fieldName=="RequestedAmount" || fieldName=="DailySettlementLimitAmt" || fieldName=="ForeignExchangeRiskLimitAmt")
        {
            this.updateProduct(e);
            this.enableUseOffunds();
        }
    }

    removeCollateralAndSaveProduct(){
        this.setState({isOpenDialog:false});
        this.SaveProductInformation(true, true);
        product={};
    }

    cancelDialogBox(isOpenDialog)
    {
        this.setState({isOpenDialog:isOpenDialog, saving: false});
    }
    /* event methods end */

    /* action methods start */
    getProductTypeList(productType, index, IsProductByBFNA)
    {
        if(productType!=-1)
        {   
            this.props.actions.CreateProduct(productType, this.state.productRequestInformation.ProductId, index, IsProductByBFNA, this.state.productRequestInformation.AssociatedProductId).then((data)=> {
                this.setState({productRequestInformation:  data, ajaxCallsInProgress: false});
                this.enableUseOffunds();
            }).catch(error=> {
                console.log(error.response.data.ExceptionMessage);
            });
        }
    }

    addNewProduct(){
        this.props.actions.AddNewProduct(-1).then(()=> {
            this.setState({productRequestInformation: Object.assign({}, this.props.productrequest)});
            this.setState({ajaxCallsInProgress: false});
        }).catch(error=> {
            console.log(error.response.data.ExceptionMessage);
        });
    }

    getProductCommonData(){
        let userID = this.props.userID;
        let legalEntityId = this.props.legalEntityId;
        this.props.actions.GetProductCommonData(legalEntityId, userID).then(()=> {
            this.setState({ajaxCallsInProgress: false});
            this.setState({useOfFundsList: this.props.productCommonData.UseOfFundsList});
        }).catch(error=> {
            console.log(error.response.data.ExceptionMessage);
        });
    }

    getCollateralProductMapping(prodId)
    {
        let list = _.filter(this.props.collateralList, function(o){
            return _.includes(o.ProductIds, prodId);
        });
        return list;
    }
    /* action methods end */


    updateProduct(e) {
        const fieldName = e.target.name;
        let fielValue = getFormattedData(e);

        if(fieldName=="ProductType.IntegrationCode")
        {
            this.getProductTypeList(fielValue, this.props.params.id, this.state.productRequestInformation.IsProductByBFNA);
            this.isBCCProduct(this.state.productRequestInformation);
        }
        else{
            if(fieldName == "IsBillPayerRegistered") {
                fielValue= !fielValue;
            }

            _tempProductRequest = this.state.productRequestInformation;
            _.set(_tempProductRequest, fieldName, fielValue);

            this.setState({productrequestinformation: _tempProductRequest});
        }
    }

    enableUseOffunds(){
        this.state.productRequestInformation.LoanType=3;

        if(this.state.productRequestInformation.ProductType.IntegrationCode==PRODUCT_INTEGRATIONCODE.ACH){
            if(this.state.productRequestInformation.LoanType!=-1 && this.state.productRequestInformation.TotalCreditExposureLimit>0 && this.state.productRequestInformation.TotalDebitExposureLimit>0 && !errorCollection.TotalCreditExposureLimit && !errorCollection.TotalDebitExposureLimit)
            {
                this.setState({isUseOfFundsDisable:false});
            }
            else if(this.state.productRequestInformation.LoanType!=-1 && this.state.productRequestInformation.IsPrefunding==true)
            {
                this.setState({isUseOfFundsDisable:false});
            }
            else
            {
                this.setState({isUseOfFundsDisable:true});
            }
        }
        else if(this.state.productRequestInformation.ProductType.IntegrationCode==PRODUCT_INTEGRATIONCODE.FOREIGN_EXCHANGE || this.state.productRequestInformation.ProductType.IntegrationCode==PRODUCT_INTEGRATIONCODE.FOREIGNEXCHANGE_FER){
            if(this.state.productRequestInformation.LoanType!=-1 && this.state.productRequestInformation.DailySettlementLimitAmt>0 && this.state.productRequestInformation.ForeignExchangeRiskLimitAmt>0 && !errorCollection.DailySettlementLimitAmt && !errorCollection.ForeignExchangeRiskLimitAmt)
            {
                this.setState({isUseOfFundsDisable:false});
            }
            else
            {
                this.setState({isUseOfFundsDisable:true});
            }
        }
        else if(this.state.productRequestInformation.LoanType!=-1 && this.state.productRequestInformation.ProductType.IntegrationCode!=-1){
            if(this.state.productRequestInformation.RequestedAmount>0 && !errorCollection.RequestedAmount)
            {
                this.setState({isUseOfFundsDisable:false});
            }
            else
            {
                this.setState({isUseOfFundsDisable:true});
            }
        }
        else
        {
            this.setState({isUseOfFundsDisable:true});
        }
    }

    hasError(error, e){
        let fieldName=e.name;
        if(error[fieldName])
            _.set(errorCollection, fieldName, error[fieldName]);
        else
            _.unset(errorCollection, fieldName);
    }

    save(showMessage, paramId)
    {
        console.log("Save", this.props.newLoaAppData);
        this.props.actions.SaveProduct(this.props.newLoaAppData, paramId).then(()=> {
            if(this.state.savedStatus.Product == undefined || !this.state.savedStatus.Product)
            {
                let newStatus = this.state.savedStatus;
                _.set(newStatus, "Product", true);
                this.props.actions.UpdateActionStatus(newStatus);
            }
            if(showMessage)
            {
                showSuccess(MESSAGE_CONSTANT.PRODUCT_REQUEST_SAVE_SUCCESS);
                showWarning(MESSAGE_CONSTANT.PRODUCT_REQUEST_ADD_LINK);
            }
            this.setState({productRequestInformation : this.props.newLoaAppData.Products[paramId]});
            this.setState({saving: false});
        }).catch(error=> {
            this.setState({saving: false});
            if(showMessage)
                console.log(error.response.data.ExceptionMessage);
        });
    }

    SaveProductInformation(showMessage, isModifyCollateral=false)
        {
            let _paramId =  this.props.params.id;
            console.log("Product Save Information", this.props.newLoaAppData.Products[_paramId]);
            this.state.productRequestInformation.ProductType = _.find(this.props.productCommonData.ProductTypeList, ['IntegrationCode', this.state.productRequestInformation.ProductType.IntegrationCode]);
            this.state.productRequestInformation.AssociatedProductId = this.props.newLoaAppData.Products[_paramId].AssociatedProductId;
            this.props.newLoaAppData.Products[_paramId] = this.state.productRequestInformation;
            this.props.newLoaAppData.Products[_paramId].IsDirty=true;
            this.props.newLoaAppData.Products[_paramId].DisplayName = ("Product Request " +  (parseInt(_paramId)+1));
            this.props.newLoaAppData.Products[_paramId].LoanType= document.getElementById("LoanType").value;
            
            if(this.props.newLoaAppData.Products[_paramId].ProductType.IntegrationCode == PRODUCT_INTEGRATIONCODE.ACH){
                this.props.newLoaAppData.Products[_paramId].ACHRiskIDTaxIDNumber= document.getElementById("ACHRiskIDTaxIDNumber").value;
            }
            
            if(isModifyCollateral){
                this.props.actions.RemoveCollateralProductMapping(this.props.collateralList, product).then(()=> {
                    this.save(showMessage, _paramId);
                }).catch(error=> {
                    console.log(error.response.data.ExceptionMessage);
                    this.setState({saving: false});
                });
            }
            else
            {
                this.save(showMessage, _paramId);
            }
        }

        isBCCProduct(product){
            let productTypeObject;
            if(product.Type==null)
            {
                productTypeObject = _.find(this.props.productCommonData.ProductTypeList, ['IntegrationCode', product.IntegrationCode]);
                return (productTypeObject!=undefined && productTypeObject.ProductTypeCategory=="BCC");
            }
            else
            {
                return (product.Type=="BCC");
            }
            return false;
        }

        isMultipleLOCorBCCExist()
        {
            let isBCCProductExist=_.find(this.props.productList, ['Type', "BCC"]);
            let isLOCProductExist=_.find(this.props.productList, ['IntegrationCode', PRODUCT_INTEGRATIONCODE.LINE_OF_CREDIT]);
            if(isBCCProductExist!=null && isBCCProductExist.ProductId!=this.state.productRequestInformation.ProductId && isBCCProductExist.ProductId!=0 && (this.state.productRequestInformation.IntegrationCode== "MASTERCARD-TRAV" || this.state.productRequestInformation.IntegrationCode== "MASTERCARD"))
            {
                showError(MESSAGE_CONSTANT.MULTIPLE_BCC_ERROR_MESSAGE);
                return true;
            }
            else if(isLOCProductExist!=null && isLOCProductExist.ProductId!=this.state.productRequestInformation.ProductId && isLOCProductExist.ProductId!=0 && this.state.productRequestInformation.IntegrationCode=="BLOC"){
                showError(MESSAGE_CONSTANT.MULTIPLE_LOC_ERROR_MESSAGE);
                return true;
            }
            return false;
        }

        ///Event to update the main reducer object by passing the local state object
        _onDone(e) {
            /* Fetch data from form collection*/
            let formData = $("form :input").serializeArray();
            let _isMultipleLOCorBCCExist = this.isMultipleLOCorBCCExist();

            if(!_isMultipleLOCorBCCExist)
            {
                let _tempProductRequest = this.state.productRequestInformation;
                {formData && formData.map((data, index) => {
                    data.value=formatData(data.value);
                    _.set(_tempProductRequest, data.name, data.value);
                })}

                this.setState({productRequestInformation: _tempProductRequest});
                errorCollection = {};
                this.setState({doValidate: true, isSubmit: true, saving: true});
            }
        }


        render() {
            if (this.state.ajaxCallsInProgress || this.props.productCommonData==undefined) {
                return (renderSpinner());
            }

            let minValue=getProductMinValue(this.state.productRequestInformation.ProductType.IntegrationCode);
            let maxValue=getProductMaxValue(this.state.productRequestInformation.ProductType.IntegrationCode);

            let nodeConfirmation =(<span>
                                    <button className="btn btn-primary" onClick={this.removeCollateralAndSaveProduct.bind(this)}>Yes</button>
                                    <button className="btn btn-primary" onClick={this.cancelDialogBox.bind(this, false)}>No</button>
                                 </span>);

        return(<div>
                        <div>
                        <FormField type="dialog" node={nodeConfirmation} isOpenDialog={this.state.isOpenDialog} Message={<div className="font-size-11px">{LEGEND_CONSTANT.PRODUCT_COLLATERAL_MAPPING}</div>} ModalTitle={PRODUCTREQUEST_CONSTANT.PRODUCT_COLLATERAL_MAPPING_REMOVAL} onClose={this.cancelDialogBox.bind(this, false)} />
                            </div>
                           <ProductRequest onFieldChange={this.onFieldChange}  
                            onFieldBlur={this.onFieldBlur} taxId={this.props.taxId}
                            displayName={getDisplayName(this.props.productList, this.props.params.id)}
                            data={this.state.productRequestInformation}
                            commonData={this.props.productCommonData} useOfFundsList={this.state.useOfFundsList}
                            isNextButtonDisable={this.state.saving}
                            onNextButtonClick={this._onDone.bind(this)} minValue={minValue} maxValue={maxValue} isBillPayerEnable={this.isBCCProduct(this.state.productRequestInformation)}
                            hasError={this.hasError} doValidate={this.state.doValidate} isUseOfFundsDisable={this.state.isUseOfFundsDisable} /></div>);
                        }
}

ProductRequestContainer.propTypes = {
    productrequest: PropTypes.object.isRequired,
    commonData: PropTypes.object.isRequired,
    productTypeId: PropTypes.string.isRequired,
    securityRole: PropTypes.string.isRequired,
    legalEntityId: PropTypes.string.isRequired,
    actions: PropTypes.object.isRequired
};

ProductRequestContainer.contextTypes = {
    router: PropTypes.object
};

///Get Product request based on id passed
function getProductRequestById(products, productRequestId) {
    let product = _.nth(products, productRequestId);
    if (product)
        return product;
    return null;
}

let mapStateToProps = (state, ownProps) => {
    const productRequestId = ownProps.params.id;    /// Get the product request id
    let _productRequest = {}; /// local constant variable to store product request

    /// If Product reducer having products return product based on the productid
    if (productRequestId && state.loanAppReducer.LoanApplication.Products.length > 0) {
        _productRequest =  Object.assign({}, getProductRequestById(state.loanAppReducer.LoanApplication.Products, productRequestId));
    }

    return {
        productListLength: state.loanAppReducer.LoanApplication.Products.length,
        productrequest: _productRequest,  
        productTypeId: (state.loanAppReducer.LoanAppInputData.Products.length>0 && state.loanAppReducer.LoanAppInputData.Products.ProductTypeId!=undefined)?(state.loanAppReducer.LoanAppInputData.Products.ProductTypeId):(""),
        securityRole: state.loanAppReducer.LoanApplication.ApplicationSummary.LoggedInUserSecurityRole,
        legalEntityId: state.loanAppReducer.LoanApplication.Borrower.Id,
        productCommonData: state.loanAppReducer.ProductCommonData,
        newLoaAppData: state.loanAppReducer.LoanApplication,
        userID: state.loanAppReducer.LoanApplication.ApplicationSummary.EmployeeId,
        productList:state.loanAppReducer.LoanApplication.Products,
        savedStatus: state.loanAppReducer.SavedStatus,
        collateralList: state.loanAppReducer.LoanApplication.Collaterals,
        ///isDirtyStatus: state.loanAppReducer.status,
        taxId:(state.loanAppReducer.LoanApplication.Borrower.EntityStructure!="I")?(state.loanAppReducer.LoanApplication.Borrower.TaxId):(state.loanAppReducer.LoanApplication.Borrower.SocialSecurityNumber)
    }
}

/// Dispatch product request actions
function mapDispatchToProps(dispatch) {
    return {actions: bindActionCreators({SaveProduct, CreateProduct, GetProductCommonData, AddNewProduct, UpdateActionStatus, RemoveCollateralProductMapping, LeftNavigationControlIsDirty}, dispatch)};
}

export default connect(mapStateToProps,mapDispatchToProps)(ProductRequestContainer);
