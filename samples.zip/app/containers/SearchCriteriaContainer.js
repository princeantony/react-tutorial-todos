﻿/*eslint-disable no-undef */

/* React libraries */
import React, { Component, PropTypes } from "react";
import { bindActionCreators } from "redux";
import {connect} from "react-redux";

/* LoanApp libraries */
import {isSearchCriteriaValid} from "../utils/Validation";
import {showError, getURLPath} from "../utils/Functions";

/* Action components */
import {SearchLegalEntities} from "../actions/searchAction";

/* Constant components */
import {APPLICATION_URL} from "../constants/ApplicationURL";
import {POSITION, VALIDATION_CONSTANT, VARIABLE_CONSTANT} from "../constants/ApplicationConstants";

/* Child components libraries */
import SearchCriteria from "../components/child-components/search/SearchCriteriaPage";

/* variable declaration start */
let searchPageHeader = VARIABLE_CONSTANT.CUSTOMER_SEARCH;
let _propsId, _legalEntityFrom;
/* variable declaration end */

class SearchCriteriaContainer extends Component {
    constructor(props, context) {
        super(props, context);
        this.state={
            searching: false
        };
    }

    /* component lifecycle methods start */
    componentWillMount() {
        let _path = getURLPath(location.pathname);
        _legalEntityFrom = _path[4];
        _propsId=this.props.params.id;

        if(_propsId == VARIABLE_CONSTANT.BORROWER_OWNER || _propsId == VARIABLE_CONSTANT.GUARNATOR_OWNER)
            searchPageHeader = VARIABLE_CONSTANT.OWNER_SEARCH;
        else if(_propsId == VARIABLE_CONSTANT.GUARNATOR)
            searchPageHeader =  VARIABLE_CONSTANT.GUARANTOR_SEARCH;
    }
    /* component lifecycle methods end */

    /* action methods start */
    _searchLegalEntities(_tinNo, _customerName, legalEntityId)
    {
        this.props.actions.SearchLegalEntities(_tinNo, _customerName, legalEntityId)
            .then(() => { this.setState({searching: false}); this.redirect();})
            .catch(error => {
                console.log(error.response.data.ExceptionMessage);
                this.setState({searching: false});
        });
    }
    /* action methods end */

    /* component events start */
    onKeyDown(e) {
        if(e.keyCode==13)
            this._redirectToSearchPage();
    }
    /* component events end */

    _resetSearchCriteria(){
        document.getElementById("TINSSN").value="";
        document.getElementById("CUSTOMER_NAME").value="";
    }


    redirect(){
        this.setState({searching: false});
        if(_propsId == VARIABLE_CONSTANT.BORROWER_OWNER)
        {
            this.context.router.push(APPLICATION_URL.BORROWER_OWNER_SEARCH_RESULT+ _propsId);
        }
        else if(_propsId == VARIABLE_CONSTANT.GUARNATOR)
        {
            this.context.router.push(APPLICATION_URL.GUARANTOR_SEARCH_RESULT+ _propsId);
        }
        else if(_propsId == VARIABLE_CONSTANT.GUARNATOR_OWNER)
        {
            this.context.router.push(APPLICATION_URL.GUARANTOR_OWNER_SEARCH_RESULT + _legalEntityFrom + "/" + _propsId);
        }
    }

    _redirectToSearchPage(){
        let _errors = isSearchCriteriaValid("TINSSN", "CUSTOMER_NAME");
        if (Object.keys(_errors).length==0)
        {
            this.setState({searching: true});
            let _tinNo= document.getElementById("TINSSN").value;
            let _customerName= document.getElementById("CUSTOMER_NAME").value;
            this._searchLegalEntities(_tinNo, _customerName, this.props.legalEntityId);
        }
        else if(_errors._ssnTinEin)
        {
            showError(VALIDATION_CONSTANT.SSN_TIN_EIN_ERROR);
        }
        else if(_errors.requiredOneField)
        {
            showError(VALIDATION_CONSTANT.SEARCH_ERROR);
        }
    }

    _renderSearchCriteria(){
        return(<div>
                        <SearchCriteria
                        searchPageHeader={searchPageHeader}
                        onKeyDown={this.onKeyDown.bind(this)} 
                        isDisabled={this.state.searching} 
                        onResetClick={this._resetSearchCriteria.bind(this)} 
                        onSearchClick={this._redirectToSearchPage.bind(this)} />
            </div>);
    }

    render() {
        return(<div>{this._renderSearchCriteria()}</div>);
    }
}

SearchCriteriaContainer.contextTypes = {
    router: PropTypes.object
};

let mapStateToProps = (state) => {
    return {
        searchResults:state.loanAppReducer.SearchResults,
        legalEntityId: state.loanAppReducer.LoanApplication.Borrower.Id
    }
}

function mapDispatchToProps(dispatch) {
    return  {actions: bindActionCreators({SearchLegalEntities}, dispatch)};
}

export default connect(mapStateToProps,mapDispatchToProps)(SearchCriteriaContainer);
