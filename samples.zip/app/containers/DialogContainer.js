/* React libraries */
import React, {Component} from "react";

/* Child components libraries */
import DialogBox from "../components/form-components/DialogBox";

class DialogContainer extends Component{
    constructor(props) {
        super(props);
        this.state = {
           isOpenDialog: false
        };
    }

     componentWillReceiveProps(nextProps){
        this.setState({isOpenDialog: nextProps.isOpenDialog});
    }
    
     openDialogbox(){
        this.setState({isOpenDialog:true});
     }

    closeDialogbox(){
        this.setState({isOpenDialog:false});
         this.props.handleDialogYesClick(false);
    }

    doYesClick(){
        this.setState({isOpenDialog:false});
        this.props.handleDialogYesClick(true);
    }

     render() {
         let nodeConfirmation =(<span>
                                      <button className="btn btn-primary" onClick={this.doYesClick.bind(this)}>Yes</button>
                                      <button className="btn btn-primary" onClick={this.closeDialogbox.bind(this)}>No</button>
                                </span>);

        const{message, modalTitle}=this.props;

        return(<div><DialogBox
                     node={nodeConfirmation} 
                     isOpenDialog={this.state.isOpenDialog} 
                     Message={message} 
                     ModalTitle={modalTitle} 
                     onClose={this.closeDialogbox.bind(this)} /></div>);
        }
}
export default DialogContainer;