/* React libraries */
import React, {Component, PropTypes} from "react";
import {bindActionCreators} from "redux";
import {connect} from "react-redux";
import {render} from "react-dom";

/* plugin libraries */
import _ from "lodash";

/* LoanApp libraries */
import {parseBool, getFormattedData, showSuccess, showWarning, showError, getAffiliate, formatData, isUndefinedOrNull} from "../utils/Functions";
import {renderSpinner} from "../components/form-components/Form";

/* Child components libraries */
import Borrower from "../components/Borrower";
import ErrorContainer from "./ErrorContainer";

/* Constant components */
import {VALIDATION_CONSTANT, APP_CONSTANT, MESSAGE_CONSTANT} from "../constants/ApplicationConstants";
import {APPLICATION_URL} from "../constants/ApplicationURL";

/* Action components */
import {GetLegalEntityCommonData, UpdateActionStatus} from "../actions/commondataAction";
import {GetBorrower, SaveBorrower, CreateLegalEntity, IsBorrowerHasBlanketGuarantors} from "../actions/legalEntityAction";

/* variable declaration start */
let isIndividual = false;
let borrowerAction = "";
let entityStructureLLCs = [];
let errorCollection = {};
let defaultData={};
let businessAddressIndex = 0;
let homeAddressIndex = 0;
/* variable declaration end */

class BorrowerContainer extends Component {
    constructor(props, context) {
        super(props, context);
        this.state = {
            borrowerInformationData: Object.assign({}, props.borrowerinformation),
            saving: false,
            isBorrowerInfoLoaded: false,
            isBorrowerCommonDataLoaded: false,
            isEntityStructureDisable: false,
            doValidate : false,
            isNewHomeAddressSelected: null,
            isNewBusinessAddressSelected: null, 
            isSubmit : false,
            savedStatus:(this.props.savedStatus == undefined?{Borrower: false}:Object.assign({}, props.savedStatus))
        };

        this.onFieldChange = this.onFieldChange.bind(this);
        this.onEntityChange = this.onEntityChange.bind(this);
    }

    /* component lifecycle methods start */
    componentWillMount()
    {
        borrowerAction = this.props.params.id;
        if(borrowerAction!="active" && borrowerAction!="add")
        {
            this.props.actions.IsBorrowerHasBlanketGuarantors(borrowerAction).then((response)=> {
                (response.data)?render(<ErrorContainer />, document.getElementById(APP_CONSTANT.APP)):this.navigateToExistBorrower();
            }).catch(error=> {
                console.log(error.response.data.ExceptionMessage);
            });
        }
        else
        {
            /*Call an ajax axios call to get common data for legal entity; those are country list, State list,
             Facilities list and EntityStructure list. This should invoke only once */
            if (this.props.borrowercommondata == null || this.props.borrowercommondata == undefined) {
                this.getLegalEntityCommonData();
            }

            if (borrowerAction == "add") // when the user click on "Add Borrower" button
            {
                this.props.actions.CreateLegalEntity(this.props.bfnaborrowerinformation).then(()=> {
                    this.setState({isBorrowerInfoLoaded: true, borrowerInformationData: Object.assign({}, this.props.borrowerinformation)});
                    defaultData= Object.assign({}, this.props.borrowerinformation);
                }).catch(error=> {
                    console.log(error.response.data.ExceptionMessage);
                });
            }
            else if (borrowerAction == "active") {
                this.setState({isBorrowerInfoLoaded: true, isBorrowerCommonDataLoaded: true, isEntityStructureDisable: true, isNewHomeAddressSelected: this.state.borrowerInformationData.isNewHomeAddressSelected, isNewBusinessAddressSelected: this.state.borrowerInformationData.isNewBusinessAddressSelected});
            }
        }
    }

    componentWillReceiveProps(nextProps){
        if(this.props.borrowerinformation!=nextProps.borrowerinformation)
        {
            this.setState({borrowerInformationData: Object.assign({},nextProps.borrowerinformation)});
            defaultData= Object.assign({}, nextProps.borrowerinformation);
        }
    }

    shouldComponentUpdate(nextProps, nextState) {
        return (nextState.isBorrowerInfoLoaded && nextState.isBorrowerCommonDataLoaded);
    }

    componentWillUpdate(nextProps, nextState) {
        if (nextState.isBorrowerInfoLoaded && nextState.isBorrowerCommonDataLoaded) {
            isIndividual = this.props.borrowerinformation.IsIndividual;
            if (!isIndividual) {
                /* If the Entity StructureCode is LLC, then we need to showLLC&LLCSO items in the EntityStructure dropdown for non-induvidual*/
                let llcStructureCodes = ["LLC", "LLCSO"];
                if (llcStructureCodes.indexOf(this.props.bfnaborrowerinformation.StructureCode) > -1 || llcStructureCodes.indexOf(this.state.borrowerInformationData.EntityStructure.StructureCode) > -1){
                    entityStructureLLCs = _(this.props.borrowercommondata.EntityStructures).keyBy('StructureCode').at(llcStructureCodes).value();
                }
            }
        }
    }

    componentDidUpdate(prevProps, prevState){
        if(this.state.isSubmit)
        {
            this.state.isSubmit = false;
            if(_.size(errorCollection)>0)
                showError(VALIDATION_CONSTANT.BORROWER_ERROR_MESSAGE);
            else
            {
                this.saveBorrowerFormData();
                this.state.doValidate = false;
            }
        }
    }
    /* component lifecycle methods end */

    /* component event methods start */
    onFieldChange(e) {
        this.updateBorrower(e);
    }

    onEntityChange(e) {
        let structureCode = e.target.value;
        let selectedEntityStructure = _.find(this.props.borrowercommondata.EntityStructures, ['StructureCode', structureCode]);
        this.state.borrowerInformationData.EntityStructure = selectedEntityStructure;
    }
    /* component event methods end */

    getLegalEntityCommonData(){
        this.props.actions.GetLegalEntityCommonData().then(()=> {
            this.setState({isBorrowerCommonDataLoaded: true});
        }).catch(error=> {
            console.log(error.response.data.ExceptionMessage);
        });
    }

    navigateToExistBorrower(){
        if(isUndefinedOrNull(this.props.borrowercommondata)){
            this.getLegalEntityCommonData();
        }
        if (borrowerAction > 0) // when the user click on "Continue" button
        {
            let brwrAndNewAddresses = {
                BorrowerId: borrowerAction,
                NewAddresses: this.props.bfnaborrowerinformation.Addresses
            };
            this.props.actions.GetBorrower(brwrAndNewAddresses).then(() => {
                this.setState({borrowerInformationData: Object.assign({}, this.props.borrowerinformation)});
                this.setState({isBorrowerInfoLoaded: true});
            }).catch(error => {
                console.log(error.response.data.ExceptionMessage);
            });
        }
    }

    updateBorrower(e) {
        const fieldName = e.target.name;
        let fielValue = getFormattedData(e);

        let _tempBorrower = this.state.borrowerInformationData;
        _.set(_tempBorrower, fieldName, fielValue);
        this.setState({borrowerInformationData: _tempBorrower});
        this.setState({isSubmit: false});
    }

    //Revisit
    onMismatchClick(name, value) {
        this.setState({isSubmit: false});
        if (name == "BusinessIndividual_true" || name == "BusinessIndividual_false") {
            this.state.isNewBusinessAddressSelected = value == "2" ? true : false;
            businessAddressIndex = value;
        }
        if (name == "HomeIndividual_true") {
            this.state.isNewHomeAddressSelected = value == "2" ? true : false;
            homeAddressIndex = value;
        }
    }

    hasError(error, e){
        let fieldName=e.name;
        if(e.id!=undefined && e.id!=null)
            fieldName = e.id;
        if(error[fieldName])
            _.set(errorCollection, fieldName, error[fieldName]);
    }

    saveBorrowerFormData()
    {
        this.setState({saving: true});
        /* Fetch data from form collection*/
        let formData = $("form :input").not('#Business_facilitiesDiv, #Home_facilitiesDiv').serializeArray();
        let homeFacilityFields=$("#Home_facilitiesDiv :input").serializeArray();
        let businessFacilityFields=$("#Business_facilitiesDiv :input").serializeArray();


        let _tempBorrower = this.state.borrowerInformationData;

        _.set(_tempBorrower, "FacilityInformation[0]", _.zipObject(_.map(homeFacilityFields, 'name'), _.map(homeFacilityFields, 'value')));
        _.set(_tempBorrower, "FacilityInformation[1]", _.zipObject(_.map(businessFacilityFields, 'name'), _.map(businessFacilityFields, 'value')));

        formData && formData.map((data, index) => {
            /// data.value = formatData(data.value);
            if(data.name == "Affiliate")
            {
                _.set(_tempBorrower, data.name, getAffiliate(this.props.borrowercommondata.Affilliates, data.value));   
            }
            else
            {
                _.set(_tempBorrower, data.name, data.value);
            }

        });

        _.set(_tempBorrower, "isNewBusinessAddressSelected", ((!this.state.isNewBusinessAddressSelected)?false:true));
        _.set(_tempBorrower, "isNewHomeAddressSelected", ((!this.state.isNewHomeAddressSelected)?false:true));

        let brwrAndNewAddresses = {
            BorrowerId: this.state.borrowerInformationData.Id,
            Borrower: this.state.borrowerInformationData,
            NewAddresses: this.props.bfnaborrowerinformation.Addresses
        };

        this.props.actions.SaveBorrower(brwrAndNewAddresses).then(() => {
            if(!this.state.savedStatus.Borrower){
                 let newStatus = this.state.savedStatus;
                 _.set(newStatus, "Borrower", true);
                 this.setState({isEntityStructureDisable:true});
                this.props.actions.UpdateActionStatus(newStatus);
            }
              this.redirect();
            }).catch(error => {
                this.setState({saving: false});
                console.log(error.response.data.ExceptionMessage);
         });
    }

    onNextButtonClick(e) {
        errorCollection = {};
        this.setState({doValidate: true});
        this.setState({isSubmit: true});
    }

    redirect() {
        this.setState({saving: false});
        showSuccess(MESSAGE_CONSTANT.BORROWER_REQUEST_SAVE_SUCCESS);
        isIndividual?this.context.router.push(APPLICATION_URL.PRODUCT_REQUEST_URL + "0"):showWarning(MESSAGE_CONSTANT.OWNER_ADD_LINK);
    }

    render() {
        if (!this.state.isBorrowerCommonDataLoaded || !this.state.isBorrowerInfoLoaded) {
            return (renderSpinner());
        }

        return (<div><Borrower onFieldChange={this.onFieldChange}  onEntityChange={this.onEntityChange} onMismatchClick={this.onMismatchClick.bind(this)}
            data={this.state.borrowerInformationData}  initialData={defaultData} homeAddressIndex={homeAddressIndex}
            isEntityStructureDisable={this.state.isEntityStructureDisable} bfnaData={this.props.bfnaborrowerinformation}
            commonData={this.props.borrowercommondata} affiliateCode={this.props.affiliateCodeFromBFNA} isIndividual={isIndividual}
            isNextButtonDisable={this.state.saving} entityStructureLLCs={entityStructureLLCs} borrowerAction={borrowerAction} businessAddressIndex={businessAddressIndex}
            hasError={this.hasError.bind(this)} doValidate={this.state.doValidate} onNextButtonClick={this.onNextButtonClick.bind(this)} /></div>);
        }
}

BorrowerContainer.propTypes = {
    borrowerinformation: PropTypes.object.isRequired,
    bfnaborrowerinformation: PropTypes.object.isRequired,
    borrowercommondata: PropTypes.object.isRequired,
    affiliateCodeFromBFNA: PropTypes.string.isRequired,
    actions: PropTypes.object.isRequired,
};

BorrowerContainer.contextTypes = {
    router: PropTypes.object
};

let mapStateToProps = (state) => {
    return {
        borrowerinformation: state.loanAppReducer.LoanApplication.Borrower,
        bfnaborrowerinformation: state.loanAppReducer.LoanAppInputData.Borrower,
        borrowercommondata: state.loanAppReducer.LegalEntityCommonData,
        affiliateCodeFromBFNA: state.loanAppReducer.LoanAppInputData.AffiliateAcro,
        savedStatus: state.loanAppReducer.SavedStatus
    };
}

function mapDispatchToProps(dispatch) {
    return {
        actions: bindActionCreators({SaveBorrower, CreateLegalEntity, GetLegalEntityCommonData, GetBorrower, IsBorrowerHasBlanketGuarantors, UpdateActionStatus}, dispatch)
    };
}
export default connect(mapStateToProps, mapDispatchToProps)(BorrowerContainer);
