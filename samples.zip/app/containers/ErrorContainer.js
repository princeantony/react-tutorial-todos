﻿/*eslint-disable no-undef */
/* React libraries */
import React, {Component} from "react";

/* Child components libraries */
import Header from "../components/Header";
import Footer from "../components/Footer";

class ErrorContainer extends Component{

    _onClose(e) {
        window.close();
    }

    render() {
        return(<div>
                <div>
                    <Header/>
                    <div className="min-height">
                            <div><p className="bg-danger"><span>The Borrower selected has existing blanket guarantees tied to its CCAS Customer number.</span><br/> <span>Please contact the Product Support team at </span><span><i className="fa fa-phone-square" aria-hidden="true"></i><b>{ccasCustomerNumber}</b></span><span> to remove the blanket guaranty from the CCAS Customer number prior to starting the loan application.</span></p></div>
                            <div className="col-lg-12 pad-t-0px pad-b-13px">
                                    <input type="button" className="btn btn-primary pull-right" value="Close" onClick={this._onClose.bind(this)}/>
                            </div>
                    </div>
                    <Footer/>
                 </div>
            </div>);
        }
}

export default ErrorContainer;