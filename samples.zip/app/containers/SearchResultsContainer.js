﻿/*eslint-disable no-undef */

/* React libraries */
import React, { Component, PropTypes } from "react";
import {bindActionCreators} from "redux";
import {connect} from "react-redux";

/* LoanApp libraries */
import {getURLPath, isUndefinedOrNull} from "../utils/Functions";

/* Constant components */
import {APPLICATION_URL} from "../constants/ApplicationURL";
import {VARIABLE_CONSTANT} from "../constants/ApplicationConstants";

/* Child components libraries */
import SearchGrid from "../components/child-components/search/SearchGrid";
import {renderSpinner} from "../components/form-components/Form";

/* variable declaration start */
let customerPageHeader = VARIABLE_CONSTANT.CUSTOMER_SEARCH;
let addNewButtonText = "Customer";
let _legalEntityId = "add";
let _legalEntityFrom, _propsId;
/* variable declaration end */

class SearchResultContainer extends Component {
    constructor(props, context) {
        super(props, context);
        this.state = {
            isContinueEnable:false
        };
    }

    /*component lifecycle methods start*/
    componentWillMount() {
         _propsId= this.props.params.id;
         let _path = getURLPath(location.pathname);
        _legalEntityFrom = _path[4];

        if(_propsId == VARIABLE_CONSTANT.BORROWER_OWNER)
        {
            customerPageHeader = VARIABLE_CONSTANT.OWNER_SEARCH;
            addNewButtonText = "Borrower Owner";
        }
        else if(_propsId == VARIABLE_CONSTANT.GUARNATOR_OWNER)
        {
            customerPageHeader = VARIABLE_CONSTANT.OWNER_SEARCH;
            addNewButtonText = "Guarantor Owner";
        }
        else if(_propsId == VARIABLE_CONSTANT.GUARNATOR)
        {
            customerPageHeader = VARIABLE_CONSTANT.GUARANTOR_SEARCH;
            addNewButtonText = "Guarantor";
        }
    }
    /*component lifecycle methods end*/

    onRowSelect(row, isSelected){
        if(isSelected)
        {
            _legalEntityId= row.LegalEntityId;
            this.setState({isContinueEnable: true});
        }
        else
        {
            _legalEntityId="add";
            this.setState({isContinueEnable: false});
        }
    }

    redirectToCustomer(_legalEntityId){
        if(_propsId==VARIABLE_CONSTANT.BORROWER_OWNER)
            this.context.router.push(APPLICATION_URL.BORROWER_OWNER + _legalEntityId);
        else if(_propsId==VARIABLE_CONSTANT.GUARNATOR)
            this.context.router.push(APPLICATION_URL.GUARANTOR + _legalEntityId);
        else if(_propsId==VARIABLE_CONSTANT.GUARNATOR_OWNER)
            this.context.router.push(APPLICATION_URL.GUARANTOR_OWNER + _legalEntityFrom + "/" + _legalEntityId);
    }

    _redirectToSearchCriteria(){
        if(_propsId==VARIABLE_CONSTANT.BORROWER_OWNER)
            this.context.router.push(APPLICATION_URL.BORROWER_OWNER_SEARCH_CRITERIA + _propsId);
        else if(_propsId==VARIABLE_CONSTANT.GUARNATOR)
            this.context.router.push(APPLICATION_URL.GUARANTOR_SEARCH_CRITERIA_PAGE + _propsId);
        else if(_propsId==VARIABLE_CONSTANT.GUARNATOR_OWNER)
            this.context.router.push(APPLICATION_URL.GUARANTOR_OWNER_SEARCH_CRITERIA + _legalEntityFrom + "/" + _propsId);
    }

    _renderSearchGrid(){
        return(<div>
                <SearchGrid searchcustomerPageHeaderText={customerPageHeader}
                displayValue={this.props.searchresults}
                addNewButtonDisplayText={addNewButtonText} isHover={true} isSort={(!(this.props.searchresults==0))}
                isSearch={false} selectType="radio"
                onRowSelect={this.onRowSelect.bind(this)}
                onAddButtonClick={this.redirectToCustomer.bind(this, 'add')}
                onContinueButtonClick={this.redirectToCustomer.bind(this, _legalEntityId)}
                isContinueDisable={!this.state.isContinueEnable}
                showErrorMessage={true}  searchAgain={true}
                onSearchAgainClick={this._redirectToSearchCriteria.bind(this)} />
            </div>);
        }

        render() {
            if(isUndefinedOrNull(this.props.searchresults))
                    return (renderSpinner());
             return (<div>{this._renderSearchGrid()}</div>);
    }
}

SearchResultContainer.propTypes = {
    searchresults: PropTypes.object.isRequired,
    actions: PropTypes.object.isRequired
};

SearchResultContainer.contextTypes = {
    router: PropTypes.object
};

let mapStateToProps = (state) => {
    return {
        searchresults:state.loanAppReducer.SearchResults
    }
}

export default connect(mapStateToProps)(SearchResultContainer);
