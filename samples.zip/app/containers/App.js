/* React libraries */
import React, {Component} from "react";
import {bindActionCreators} from "redux";
import {connect} from "react-redux";

/* Child components libraries */
import Header from "../components/Header";
import ApplicationSummary from "../components/ApplicationSummary";
import LeftNavigation from "../components/LeftNavigation";
import SearchPage from "../components/SearchPage";
import SubmitSection from "../components/SubmitSection";
import Footer from "../components/Footer";

/* Constant components */
import {APPLICATION_URL} from "../constants/ApplicationURL";

class App extends Component {
    constructor(props)
    {
        super(props);
        this.state = {
            isDisclosureViewed:false
        };
    }

    onDisclosureLinkClick(isViewed){
        this.setState({isDisclosureViewed:isViewed});
    }

    render() {
        return (
            <div className="container page-shadow pad-l-0px pad-r-0px">
               
                    <Header employeeName ={this.props.applicationsummary.EmployeeName} />
                
                {/*Application Summary Section*/}
                  <div className="row pad-t-0px pad-b-0px">
                    <div className="col-md-12 mar-b-15px">
                        <ApplicationSummary applicationsummary={this.props.applicationsummary} confirmationDetails={this.props.loanApplicationData}/>
                    </div>
                </div>

                {/*Main Section*/}
                <div className="row">
                    <div className="col-lg-12  ">
                        {/*Left Navigation Section*/}
                        <div className="col-md-3 wid-100-per-xs  pad-r-0px-md pad-r-0px-md pad-l-0px pad-r-0px mar-t-m-8px">
                            <LeftNavigation onDisclosureLinkClick={this.onDisclosureLinkClick.bind(this)} />
                        </div>
                        {/*Right Panel Section*/}
                        <div className="col-lg-9 pad-l-15px pad-r-0px mar-t-m-15px pad-l-0px-xs pad-r-0px-xs">
                            <div>{this.props.children}</div>
                            <div className="col-lg-12">
                                {(this.props.location.pathname != APPLICATION_URL.SEARCH_URL && this.props.location.pathname != APPLICATION_URL.GUARANTOR_SEARCH_RESULT) ?
                                    <SubmitSection finalappdata={this.props.loanApplicationData} isDisclosureViewed={this.state.isDisclosureViewed} /> : ""}
                            </div>
                        </div>
                    </div>
                </div>
                
                    <div className="col-lg-12 bg-clr-darknavy">
                        <Footer />
                    </div>
                
            </div>
        )
    }
}

let mapStateToProps = (state) => {
    return {
        applicationsummary: state.loanAppReducer.LoanApplication.ApplicationSummary,
        loanApplicationData: state.loanAppReducer.LoanApplication,
        productListLength: state.loanAppReducer.LoanApplication.Products.length
    }
};

export default connect(mapStateToProps)(App);
