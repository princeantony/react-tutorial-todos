﻿/* React libraries */
import React, {PropTypes, Component} from "react";
import {bindActionCreators} from "redux";
import {connect} from "react-redux";

/* plugin libraries */
import _ from "lodash";

/* LoanApp libraries */
import {parseBool, getFormattedData, showSuccess, showError, showWarning, getDisclosures, formatData} from "../utils/Functions";

/* Constant components */
import {CONFIG_KEYS, MESSAGE_CONSTANT, VALIDATION_CONSTANT, ADDITIONAL_INFORMATION, PRODUCT_INTEGRATIONCODE} from "../constants/ApplicationConstants";
import {APPLICATION_URL} from "../constants/ApplicationURL";

/* Action components */
import {SaveAdditionalInformation} from '../actions/additionalInformationAction';
import {LeftNavigationControlIsDirty} from "../actions/commondataAction";

/* Child components libraries */
import AdditionalInformation from "../components/AdditionalInformation";


/* variable declaration start */
let whichEntity = [];
let errorCollection = {};
let actionType=null;
/* variable declaration end */

class AdditionalInformationContainer extends Component {
    constructor(props, context) {
        super(props, context);
        this.state = {
            additionalInformation: Object.assign({}, props.additionalinformation),          
            errors: {},
            displayGroupEmail: false,
            saving: false,
            doValidate : false
        };  
        this.onFieldChange= this.onFieldChange.bind(this);
        this.onFieldBlur= this.onFieldBlur.bind(this);
    }

    /* component lifecycle methods start */
    componentWillMount() {  
        whichEntity = [];
        // To populate Borrower name
        let borroerLE = ((this.props.borrower.IsIndividual)?(this.props.borrower.FirstName +" " +this.props.borrower.LastName):(this.props.borrower.LegalName))
        whichEntity.push({"Key":this.props.borrower.id, "Value": borroerLE})

        // To populate Guarantor name
        this.props.guarantorList.map((data, index) => {
            let name = ((data.RelatedEntity.IsIndividual)?(data.RelatedEntity.FirstName +" " +data.RelatedEntity.LastName):(data.RelatedEntity.LegalName))
            whichEntity.push({"Key":data.RelatedEntity.Id, "Value":name});
        }); 
        
        let tmfcsProduct = _.findIndex(this.props.productsList, function(pl) { 
            return (pl.ProductType.IntegrationCode == PRODUCT_INTEGRATIONCODE.ACH || pl.ProductType.IntegrationCode == PRODUCT_INTEGRATIONCODE.COMMERCIAL_CARD); 
        });   
        
        if(tmfcsProduct != -1){
            this.setState({displayGroupEmail: true});
        }        
    } 

    componentDidUpdate(prevProps, prevState){
        if(prevState.doValidate != this.state.doValidate)
        {
            this.state.doValidate = false;
            if(_.size(errorCollection)>0)
                showError(VALIDATION_CONSTANT.ADDITIONALINFO_ERROR_MESSAGE);
            else
                this.saveAdditionalInformation();
        }
    }
    /* component lifecycle methods end */

    /* action methods start */
    saveAdditionalInformation()
    {
        this.props.actions.SaveAdditionalInformation(this.state.additionalInformation);
        showSuccess(ADDITIONAL_INFORMATION.ADDITIONAL_INFO_SAVE_SUCCESS);
        let disclosures = getDisclosures(this.props.productsList);
        if(disclosures.length>0)
            showWarning(MESSAGE_CONSTANT.DISCLOSURE_MESSAGE);
        this.setState({saving: false});
    }
    /* action methods end */

    hasError(error, e){
        let fieldName=e.name;
        if(error[fieldName])
            _.set(errorCollection, fieldName, error[fieldName]);
        else
            _.unset(errorCollection, fieldName);
    }

    /* component events start */
    onFieldBlur(e){
        let actionDisatchpObj = this.props.actions.LeftNavigationControlIsDirty(true);
        actionType=actionDisatchpObj.type;
    }

    onFieldChange(e){
        let actionDisatchpObj = this.props.actions.LeftNavigationControlIsDirty(true);
        actionType=actionDisatchpObj.type;
    }

    _onDone(e) {
        this.setState({saving: true});
        /* Fetch data from form collection*/
        let formData = $("form :input").serializeArray();

        let _tempAdditionalInformation =  this.state.additionalInformation;
        {
            formData && formData.map((data, index) => {
                data.value = formatData(data.value);
                _.set(_tempAdditionalInformation, data.name, data.value);
            })
        }
        this.setState({additionalInformation: _tempAdditionalInformation});
        errorCollection = {};
        this.setState({doValidate: true});
    }
    /* component events end */

    render() {
        return (<div><AdditionalInformation additionalInfo={this.state.additionalInformation}
                                            displayGroupEmail={this.state.displayGroupEmail}
                                            onFieldChange={this.onFieldChange} onFieldBlur={this.onFieldBlur}
                                            onNextButtonClick={this._onDone.bind(this)}
                                            whichEntity={whichEntity}
                                            hasError={this.hasError.bind(this)} doValidate={this.state.doValidate} /></div>);
    }
}

AdditionalInformationContainer.propTypes = {
    additionalinformation: PropTypes.object.isRequired,
    userDetails: PropTypes.object.isRequired,
    guarantorList: PropTypes.object.isRequired,
    borrower: PropTypes.object.isRequired,
    actions: PropTypes.object.isRequired
};

let mapStateToProps = (state) => {
    let additionalInfo = state.loanAppReducer.LoanApplication.AdditionalInformation;
    let userObj= {
        Id: state.loanAppReducer.LoanApplication.ApplicationSummary.EmployeeId,
        Name: state.loanAppReducer.LoanApplication.ApplicationSummary.EmployeeName
    }

    let _additionalInformation = {
        RecipientEmail: state.loanAppReducer.LoanApplication.User.EmailId,
        GroupEmail: CONFIG_KEYS.TMFCS_SETUPUSER_GROUP_EMAIL,
        user: userObj
    };

    ///console.log("map State to props", ((additionalInfo != undefined && additionalInfo != null) ? (additionalInfo) : _additionalInformation));
    return {
        additionalinformation: ((additionalInfo != undefined && additionalInfo != null) ? (additionalInfo) : _additionalInformation),
        userDetails: state.loanAppReducer.LoanApplication.User,
        productsList: state.loanAppReducer.LoanApplication.Products,
        productTypeList: ((state.loanAppReducer.ProductCommonData != undefined && state.loanAppReducer.ProductCommonData != null) ? (state.loanAppReducer.ProductCommonData.ProductTypeList) : ([])),
        guarantorList:state.loanAppReducer.LoanApplication.Guarantors,
        borrower:state.loanAppReducer.LoanApplication.Borrower,
        creditRequestIdBLC:state.loanAppReducer.LoanApplication.BLCCreditRequestId, 
        creditRequestIdBCC:state.loanAppReducer.LoanApplication.BCCCreditRequestId,
    };
}

function mapDispatchToProps(dispatch) {
    return {
        actions: bindActionCreators({SaveAdditionalInformation, LeftNavigationControlIsDirty}, dispatch)
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(AdditionalInformationContainer);