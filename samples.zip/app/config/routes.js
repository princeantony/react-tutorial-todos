/* React libraries */
import React from "react";
import { Route, IndexRoute } from "react-router";

/* Child components libraries */
import App from "../containers/App";
import Main from "../components/Main";
import Search from "../components/SearchPage";
import Borrower from "../containers/BorrowerContainer";
import ProductRequest from "../containers/ProductRequestContainer";
import GuarantorSearchCriteriaPage from "../components/GuarantorSearchCriteriaPage";
import GuarantorSearch from "../components/GuarantorSearch";
import Guarantor from "../components/Guarantor";
import Collateral from "../components/Collateral";
/*For Owner*/
import SearchCriteraiContainer from "../containers/SearchCriteriaContainer";
import SearchResultContainer from "../containers/SearchResultsContainer";
import OwnerContainer from "../containers/OwnerContainer";
import CardholderContainer from "../containers/CardholderContainer";
import AdditionalInformationContainer from "../containers/AdditionalInformationContainer";
import LoanAppRoute from "../components/LoanAppRoute";

import {VARIABLE_CONSTANT} from "../constants/ApplicationConstants";
let url = VARIABLE_CONSTANT.BASE_URL;

export default (
  <Route path={url +"Launch"} component={App}>
      <Route path={url +"Search"} component={Search} />
      <Route path={url +"productRequest/(:id)"}component={ProductRequest} />
      <Route path={url +"Borrower/(:id)"} component={Borrower} />
      <Route path={url +"GuarantorSearchCriteriaPage/(:id)"} component={SearchCriteraiContainer} />
      <Route path={url +"GuarantorSearch/(:id)"} component={SearchResultContainer} />
      <Route path={url +"Guarantor/(:id)"}  component={Guarantor} />
      <Route path={url +"Collateral/(:id)"} component={Collateral} />
      <Route path={url +"CardHolder/(:id)"} component={CardholderContainer} />
      /*Borrower Owner*/
      <Route path={url +"BorrowerOwnerSearchCriteria/(:id)"} component={SearchCriteraiContainer} />
      <Route path={url +"BorrowerOwnerSearchResult/(:id)"} component={SearchResultContainer} />
      <Route path={url +"BorrowerOwner/(:id)"} component={OwnerContainer} />
      /*Guarantor Owner*/
      <Route path={url +"GuarantorOwnerSearchCriteria/(:guarantorIndex)/(:id)"} component={SearchCriteraiContainer} />
      <Route path={url +"GuarantorOwnerSearchResult/(:guarantorIndex)/(:id)"} component={SearchResultContainer} />
      <Route path={url +"GuarantorOwner/(:guarantorIndex)/(:id)"}  component={OwnerContainer} />
      <Route path={url + "AdditionalInformation"} component={AdditionalInformationContainer} />
      <Route path={url + "LoanAppRoute/(:case)/(:id)/(:parentId)"} component={LoanAppRoute} />
      
      <IndexRoute component={Main} />
  </Route>
)
