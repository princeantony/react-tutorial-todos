/*eslint-disable import/default */

/* plugin libraries */
import axios from "axios";

/* Constant components */
import {SERVICE_URLS} from "../constants/ServiceURL";
import * as types from "../constants/ActionTypes";

import {showExceptionMessage} from "../utils/Functions";


/*Create Owner Action*/
let CreateOwner = (assignmentTypeId, primaryEntityId, secondaryEntityId, userId) => {
    const url = SERVICE_URLS.ADD_NEW_OWNER +"?assignmentTypeId="+assignmentTypeId +"&relatedEntityId="+primaryEntityId + "&borrowerEntityId="+secondaryEntityId + "&userId="+userId;
    const apiOwnerRequest = axios.get(url);

    return (dispatch) => {
        return apiOwnerRequest.then(({data}) => {
            dispatch({type: types.GET_OWNER, Owner: data})
        }).catch(error => {
            showExceptionMessage(error); throw(error);
        });
    }
}

let CreateOwnerForGuarantor = (assignmentTypeId, primaryEntityId, secondaryEntityId, index, userId) => {
    const url = SERVICE_URLS.ADD_NEW_OWNER +"?assignmentTypeId="+assignmentTypeId +"&relatedEntityId="+primaryEntityId + "&borrowerEntityId="+secondaryEntityId + "&userId="+userId;
    const apiOwnerRequest = axios.get(url);

    return (dispatch) => {
        return apiOwnerRequest.then(({data}) => {
            dispatch({type: types.GET_GUARANTOR_OWNER, Owner: data, Index:index})
        }).catch(error => {
            showExceptionMessage(error); throw(error);
        });
    }
}
/*Create Owner Action End*/

/*Get Owner Action*/
let GetRelatedEntityByAssignementType = (assignmentTypeId, primaryEntityId, secondaryEntityId, OwnerIndex, userId) =>{
    const url = SERVICE_URLS.ADD_NEW_OWNER +"?assignmentTypeId="+assignmentTypeId +"&relatedEntityId="+primaryEntityId + "&borrowerEntityId="+secondaryEntityId + "&userId="+userId;
    const apiOwnerRequest = axios.get(url);

    return (dispatch) => {
        return apiOwnerRequest.then(({data}) => {
            dispatch({type: types.OWNER_ASSIGNEMENT_UPDATE, Owner: data, OwnerIndex:OwnerIndex})
        }).catch(error => {
            showExceptionMessage(error); throw(error);
        });
    }
}


let GetGuarantorRelatedEntityByAssignementType = (assignmentTypeId, primaryEntityId, secondaryEntityId, OwnerIndex, guarantorIndex, userId) => {
    const url = SERVICE_URLS.ADD_NEW_OWNER +"?assignmentTypeId="+assignmentTypeId +"&relatedEntityId="+primaryEntityId + "&borrowerEntityId="+secondaryEntityId + "&userId="+userId;
    const apiOwnerRequest = axios.get(url);

    return (dispatch) => {
        return apiOwnerRequest.then(({data}) => {
            dispatch({type: types.GUARANTOR_OWNER_ASSIGNEMENT_UPDATE, Owner: data, OwnerIndex:OwnerIndex, GuarantorIndex:guarantorIndex})
        }).catch(error => {
            showExceptionMessage(error); throw(error);
        });
    }
}

let GetOwners = (legalEntityId) => {
    const url= SERVICE_URLS.GET_OWNERS.replace('{0}', legalEntityId);
    const apiGetOwnersResult = axios.get(url);
    return (dispatch) => {
        return apiGetOwnersResult.then(({data}) => {
            dispatch({type: types.GET_OWNERS, Owners: data})
        }
        ).catch(error => {
            showExceptionMessage(error); throw(error);
        });
    }
}

let GetOwnerLegalEntity = (assignmentTypeId, primaryEntityId, secondaryEntityId, userId) => {
    const url = SERVICE_URLS.ADD_NEW_OWNER +"?assignmentTypeId="+assignmentTypeId +"&relatedEntityId="+primaryEntityId + "&borrowerEntityId="+secondaryEntityId + "&userId="+userId;
    const apiGetGuarantorLegalEntityRequest = axios.get(url);

    return (dispatch) => {
        return apiGetGuarantorLegalEntityRequest.then(({data}) => {
            dispatch({type: types.GET_OWNER, Owner: data})
        }).catch(error => {
            showExceptionMessage(error); throw(error);
        });
    }
}

let  GetGuarantorOwners = (legalEntityId, index) => {
    const url= SERVICE_URLS.GET_OWNERS.replace('{0}', legalEntityId);
    const apiGetOwnersResult = axios.get(url);
    return (dispatch) => {
        return apiGetOwnersResult.then(({data}) => {
            dispatch({type: types.GET_GUARANTOR_OWNERS, Owners: data, Index:index})
        }).catch(error => {
            showExceptionMessage(error); throw(error);
        });
    }
}

let GetGuarantorOwnerLegalEntity = (assignmentTypeId, primaryEntityId, secondaryEntityId, index, userId) => {
    const url = SERVICE_URLS.ADD_NEW_OWNER +"?assignmentTypeId="+assignmentTypeId +"&relatedEntityId="+primaryEntityId + "&borrowerEntityId="+secondaryEntityId + "&userId="+userId;
    const apiGetGuarantorLegalEntityRequest = axios.get(url);

    return (dispatch) => {
        return apiGetGuarantorLegalEntityRequest.then(({data}) => {
            dispatch({type: types.GET_GUARANTOR_OWNER, Owner: data, Index:index})
        }).catch(error => {
            showExceptionMessage(error); throw(error);
        });
    }
}
/*Get Owner Action End*/

/*Save Owner Action*/
let SaveRelatedEntity = (relatedEntitiyTie, index) => {
    const url = SERVICE_URLS.RELATED_ENTITY_SAVE;
    const apiOwnerRequest = axios({
        method: 'post',
        url: url,
        data:relatedEntitiyTie
    });

    return (dispatch) => {
        return apiOwnerRequest.then(({data}) => {
            data.IsNew=false;
            dispatch({type: types.SAVE_OWNER, Owner: data, Index:index})
        }).catch(error => {
            showExceptionMessage(error); throw(error);
        });
    }
}

let SaveGuarantorRelatedEntity = (relatedEntitiyTie, parentIndex, childIndex) => {
    const url = SERVICE_URLS.RELATED_ENTITY_SAVE;
    const apiOwnerRequest = axios({
        method: 'post',
        url: url,
        data:relatedEntitiyTie
    });

    return (dispatch) => {
        return apiOwnerRequest.then(({data}) => {
            data.IsNew=false;
            dispatch({type: types.SAVE_GUARANTOR_OWNER, Owner: data, GuarantorIndex:parentIndex, OwnerIndex:childIndex})
        }).catch(error => {
            showExceptionMessage(error); throw(error);
        });
    }
}
/*Save Owner Action End*/

/*Remove Owner Action*/
let RemoveBorrowerOwner = (ownerList, index) => {  
    let owner=ownerList[index];
    const url= SERVICE_URLS.REMOVE_RELATEDENTITYTIE_OWNER;
    const apiRemoveOwnerRequest=axios({
        method: 'post',
        url: url,
        data:owner
    });

    return (dispatch) => {
        return apiRemoveOwnerRequest.then(() => {
            ownerList.splice(index, 1);
            dispatch({type: types.GET_OWNERS, Owners: ownerList});
        }).catch(error => {
            showExceptionMessage(error); throw(error);
        });
    }
}

let RemoveGuarantor = (guarantorList, index) => {
    let guarantor=guarantorList[index];
    const url= SERVICE_URLS.REMOVE_RELATEDENTITYTIE_OWNER;

    const apiRemoveGuarantorRequest=axios({
        method: 'post',
        url: url,
        data:guarantor
    });

    return (dispatch) => {
        return apiRemoveGuarantorRequest.then(() => {
            guarantorList.splice(index, 1);
            dispatch({type: types.GET_GUARANTORS, Guarantors: guarantorList});
        }).catch(error => {
            showExceptionMessage(error); throw(error);
        });
    }
}

let RemoveGuarantorOwner =  (ownerList, parentIndex, childIndex) => {  
    let owner=ownerList[parentIndex].RelatedEntity.OwnershipTies[childIndex];
    const url= SERVICE_URLS.REMOVE_RELATEDENTITYTIE_OWNER;
    const apiRemoveOwnerRequest=axios({
        method: 'post',
        url: url,
        data:owner
    });

    return (dispatch) => {
        return apiRemoveOwnerRequest.then(() => {
            ownerList[parentIndex].RelatedEntity.OwnershipTies.splice(childIndex, 1);
            dispatch({type: types.GET_GUARANTOR_OWNERS, Owners: ownerList, Index:parentIndex});
        }).catch(error => {
            showExceptionMessage(error); throw(error);
        });
    }
}
/*Remove Owner Action End*/

export {CreateOwner, CreateOwnerForGuarantor, GetOwners, GetOwnerLegalEntity, GetGuarantorOwners, GetGuarantorOwnerLegalEntity, SaveRelatedEntity, SaveGuarantorRelatedEntity, RemoveBorrowerOwner, RemoveGuarantorOwner, GetRelatedEntityByAssignementType, GetGuarantorRelatedEntityByAssignementType, RemoveGuarantor};
 