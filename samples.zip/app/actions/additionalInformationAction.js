﻿/*eslint-disable import/default */

/* plugin libraries */
import axios from "axios";

/* Constant components */
import {SERVICE_URLS} from "../constants/ServiceURL";
import * as types from "../constants/ActionTypes";

import {showExceptionMessage} from "../utils/Functions";

let CreateAdditionalInformation = () => {
    const url = SERVICE_URLS.CREATE_ADDITIONAL_INFORMATION;
    const apiAdditionalInformationRequest = axios.get(url);
    return (dispatch) => {
        return apiAdditionalInformationRequest.then(({data}) => {
            dispatch({type: types.CREATE_NEW_ADDITIONAL_INFORMATION, AdditionalInformation: data});
        }).catch(error => {
            showExceptionMessage(error); throw(error);
        });
    }    
}

let SaveAdditionalInformation = (additionalInformation) => {  
    return (dispatch) => {
        dispatch({type: types.UPDATE_ADDITIONAL_INFORMATION, AdditionalInformation: additionalInformation});
        dispatch({type: types.SET_IS_DIRTY_ITEM, status: false});
    }
}

export {CreateAdditionalInformation,SaveAdditionalInformation};