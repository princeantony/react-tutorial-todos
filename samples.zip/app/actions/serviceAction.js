/*eslint-disable import/default */

/* plugin libraries */
import axios from "axios";

/* Constant components */
import {SERVICE_URLS} from "../constants/ServiceURL";
import * as types from "../constants/ActionTypes";
import FileSaver from 'file-saver';
import {showExceptionMessage} from "../utils/Functions";

let SubmitLoanApplication = (loanAppData) => {
    const url = SERVICE_URLS.SUBMIT_LOANAPPLICATION;
    const apiSubmitLoanAppRequest = axios({
        method: 'post',
        url: url,
        data: loanAppData
    });

    return (dispatch) => {
       return apiSubmitLoanAppRequest.then(({data}) => {
            dispatch({type: types.UPDATE_LOANAPPLICATION, isSubmitSuccess:data})
        }).catch(error => {
            showExceptionMessage(error); throw(error);
        });
    }
}

let CancelLoanApplication = (loanAppData) => {
    const url = SERVICE_URLS.CANCEL_LOANAPPLICATION;
    const apiCancelLoanAppRequest = axios({
        method: 'post',
        url: url,
        data: loanAppData
    });

    return (dispatch) => {
        return apiCancelLoanAppRequest.then(() => {
            return true;
        }).catch(error => {
            showExceptionMessage(error); throw(error);
        });
    }
}

function b64toBlob(b64Data, contentType, sliceSize) {
    contentType = contentType || '';
    sliceSize = sliceSize || 512;
    var byteCharacters = atob(b64Data);
    var byteArrays = [];
    for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
        var slice = byteCharacters.slice(offset, offset + sliceSize);
        var byteNumbers = new Array(slice.length);
        for (var i = 0; i < slice.length; i++) {
            byteNumbers[i] = slice.charCodeAt(i);
        }
        var byteArray = new Uint8Array(byteNumbers);
        byteArrays.push(byteArray);
    }
    var blob = new Blob(byteArrays, {type: contentType});
    return blob;
}

let GetFinancialNeedsDocument = (loanAppData) => {
    const url = SERVICE_URLS.GET_FINANCIALNEEDS_DOCUMENT;
    $.ajax({
        type: "POST",
        url: url,
        data: loanAppData,
        success: function(response, textStatus, jqXHR)
        {  
            var blob = b64toBlob(response, "application/pdf");
            var blobUrl = URL.createObjectURL(blob);
            var a = window.document.createElement('a');
            a.href = blobUrl; 
            a.download = "FinancialNeeds.pdf";
            document.body.appendChild(a)
            a.click();
            document.body.removeChild(a)
        },
        error: function (jqXHR, textStatus, errorThrown){}      
    });
}

let GetSnapShotAndDisclosuresDocument = (loanAppData) => {
    const url = SERVICE_URLS.GET_SNAPSHOTANDDISCLOSURES_DOCUMENT;
    $.ajax({
        type: "POST",
        url: url,
        data: loanAppData,
        success: function(response, textStatus, jqXHR)
        {  
            var blob = b64toBlob(response, "application/pdf");
            var blobUrl = URL.createObjectURL(blob);
            var a = window.document.createElement('a');
            a.href = blobUrl; 
            a.download = "Disclosures.pdf";
            document.body.appendChild(a)
            a.click();
            document.body.removeChild(a)
        },
        error: function (jqXHR, textStatus, errorThrown){}      
    });
}

export {SubmitLoanApplication, GetFinancialNeedsDocument, CancelLoanApplication,GetSnapShotAndDisclosuresDocument};