/*eslint-disable import/default */

/* plugin libraries */
import axios from "axios";

/* Constant components */
import {SERVICE_URLS} from "../constants/ServiceURL";
import * as types from "../constants/ActionTypes";

import {showExceptionMessage} from "../utils/Functions";


let GetLegalEntityCommonData = () => {
    const url = SERVICE_URLS.GET_LEGALENTITY_COMMON_DATA;
    const apiEntityCommonDataResult = axios.get(url);

    return (dispatch) => {
        return apiEntityCommonDataResult.then(({data}) => {
           dispatch({type: types.GET_LEGALENTITY_COMMON_DATA, LegalEntityCommonData: data});
        }).catch(error => {
            showExceptionMessage(error); throw(error);
        });
    }
}

let GetProductCommonData = (legalEntityId,userId) => {
    const url = SERVICE_URLS.PRODUCT_COMMON_DATA;
    const apiProductCommonDataResult = axios.get(url, {
        params: {
            legalEntityId,
            userId
        }
    });

    return (dispatch) => {
        return  apiProductCommonDataResult.then(({data}) => {
            dispatch({type: types.GET_PRODUCT_COMMON_DATA, ProductCommonData: data});
        }).catch(error => {
            showExceptionMessage(error); throw(error);
        });
    }
}

let GetCollateralCommonData = () => {
    const url = SERVICE_URLS.COLLATERAL_COMMON_DATA;
    const apiGetCollateralCommonData = axios.get(url);

    return (dispatch) => {
        return apiGetCollateralCommonData.then(({data}) => {
            dispatch({type: types.GET_COLLATERAL_COMMON_DATA, CollateralCommonData: data});
        }).catch(error => {
            showExceptionMessage(error); throw(error);
        });
    }
}

let UpdateActionStatus = (statusItems) => {  
    return (dispatch) => {
        dispatch({type: types.SET_SAVED_ITEM, statusItems: statusItems});
    }
}



let LeftNavigationControlIsDirty = (status) =>{
    return (dispatch) => {
        return  dispatch({type: types.SET_IS_DIRTY_ITEM, status: status});
    }
}


export {GetLegalEntityCommonData, GetProductCommonData, GetCollateralCommonData, UpdateActionStatus, LeftNavigationControlIsDirty};