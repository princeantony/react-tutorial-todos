﻿/*eslint-disable import/default */

/* plugin libraries */
import axios from "axios";

/* Constant components */
import {SERVICE_URLS} from "../constants/ServiceURL";
import * as types from "../constants/ActionTypes";

import {showExceptionMessage} from "../utils/Functions";

/* Create CardHolders Action*/
let CreateCardholder = (index) => {
    const url = SERVICE_URLS.ADD_NEW_CARDHOLDER + index;
    const apiCardholderRequest = axios.get(url);
    return (dispatch) => {
        return apiCardholderRequest.then(({data}) => {
            dispatch({type: types.CREATE_CARDHOLDER, Cardholders: data});
        }).catch(error => {
            showExceptionMessage(error); throw(error);
        });
    }    
}
/* Create CardHolders Action End*/

/* Save CardHolders Action */
let SaveCardholder = (cardholderInformation, index) => {  
    return (dispatch) => {
        cardholderInformation.IsNew=false;
        dispatch({type: types.UPDATE_CARDHOLDER, Cardholders: cardholderInformation, Index:index});
        dispatch({type: types.SET_IS_DIRTY_ITEM, status: false});
    }
}
/* Save CardHolders Action End */

/* Remove CardHolders Action */
let RemoveCardholderLegalEntity = (cardholderList) => {  
    return (dispatch) => {
        dispatch({type: types.REMOVE_CARDHOLDER, Cardholders:cardholderList});
    }
}
/* Remove CardHolders Action End */

export {CreateCardholder, SaveCardholder, RemoveCardholderLegalEntity};