/*eslint-disable import/default */
import {SERVICE_URLS} from "../constants/ServiceURL";
import * as types from "../constants/ActionTypes";
import axios from "axios";

export function SaveLegalEntity(borrower) {
    const url = SERVICE_URLS.SAVE_LEGALENTITY;
    const apiSaveLegalEntityRequest = axios({
        method: 'post',
        url: url,
        data: borrower
    });
        
    return (dispatch) => {
        return apiSaveLegalEntityRequest.then(({data}) => {
            borrower.Id = data.Id;
            borrower.Relationship.Id = data.Relationship.Id;
            dispatch({type: types.UPDATE_BORROWER_SUCCESS, Borrower: borrower})
        }).catch(error => {
            throw(error);
        });
    }
}

export function CreateLegalEntity(borrower) {
    const url = SERVICE_URLS.UPDATE_LEGALENTITY;
    const apiCreateLegalEntityRequest = axios({
        method: 'post',
        url: url,
        data: borrower
    });
        
    return (dispatch) => {
        return apiCreateLegalEntityRequest
        .then(({data}) => {
            dispatch({type: types.UPDATE_BORROWER_SUCCESS, Borrower: data});
        }).catch(error => {
            throw(error);
        });
    }
}

export function CreateGuarantor(){
    const url = SERVICE_URLS.CREATE_LEGALENTITY;
    const apiGuarantorRequest = axios.get(url)
    return (dispatch) => {
        return apiGuarantorRequest.then(({data}) => {
            dispatch({type: types.UPDATE_GUARANTOR_SUCCESS, Guarantor: data})
        }).catch(error => {
            throw(error);
        });
    }
}

export function SaveGuarantorLegalEntity(borrower) {
    const url = SERVICE_URLS.SAVE_LEGALENTITY;
    const apiSaveGuarantorLegalEntityRequest = axios({
        method: 'post',
        url: url,
        data:borrower
    });
        
    return (dispatch) => {
        return  apiSaveGuarantorLegalEntityRequest.then(({data}) => {
            dispatch({type: types.UPDATE_GUARANTOR_SUCCESS, Guarantor: data})
        }).catch(error => {
            throw(error);
        });
    }
}

export function CreateGuarantorLegalEntity(borrower) {
    const url = SERVICE_URLS.UPDATE_LEGALENTITY;
    const apiUserRequest = axios({
        method: 'post',
        url: url,
        data: borrower
    });
        
    return (dispatch) => {
        apiUserRequest.then(({data}) => {
            dispatch({type: types.UPDATE_GUARANTOR_SUCCESS, Guarantor: data})
        }
        );
    }
}


export function GetLegalEntityCommonData(){
    const url = SERVICE_URLS.GET_LEGALENTITY_COMMON_DATA;
    const apiLegalEntityCommonDataResult = axios.get(url)
    return (dispatch) => {
        apiLegalEntityCommonDataResult.then(({data}) => {
            dispatch({type: types.GET_LEGALENTITY_COMMON_DATA, LegalEntityCommonData: data})
        }
        );
    }
}


export function CreateOwner(assignmentTypeId, legalEntityId, userId){
    const url = SERVICE_URLS.ADD_NEW_OWNER +"?assignmentTypeId="+assignmentTypeId +"&legalEntityId="+legalEntityId + "&userId="+userId;
    const apiOwnerRequest = axios.get(url)
    return (dispatch) => {
        return apiOwnerRequest.then(({data}) => {
            dispatch({type: types.GET_OWNER, Owner: data})
        }).catch(error => {
            throw(error);
        });
    }
}

export function RemoveBorrowerOwner(data) {  
    return (dispatch) => {
        dispatch({type: types.GET_OWNERS, Owners: data});
    }
}

export function SaveRelatedEntity(relatedEntitiyTie, index){
    const url = SERVICE_URLS.RELATED_ENTITY_SAVE;
    const apiOwnerRequest = axios({
        method: 'post',
        url: url,
        data:relatedEntitiyTie
    });
    return (dispatch) => {
        return apiOwnerRequest.then(({data}) => {
            dispatch({type: types.SAVE_OWNER, Owner: relatedEntitiyTie, Index:index})
        }).catch(error => {
            throw(error);
        });
    }
}

export function CreateOwnerForGuarantor(assignmentTypeId,legalEntityId, userId){
    const url = SERVICE_URLS.ADD_NEW_OWNER +"?assignmentTypeId="+assignmentTypeId +"&legalEntityId="+legalEntityId + "&userId="+userId;
    const apiOwnerRequest = axios.get(url)
    return (dispatch) => {
        return apiOwnerRequest.then(({data}) => {
            dispatch({type: types.GET_GUARANTOR_OWNER, Owner: data})
        }).catch(error => {
            throw(error);
        });
    }

}

export function SaveGuarantorRelatedEntity(relatedEntitiyTie, index){
    const url = SERVICE_URLS.RELATED_ENTITY_SAVE;
    const apiOwnerRequest = axios({
        method: 'post',
        url: url,
        data:relatedEntitiyTie
    });
    return (dispatch) => {
        return apiOwnerRequest.then(({data}) => {
            dispatch({type: types.SAVE_GUARANTOR_OWNER, Owner: relatedEntitiyTie, Index:index})
        }).catch(error => {
            throw(error);
        });
    }
}

 