/*eslint-disable import/default */

/* plugin libraries */
import axios from "axios";
import _ from "lodash";

/* Constant components */
import {SERVICE_URLS} from "../constants/ServiceURL";
import * as types from "../constants/ActionTypes";

import {showExceptionMessage} from "../utils/Functions";

let CreateNewCollateral = (collateralTypeId, userId) => {
    const url = SERVICE_URLS.CREATE_COLLATERAL;
    const apiGetCollateralInformation = axios.get(url, {
        params: {
            collateralTypeId: collateralTypeId,
            userId:userId
        }
    });

    return (dispatch) => {
        return apiGetCollateralInformation.then(({data}) => {
            dispatch({type: types.GET_COLLATERAL, Collateral: data})
        }).catch(error => {
            showExceptionMessage(error); throw(error);
        });
    }
}

let CreateCollateral = (collateralTypeId, userId, index, collateralData) => {
     const url = SERVICE_URLS.CREATE_COLLATERAL;
     const apiGetCollateralInformation = axios.get(url, {
         params: {
             collateralTypeId: collateralTypeId,
             userId:userId
         }
     });

     return (dispatch) => {
        return apiGetCollateralInformation.then(({data}) => {
            if(collateralData!=null && collateralData.ProductIds!=undefined && collateralData.Owner!=undefined)
            {
                data.ProductIds=collateralData.ProductIds;
                data.Owner=collateralData.Owner;
            }
           /// return data;
            dispatch({type:types.CREATE_COLLATERAL_SUCCESS, Collateral:data, Index:index});
        }).catch(error => {
            showExceptionMessage(error); throw(error);
        });
    }
}

let CreateCollateralOwner = (index) => {
    const url = SERVICE_URLS.CREATE_LEGALENTITY;
    const apiCreateCollateralLegalEntityRequest = axios.get(url);
     
    return (dispatch) => {
        return apiCreateCollateralLegalEntityRequest.then(({data}) => {
            dispatch({type: types.UPDATE_COLLATERAL_OWNER_SUCCESS, LegalEntity: data, Index:index});
        }).catch(error => {
            showExceptionMessage(error); throw(error);
        });
    };
}
 
let GetQualifiedProposedCollaterals = (integrationCode) => {
    const url = SERVICE_URLS.GET_QULIFIED_PROPOSED_COLLATERAL;
    const apiGetQualifiedProposedCollateral = axios.get(url, {
        params: {
            productType: JSON.stringify(integrationCode)
        }
    });

    return () => {
        return apiGetQualifiedProposedCollateral.then(({data}) => {
            return data;
        }).catch(error => {
            showExceptionMessage(error); throw(error);
        });
    };
}

let GetQualifiedProductLs = (id) => {
    const url = SERVICE_URLS.GET_QUALIFIED_PRODUCTS + id;
    const apiGetQualifiedProposedCollateral = axios.get(url);

    return () => {
        return apiGetQualifiedProposedCollateral.then(({data}) => {
            return data;
        }).catch(error => {
            showExceptionMessage(error); throw(error);
        });
    };
} 

 let GetCollateralOwner = (legalEntityId, index) => {
    const url = SERVICE_URLS.GET_LEGALENTITY + legalEntityId;
    const apiGetCollateralLegalEntityRequest = axios.get(url);

    return (dispatch) => {
        return apiGetCollateralLegalEntityRequest.then(({data}) => {
            dispatch({type: types.UPDATE_COLLATERAL_OWNER_SUCCESS, LegalEntity: data, Index:index});
        }).catch(error => {
            showExceptionMessage(error); throw(error);
        });
    };
}

 let SaveCollateralOwner = (legalEntity, index) => {
    const url = SERVICE_URLS.SAVE_LEGALENTITY;
    const apiSaveLegalEntityRequest = axios({
        method: 'post',
        url: url,
        data: legalEntity
    });
        
    return (dispatch) => {
        return apiSaveLegalEntityRequest.then(({data}) => {
            legalEntity.Id = data.Id;
            legalEntity.Relationship = data.Relationship;
            dispatch({type: types.UPDATE_COLLATERAL_OWNER_SUCCESS, LegalEntity: data, Index:index})
        }).catch(error => {
            showExceptionMessage(error); throw(error);
        });
    }
}


 let SaveCollateral = (productList, Collateral, index) => {
     const url = SERVICE_URLS.COLLATERAL_SAVE;
     let product = _.find(productList, function(o){
         return (o.ProductId!=0 && (o.IntegrationCode=="BLOC" || o.IntegrationCode=="ARLOC"));
     });

     let productIndex = _.findIndex(productList, function(o) { return (o.ProductId!=0 && (o.IntegrationCode=="BLOC" || o.IntegrationCode=="ARLOC")); });

     let ProductCollateralVM = {
         Collateral: Collateral,
         Product: product
     };

    const apiSaveLegalEntityRequest = axios({
        method: 'post',
        url: url,
        data: ProductCollateralVM
    });

    return (dispatch) => {
        return apiSaveLegalEntityRequest.then(({data}) => {
            data.Collateral.IsNew=false;
            dispatch({type: types.CREATE_COLLATERAL_SUCCESS, Collateral: data.Collateral, Index:index});
            if(data.Product!=null)
            {
                let products = productList;
                products[productIndex] = data.Product;
                dispatch({type: types.GET_PRODUCTS, Products: products});
            }
        }).catch(error => {
            showExceptionMessage(error); throw(error);
        });
    }
}

 let RemoveCollateral = (collateralList, index) => {
     let collateral=collateralList[index];
     const url= SERVICE_URLS.REMOVE_COLLATERAL;

     const apiRemoveCollateralRequest=axios({
         method: 'post',
         url: url,
         data:collateral
     });

     return (dispatch) => {
         return apiRemoveCollateralRequest.then(() => {
             collateralList.splice(index, 1);
             dispatch({type: types.GET_COLLATERALS, Collaterals: collateralList});
         }).catch(error => {
             showExceptionMessage(error); throw(error);
         });
     }
 }

export {CreateCollateral, GetCollateralOwner, SaveCollateralOwner, SaveCollateral, CreateCollateralOwner, GetQualifiedProposedCollaterals, GetQualifiedProductLs, RemoveCollateral, CreateNewCollateral};