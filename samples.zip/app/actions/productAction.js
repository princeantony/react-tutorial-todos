/*eslint-disable import/default */

/* plugin libraries */
import axios from "axios";

/* Constant components */
import {SERVICE_URLS} from "../constants/ServiceURL";
import * as types from "../constants/ActionTypes";
import {PRODUCT_INTEGRATIONCODE} from "../constants/ApplicationConstants";

import {reArrangeDisplayNameProperty, showExceptionMessage} from "../utils/Functions";

/* Create Product Action */
let CreateProduct = (productType, productId, index, IsProductByBFNA, AssociatedProductId) => {
    const url = SERVICE_URLS.CREATE_PRODUCT;
    const apiCreateProductRequest = axios.get(url, {
        params: {
            productType: productType,
            productId:productId
        }
    });

    return (dispatch) => {
        return apiCreateProductRequest.then(({data}) => {
            data.IsProductByBFNA=IsProductByBFNA;
            data.AssociatedProductId =  (productType==PRODUCT_INTEGRATIONCODE.FOREIGN_EXCHANGE || productType==PRODUCT_INTEGRATIONCODE.FOREIGNEXCHANGE_FER)?AssociatedProductId:0;
            return data;
            /*dispatch({type: types.CREATE_PRODUCT_INFORMATION, Product: data, Index:index})*/
        }).catch(error => {
            showExceptionMessage(error); throw(error);
        });
    }
}

let AddNewProduct = (productType) => {
    const url = SERVICE_URLS.CREATE_PRODUCT;
    const apiCreateProductRequest = axios.get(url, {
        params: {
            productType: productType,
            productId: 0
        }
    });

    return (dispatch) => {
        return apiCreateProductRequest.then(({data}) => {
            dispatch({type: types.GET_PRODUCT, Product: data})
        }).catch(error => {
            showExceptionMessage(error); throw(error);
        });
    }
}
/* Create Product Action End */

/* Save Product Action */
let SaveProduct = (loanAppData, index) => {
    const url = SERVICE_URLS.UPDATE_PRODUCTDATA;
    const apiSaveProductRequest = axios({
        method: 'post',
        url: url,
        data: loanAppData
    });
    
    return (dispatch) => {
        return apiSaveProductRequest.then(({data}) => {
            data.Products[index].IsNew=false;
            data.Products[index].IsDirty=false;
            data.Products[index].IsProductTypeDisabled=true;
            dispatch({type: types.UPDATE_PRODUCT, UpdatedLoanAppWithProd: data});
            dispatch({type: types.SET_IS_DIRTY_ITEM, status: false});
        }).catch(error => {
            showExceptionMessage(error); throw(error);
        });
    }
}
/* Save Product Action End */



let RemoveProduct = (collateralList, productList, index) => {
    const url= SERVICE_URLS.REMOVE_PRODUCT;

    let _productList=productList;

    let product=_productList[index];

    let ProductCollateralMapping = {
        collateralList: collateralList,
        product: product
    };
    
    
    const apiRemoveProductRequest = axios({
        method: 'post',
        url: url,
        data: ProductCollateralMapping
    });

    return (dispatch) => {
        return apiRemoveProductRequest.then(({data}) => {
            _productList.splice(index, 1);
            _productList =reArrangeDisplayNameProperty(_productList, "Product Request ");
            dispatch({type: types.GET_PRODUCTS, Products: _productList});
            dispatch({type: types.GET_COLLATERALS, Collaterals: data});
        }).catch(error => {
            showExceptionMessage(error); throw(error);
        });
    }
}

let RemoveCollateralProductMapping = (collateralList, product) => {
    const url=  SERVICE_URLS.REMOVE_PRODUCT_COLLATERAL_MAPPING; ///SERVICE_URLS.REMOVE_PRODUCT_COLLATERAL_MAPPING;

    let ProductCollateralMapping = {
        collateralList: collateralList,
        product: product
    };

    const apiRemoveMappingRequest=axios({
        method: 'post',
        url: url,
        data: ProductCollateralMapping
    });

        
    return (dispatch) => {
        return apiRemoveMappingRequest.then(({data}) => {
            dispatch({type: types.GET_COLLATERALS, Collaterals: data});
        }).catch(error => {
            showExceptionMessage(error); throw(error);
        });
    }

}

export {CreateProduct, SaveProduct, AddNewProduct, RemoveProduct, RemoveCollateralProductMapping};
