/*eslint-disable import/default */

/* plugin libraries */
import axios from "axios";

/* Constant components */
import {SERVICE_URLS} from "../constants/ServiceURL";
import * as types from "../constants/ActionTypes";

import {showError, showExceptionMessage} from "../utils/Functions";

/* Get LegalEntities Action*/
let GetSearchResults = (ssnTin, entityName, pageNumber) => {
    const url = SERVICE_URLS.GET_SEARCHRESULTS;
    const apiSearchRequest = axios.get(url, {
        params: {
            ssnTin, 
            entityName,
            pageNumber
        }
    });

    return (dispatch) => {
        return apiSearchRequest.then(({data}) => {
            dispatch({type: types.GET_SEARCH_INFORMATION_SUCCESS, apiResult: data});
        }).catch(error => {
            showExceptionMessage(error); throw(error);
        });
    };
}

let SearchLegalEntities = (ssnTin,entityName,primaryLegalEntityId) => {
    const url = SERVICE_URLS.GET_SEARCH_LEGALENTITIES;
    const apiSearchRequest = axios.get(url, {
        params: {
            ssnTin,
            entityName,
            primaryLegalEntityId
        }
    });

    return (dispatch) => {
       return apiSearchRequest.then(({data}) => {
           dispatch({type: types.GET_SEARCH_INFORMATION_SUCCESS, apiResult: data});
       }).catch(error => {
           showExceptionMessage(error); throw(error);
       });
    }
}
/* Get LegalEntities Action End*/

export {GetSearchResults, SearchLegalEntities};