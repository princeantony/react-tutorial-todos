/*eslint-disable import/default */

/* plugin libraries */
import axios from "axios";

/* Constant components */
import {SERVICE_URLS} from "../constants/ServiceURL";
import * as types from "../constants/ActionTypes";