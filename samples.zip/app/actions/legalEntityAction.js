/*eslint-disable import/default */

/* plugin libraries */
import axios from "axios";

/* Constant components */
import {SERVICE_URLS} from "../constants/ServiceURL";
import * as types from "../constants/ActionTypes";

import {showExceptionMessage} from "../utils/Functions";

/*Create LegalEntity Action*/
let CreateLegalEntity = (legalEntity) => {
    const url = SERVICE_URLS.UPDATE_LEGALENTITY;
    const apiCreateLegalEntityRequest = axios({
        method: 'post',
        url: url,
        data: legalEntity
    });
        
    return (dispatch) => {
        return apiCreateLegalEntityRequest
        .then(({data}) => {
            dispatch({type: types.UPDATE_BORROWER_SUCCESS, Borrower: data});
        }).catch(error => {
            showExceptionMessage(error); throw(error);
        });
    }
}

let GetBorrower = (brwrAndNewAddresses) => { 
    const url = SERVICE_URLS.GET_BORROWER;
    const apiGetBorrowerRequest = axios({
        method: 'post',
        url: url,
        data: brwrAndNewAddresses
    });
    
    return (dispatch) => {
        return apiGetBorrowerRequest.then(({data}) => {
            dispatch({type: types.UPDATE_BORROWER_SUCCESS, Borrower: data});
        }).catch(error => {
            showExceptionMessage(error); throw(error);
        });
    };
}

let CreateGuarantorLegalEntityTie = (assignmentTypeId, primaryEntityId, secondaryEntityId, userId) => {
    const url = SERVICE_URLS.ADD_NEW_OWNER +"?assignmentTypeId="+assignmentTypeId +"&relatedEntityId="+primaryEntityId + "&borrowerEntityId="+secondaryEntityId + "&userId="+userId;
    const apiGuarantorTieRequest = axios.get(url);

    return (dispatch) => {
        return apiGuarantorTieRequest.then(({data}) => {
            dispatch({type: types.GET_GUARANTOR, Guarantor: data})
        }).catch(error => {
            showExceptionMessage(error); throw(error);
        });
    }
}
/*Create LegalEntity Action End*/


/*Get LegalEntity Action*/
let GetGuarantorLegalEntityTie = (assignmentTypeId, primaryEntityId, secondaryEntityId, userId) => {
    const url = SERVICE_URLS.ADD_NEW_OWNER +"?assignmentTypeId="+assignmentTypeId +"&relatedEntityId="+primaryEntityId + "&borrowerEntityId="+secondaryEntityId + "&userId="+userId;
    const apiGetGuarantorLegalEntityRequest = axios.get(url);

    return (dispatch) => {
        return apiGetGuarantorLegalEntityRequest.then(({data}) => {
            dispatch({type: types.GET_GUARANTOR, Guarantor: data})
        }).catch(error => {
            showExceptionMessage(error); throw(error);
        });
    }
}

/*Get LegalEntity Action End*/


/*Save LegalEntity Action*/
/*Save Borrower Action*/
let SaveBorrower = (brwrAndNewAddresses) => {    
    const url = SERVICE_URLS.SAVE_BORROWER;
    const apiSaveBorrowerRequest = axios({
        method: 'post',
        url: url,
        data: brwrAndNewAddresses
    });
        
    return (dispatch) => {
        return apiSaveBorrowerRequest.then(({data}) => {
            brwrAndNewAddresses.Borrower.Id = data.Id;
            brwrAndNewAddresses.Borrower.Relationship = data.Relationship;
            brwrAndNewAddresses.Borrower.IsNew=false;
            brwrAndNewAddresses.Borrower.LegalName= data.LegalName;
            brwrAndNewAddresses.Borrower.Addresses= data.Addresses;
            dispatch({type: types.UPDATE_BORROWER_SUCCESS, Borrower: brwrAndNewAddresses.Borrower})
        }).catch(error => {
            showExceptionMessage(error); throw(error);
        });
    }
}

let SaveGuarantorRelatedEntity = (relatedEntitiyTie, index) => {
    const url = SERVICE_URLS.RELATED_ENTITY_SAVE;
    const apiSaveguarantorEntityRequest = axios({
        method: 'post',
        url: url,
        data:relatedEntitiyTie
    });

    return (dispatch) => {
        return apiSaveguarantorEntityRequest.then(({data}) => {
            data.RelatedEntity.IsNew=false;
            dispatch({type: types.SAVE_GUARANTOR, Guarantor: data, Index:index})
        }).catch(error => {
            showExceptionMessage(error); throw(error);
        });
    }
}

//Address Line
let IsInValidPOBox = (_line1Value) => {
    var Trimline1Value = _.trim(_line1Value);
   
    if((_.split(Trimline1Value, ' ').length > 1))
    {
        const url = SERVICE_URLS.GET_VALIDATEPOBOX;
        const apiValidPostBox = axios.get(url,{
            params: {
                poBox: Trimline1Value,
            }
        });

        return (dispatch) => {
            return apiValidPostBox.then(({data}) => {
                return data;
            }).catch(error => {
                showExceptionMessage(error); throw(error);
            });
        }
    }
    else
    {
        return (dispatch) => {
            return new Promise(resolve => {
                setTimeout(() => {
                    resolve();
                }, 10);
            }).then(() => {
                return true;
            });
        }
    }
}

/*Save LegalEntity Action End*/

let IsBorrowerHasBlanketGuarantors = (legalEntityId) => {
    const url = SERVICE_URLS.BORROWER_HAS_BLANKET_GUARANTORS;

    const apiHasBlanketGuarantors = axios.get(url,{
        params: {
            borrowerId: legalEntityId
        }
    });

    return (dispatch) => {
        return apiHasBlanketGuarantors.then((data) => {
            return data;
        }).catch(error => {
            showExceptionMessage(error); throw(error);
        });
    }
}

export {CreateLegalEntity, CreateGuarantorLegalEntityTie, SaveGuarantorRelatedEntity, GetGuarantorLegalEntityTie, GetBorrower, SaveBorrower, IsInValidPOBox, IsBorrowerHasBlanketGuarantors};