import expect from 'expect'
import React from 'react'
import TestUtils from 'react-addons-test-utils'
import Footer from '../../components/Footer'

function setup() {
    let renderer = TestUtils.createRenderer()
    renderer.render(<Footer />)
    let output = renderer.getRenderOutput()

    return {
        output,
        renderer
    }
}


describe('components', () => {
    describe('Footer', () => {
        it('should render correctly', () => {
            const { output } = setup()
            expect(output.type).toBe('div')
            expect(output.props.className).toBe('footer text-center brd-t  pad-b-5px  mar-t-9px')
            let [ p , span] = output.props.children
            expect(p.type).toBe('p')
            expect(span.type).toBe('span')
            expect(p.span.props.children).toBe('� 2003 Fifth Third Bank  |  For Authorized Internal Use Only')
        })

    })
})