/*eslint-disable no-undef */
import {VARIABLE_CONSTANT} from "./ApplicationConstants";

let url = VARIABLE_CONSTANT.BASE_URL;

export const APPLICATION_URL=
{
    SEARCH_URL: url + 'Search/',
    BORROWER_URL: url + 'Borrower/',
    PRODUCT_REQUEST_URL: url + 'productRequest/',
    GUARANTOR: url + 'Guarantor/',
    COLLATERAL: url + 'Collateral/',
    /*Guarantor Search*/
    GUARANTOR_SEARCH_CRITERIA_PAGE: url + 'GuarantorSearchCriteriaPage/',
    GUARANTOR_SEARCH_RESULT:url + 'GuarantorSearch/',
    /*Guarantor Owner Search*/
    GUARANTOR_OWNER_SEARCH_CRITERIA : url + 'GuarantorOwnerSearchCriteria/',
    GUARANTOR_OWNER_SEARCH_RESULT : url + 'GuarantorOwnerSearchResult/',
    GUARANTOR_OWNER:url + 'GuarantorOwner/',
    /*Borrower Owner*/
    BORROWER_OWNER_SEARCH_CRITERIA : url + 'BorrowerOwnerSearchCriteria/',
    BORROWER_OWNER_SEARCH_RESULT : url + 'BorrowerOwnerSearchResult/',
    BORROWER_OWNER:url + 'BorrowerOwner/',
    CARDHOLDER:url + 'CardHolder/',
    ADDITIONAL_INFORMATION:url + 'AdditionalInformation',
    LOANAPP_ROUTE: url + 'LoanAppRoute/'
};


    
