/*eslint-disable no-undef */
export const HEADER_CONSTANT=
{
    HEADER_TEXT: 'Small Business Loan Application',
    HELP_TEXT:'Help',
    USER_GUIDE_URL: '#',
    USER_GUIDE_TEXT:'User Guide'
};

export const APP_CONSTANT={
    APP:"app",
    TOASTR_OPTIONS:{closeButton:true, newestOnTop:false, progressBar:true, preventDuplicates:true, timeOut:"5000", positionClass:"toast-bottom-full-width"}
}

export const APPLICATIONSUMMARY_CONSTANT=
{
    APPLICATION_SUMMARY: 'Application Summary',
    EMPLOYEE_NAME:'Employee Name',
    EMPLOYEE_NUMBER:'Employee Number',
    REGION:'Region',
    COST_CENTER_NUMBER:'Cost Center Number',
    FINANCIAL_CENTER_NAME_FC:'Financial Center Name (FC#)',
    APPLICATION_ID:'App #/Credit ID',
    RECIPIENT_OF_EMAIL_COMMUNICATION:'Recipient of Email Communication',
    FINANCIAL_CENTER_NAME_BB_PB_OFFICER:'Financial Center Name (BB/PB Officer#)',
    REFERRED_BY_EMPLOYEE_ID:'Referred by Employee ID'
};
export const SEARCH_CONSTANT={
    SEARCH_RESULT: 'Search Results',
    SEARCH_CRITERIA: 'Search Criteria',
    CUSTOMER_SEARCH: 'Customer Search',
    ZERO_RECORDS_MESSAGE:'Your search returned no results.\n Please select different criteria and perform the search again or \n Add New Customer.'
};

export const OWNERSHIPTIE_CONSTANT={
    TIE_INFORMATION:'Tie Information',
    PERCENT_OWNERSHIP:'Percentage of Ownership',
    LIMITED_PARTNER:'Limited Partner',
    GENERAL_PARTNER:'General Partner',
    OWNER:'Owner',
};


export const LEGALENITITY_COMMON_CONSTANT = {
    BASIC_BUSINESS_INFORMATION:'Basic Business Information',
    CUSTOMER_NAME:'Customer Name',
    FIRST_NAME:'First Name',
    MIDDLE_NAME:'Middle Name',
    LAST_NAME:'Last Name',
    SSN_ITIN_OR_EIN:'SSN/ITIN or EIN',
    ENTITY_STRUCTURE:'Entity Structure',
    BUSINESS_NAME:'Business Name',
    EIN:'EIN',
    SSN_ITIN:'Tax ID / Social Security #',
    DATE_BUSINESS_STARTED:'Date Business Started',
    DATE_OF_BIRTH:'Date of Birth',
    TITLE:'Title',
    CITIZEN:'Citizenship',
    BUSINESS_ADDRESS:'Business Address',
    ADDRESS_Line1:'Address Line 1',
    ADDRESS_Line2:'Address Line 2',
    NEWBUSINESSADDRESS:'New Business Address',
    NEWHOMEADDRESS:'New Home Address',
    REGION_PROVINCE:'Region/Province',
    HOME_ADDRESS:'Home Address',
    ADDRESS_TYPE:'Address Type',
    STREET_ADDRESS:'Street Address',
    RESIDENCE:'Residence',
    APT_SUITE:'Apt/suite',
    CITY:'City',
    STATE:'State',
    DOMESTIC : 'Domestic',
    INTERNATIONAL : 'International',
    ZIP_POSTAL_CODE:'Zip/Postal Code',
    COUNTY:'County',
    COUNTRY:'Country',
    FACILITIES:'Facilities',
    MONTHLY_RENT_MORTGAGE_PAYMENT:'Monthly Rent/Mortgage Payment',
    PROPERTY_VALUE:'Property Value',
    COMMENTS:'Comments',
    PHONE_NUMBERS:'Phone Numbers',
    BUSINESS:'Business',
    HOME:'Mobile',
    OTHER:'Other',
    OTHER_DETAILS:'Other Details',
    PRESENT_MANAGEMENT_SINCE:'Present Management Since',
    TOTAL_NUMBER_OF_EMPLOYEES:'Total Number of Employees',
    FORMATION_STATE:'Formation State',
    ARE_YOU_A_FIFTH_THIRD_EMPLOYEE :'Are you a Fifth Third employee?',
    GROSS_ANNUAL_REVENUE:'Business Gross Annual Revenue',
    PERSONAL_GROSS_ANNUAL_INCOME:'Personal Gross Annual Income',
    BUSINESS_EMAIL_ADDRESS:'Business Email Address',
    NAICS_CODE:'NAICS Code',
    COMPANY_MANAGEMENT_HISTORY:'Company/Management History',
    NAICS_CODE_DESCRIPTION:'NAICS Code Description',
    ADDRESS_MISMATCH_MESSAGE:'There are mismatched addresses tied to this entity. Please select the most accurate address',
    TYPE_OF_CUSTOMER : 'Type of Customer',
    PRIVATE_EQUITY_GROUP : "Private Equity Group",
    REG_O: "Reg-O",
    NAME_SUFFIX:"Suffix",
    REGION: "Region"
};

export const GUARANTOR_CONSTANT = {
    GUARANTOR_INFORMATION : 'Guarantor Information',
    SEPERATE_MAINTAINANCE: 'Monthly Separate Maintenance (i.e. alimony, child support)',
    ADDRESS_CHANGE_INFORMATION: 'If the customer updated is the same as the Collateral Owner, then the corresponding Collateral Owner address fields will also update'
};

export const BORROWER_CONSTANT=
{
    BORROWER_BUSINESS_INFORMATION:'Borrower Business Information',
    IS_CUSTOMER_US_CITIZEN:'Is Customer US Citizen?',
    IS_CUSTOMER_A_MORTGAGE_LENDER:'Is Customer a Mortgage Lender?',
};

export const PRODUCTREQUEST_CONSTANT=
{
    PRODUCT_REQUEST_INFORMATION:'Product Request Information',
    TYPE_OF_LOAN_REQUEST:'Type of Request',
    PRODUCT_TYPE:'Product type',
    PRE_FUNDING:'Pre-funding?',
    DAILY_SETTLEMENT_LIMIT_AMOUNT:'(DSL) Daily Settlement Limit Amount',
    FOREIGN_EXCHANGE_RIST_LIMIT_AMOUNT:'(FERL) Foreign Exchange Risk Limit Amount',
    AMOUNT_REQUESTED:'Amount Requested',
    TOTAL_CREDIT_EXPOSURE_LIMIT:'Total Credit Exposure Limit',
    TOTAL_DEBIT_EXPOSURE_LIMIT:'Total Debit Exposure Limit',
    USE_OF_FUNDS_PURPOSE:'Use of Funds (Purpose)',
    REFINANCING_EXISTING_DEBT:'Refinancing Existing Debt?',
    IS_DEBT_BEING_REFINANCED_FIFTH_THIRD_DEBT:'Is The Debt Being Refinanced Fifth Third Debt?',
    AMOUNT_FIFTH_THIRD_HARDEXPOSURE_BEING_REFINANCED :'Amount of Fifth Third Total Hard Exposure Being Refinanced',
    AMOUNT_FIFTH_THIRD_SOFTEXPOSURE_BEING_REFINANCED:'Amount of Fifth Third Total Soft Exposure by Type Being Refinanced',
    AMOUNT_NON_FIFTH_THIRD_HARDEXPOSURE_BEING_REFINANCED:'Amount of non-Fifth Third Total Hard Exposure Being Refinanced',
    AMOUNT_NON_FIFTH_THIRD_SOFTEXPOSURE_BEING_REFINANCED:'Amount of non-Fifth Third Total Soft Exposure by Type Being Refinanced',
    SBA:'SBA?',
    FINANCIAL_INSTITUTION:'Financial Institution',
    IS_PURPOSE_FARM_RELATED:'Is Purpose Farm-Related?',
    IS_ANY_REG_O_INSIDERS_ASSOCIATED_WITH_THIS_REQUEST:'Are any Reg-O (insiders) associated with this request?',
    PROMO_CODE:'Promo Code',
    TEXTAREA:'textarea',
    BILL_PAYER_SELECTION:'Bill Payer Selection',
    DDA_SAV:'DDA #/SAV',
    ROUTING_NUMBER:'Routing Number',
    ACCOUNT_NUMBER:'Account Number',
    PRODUCT_COLLATERAL_MAPPING_REMOVAL: 'Collateral Mapping Removal',
    ACH_RISK_ROUTING_NUMBER:'ACH Risk ID Routing number',
    ACH_RISK_ID_TAX_ID_NUMBER:'ACH Risk ID Tax ID number'
};

export const SUBMIT_CONSTANT=
{
    APP_CANCEL_MESSAGE:'Are you sure you want to cancel?',
    APP_CANCEL_CONFIRMATION_MESSGAE:'This application was cancelled.'
};

export const FOOTER_CONSTANT=
{
    FOOTER_TEXT: 'Fifth Third Bank, Member FDIC, All Rights Reserved  |  For Authorized Internal Use Only'
};

export const URL_CONSTANT=
{
    WORKBENCH_URL : urlWorkbench,
    NAICS_CODE_URL : urlNaicsCode,
    USERGUIDE_URL: urlUserGuide
};

export const CONFIRMATION_PAGE_CONSTANT={
    APP_SUBMITTED:'Application Submitted',
    APPLICATION_ID:'App #/Credit ID: ',
    BORROWER_NAME:'Borrower Name: ',
    PRODUCT_REQUESTS:'Product Requests: ',
    NEXT_STEP: 'Next Steps',
    CHECK_STATUS:'Check the status of this application in',
    CHECK_DECISION:'Check the Decision Summary',
    ACCOUNTDOCUMENT_DOWNLOAD: "Print List of Documentation Needed From Customer (Letter): ",
    SNAPSHOTANDDISCLOSURES_DOWNLOAD:"Print Application Disclosures:"
};
export const POSITION=
{
    BOTTOM:'bottom',
    TOP:'top',
    LEFT:'left',
    RIGHT:'right',
    HORIZONTAL:'horizontal',
    VERTICAL:'vertical'
};

export const LEGEND_CONSTANT={
    REQUIRED_FIELD:'*Required field.',
    EXPOSURE_MESSAGE:"Total Exposure: Include the amount of this request AND all existing 5/3 commercial debt.",
    NON_INDIVIDUAL_MESSAGE:"It is recommended the User input 100% of Borrower's ownership to expedite the loan application process.",
    NON_INDIVIDUAL_GUARANTORS_MESSAGE: "It is recommended the User input 100% of Guarantor's ownership to expedite the loan application process.",
    PRODUCT_COLLATERAL_MAPPING:"Updating the \"Product\" field will systematically remove the Collateral assigned to this Product. Do you want to proceed further?",
    CANCEL_WARNING : "If \"Yes\" is selected, the entire application will be cancelled and no data will be retained."
}

export const FORMAT_CONSTANT={
    US_PHONE_NUMBER_MASK: '(111) - 111 - 1111',
    AMOUNT_FORMAT_CONSTANT: /^\$?\d+(,\d{3})*\.?[0-9]?[0-9]?$/,
    NUMERIC_CONSTANT: /[0-9]+/g,
}

export const COLLATERAL_CONSTANT ={
    PROPOSED_COLLATERAL_INFORMATION: 'Proposed Collateral Information',
    COLLATERAL_INFORMATION : 'Collateral Information',
    PROPOSED_COLLATERAL: 'Proposed Collateral',
    EQUIPMENT_TYPE:'Equipment Type',
    VIN_MODEL_NUMBER:'VIN/Serial or Model Number',
    EQUIPEMENT_CONDITION:'Equipment Condition',
    EQUIPMENT_PURCHASE_PRICE:'Equipment Purchase Price',
    VEHICLE_CONDITION: 'Vehicle Condition',
    VEHICLE_PURCHASE_PRICE:'Vehicle Purchase Price',
    VEHICLE_MAKE:'Vehicle Make',
    VEHICLE_MODEL:'Vehicle Model',
    VEHICLE_VIN:'Vehicle VIN',
    VEHICLE_YEAR:'Vehicle Year',
    REAL_ESTATE:'Real Estate Purchase Price',
    REAL_ESTATE_FAMILY_RESIDENCE:'Is the Real Estate a principal residence or used as a 1-4 family residence?',
    LIQUID_ASSERTS:'Liquid Assets Type',
    BANK_INSTITUTION:'Bank or Institution',
    ACCOUNT_POLICY:'Account/Policy Number',
    COLLATERAL_OWNER_INFORMATION:'Collateral Owner Information',
    FIRST_NAME: 'First Name',
    MIDDLE_NAME: 'Middle Name',
    LAST_NAME: 'Last Name',
    BUSINESS_NAME: 'Business Name',
    COLLATERAL_ADDRESS:'Collateral Address',
    APPILICABLE_PRODUCT_SECURED:'Please select the applicable products secured by the collateral.  Check the applicable box(es) shown below:',
    COLLATERAL_SUBTYPE:'Collateral Subtype',
    WHO_IS_OWNER: 'Who is the owner of the collateral?',
    GUARANTORS:'Guarantors',
    ALL_BLC_PRODUCTS: 'All BLC Products.'
}

export const VALIDATION_CONSTANT={
    DSL_FERL_MINVALUE : 5000,
    DSL_FERL_MAXVALUE : 1000000,
    DEBIT_CREDIT_MINVALUE : 0.00,
    DEBIT_CREDIT_MAXVALUE : 3000000,
    TOTAL_NUMBER_OF_EMPLOYEE : 999999,
    GROSS_REVENUE_AMOUNT : 1000000000,
    SEARCH_ERROR : "You must correct the following error(s) before proceeding: Please enter the customer information on which to search.",
    ENTER_AMOUNT_IN_RANGE: "Please enter amount in Range.",
    GROSSREVENUE_MESSAGE : "Amount can't be more than $1 billion.",
    EMAIL_MESSAGE : "Please enter a valid Business Email Address.",
    ADDITIONAL_INFO_EMAIL_MESSAGE:"Please enter a valid Fifth Third email address for the Additional Recipients of Internal Fifth Third Email Status Updates.",
    NUMBEROFEMPLOYEE_MESSAGE : "Total number of employees can't be more than 999999",
    PHONE_NUMBER_NOTVALID : "Please enter 10 digit Phone number.",
    NAICS_CODE_ERROR : "Please enter 6 digit numeric value.",
    ZIPCODE_ERROR : "Please enter 5 digit numeric value.",
    PROMO_CODE_ERROR : "Please enter 16 digit alphanumeric value.",
    SSN_TIN_EIN_ERROR : "TIN or SSN should be a 9 digit value.",
    GUARANTOR_SEARCH_ERROR : "Please enter the search criteria.",
    IS_US_CITIZEN_ERROR : "Is US Citizen field can't be Empty.",
    IS_FIFTH_THIRD_ERROR : "Is Fifth Third Employee field can't be Empty.",
    IS_MORTGAGE_ERROR : "Is Mortgage Lender field can't be Empty.",
    LOAN_TYPE_ERROR : "Loan Type is required.",
    PRODUCT_TYPE_ERROR : "Product Type is required.",
    DSL_FERL_MESSAGE : "Please enter Amount between 5,000 and 1,000,000",
    FORMAT_NOT_VALID: "Format is not valid.",
    IS_PURPOSE_FARM_RELATED: "Is Purpose Farm Related field can't be Empty.",
    LA_PT_REQUIRED : "Loan type, Product type or UseOfFund is Empty.",
    ENTIRYSTRUCTURE_REQUIRED : "Entity Structure can't be Empty.",
    SPECIALINSTRUCTION_ERROR: "Can't enter more than 250 characters.",
    RADIO_BUTTON_REQUIRED:"Please select required Radio Button.",
    ADRESS_FIELD_ERROR: "Please select any one of Address Type.",

    BORROWER_ERROR_MESSAGE: "Please complete all of the required fields in the Borrower Business Information sub-section denoted with \"*Required Field\".",
    PRODUCT_ERROR_MESSAGE:  "Please complete all of the required fields in the Product Request Information denoted with \"*Required Field\".",
    GUARANTOR_ERROR_MESSAGE: "Please complete all of the required fields in the Guarantor Information denoted with \"*Required Field\".",
    CARDHOLDER_ERROR_MESSAGE: "Please complete all of the required fields in the Cardholder Information sub-section  denoted with \"*Required Field\".",
    ADDITIONALINFO_ERROR_MESSAGE: "Please complete all of the required fields in the Additional Information denoted with \"*Required Field\".",
    CARDHOLDER_POBOX_ERROR_MESSAGE:"As per bank policy, Primary Address cannot have a PO Box address value. Please enter a physical address.",
    BORROWER_OWNER_ERROR_MESSAGE:"Please complete all of the required fields in the Borrower Owner Information Sub section denoted with \"*Required Field\".",
    GUARANTOR_OWNER_ERROR_MESSAGE:"Please complete all of the required fields in the Guarantor Owner Information Sub section denoted with \"*Required Field\".",
    COLLATERAL_OWNER_ERROR_MESSAGE:"Please complete all of the required fields in the Collateral Owner Information Sub section denoted with \"*Required Field\".",
    COLLATERAL_ERROR_MESSAGE:"Please complete all of the required fields in the Collateral Sub section denoted with \"*Required Field\".",

    //ADDRESS_POBOX_VALIDATION:"As per bank policy, Primary Address cannot have a PO Box address value. Please enter a physical address",

}

export const CARDHOLDER_CONSTANT={
    BASIC_BUSINESS_INFORMATION:'Basic Business Information',
    FIRST_NAME:"Cardholder First Name",
    LAST_NAME:"Cardholder Last Name",
    MIDDLE_NAME:"Cardholder Middle Name" ,
    NAMESUFFIX:"Cardholder Title",
    DOB:"Cardholder Date of Birth",
    LEGAL_NAME:"Business Name on Card",
    SSN_TIN_EIN:"Cardholder SSN/ITIN or EIN",
    LINE1:"Address Line 1",
    LINE2:"Address Line 2",
    CITY:"City" ,
    ZIPCODE:"ZipCode",
    STATE:"State",
    RENDER_TOOLTIP_MESSAGE:"Cardholder(s) may only be added for either a Business Rewards MasterCard or a Business MasterCard.",
    ADDRESS_INFORMATION:"Address Information",
}

export const MESSAGE_CONSTANT={
    PRODUCT_REQUEST_SAVE_SUCCESS: "Product was added successfully.",
    PRODUCT_REQUEST_ADD_LINK:"Please use the \"Add New\" links in the Application Navigator to add a Product/Guarantor/Collateral/Cardholder (as applicable) or navigate to the Additional Information Section.",
    PRODUCT_REQUEST_AMOUNT_EXCEPTION:"The credit request for this customer will result in the credit exposure greater than $100,000.  Please consider if this credit request should be referred to a Business Banking Relationship Manager or Business Specialist.",

    GUARANTOR_REQUEST_SAVE_SUCCESS: "Guarantor was added successfully.",
    GUARANTOR_REQUEST_ADD_LINK:"Please use the \"Add New\" links in the Application Navigator to add a Guarantor/Collateral/Cardholder (as applicable) or navigate to the Additional Information section.",
    BORROWER_REQUEST_SAVE_SUCCESS:"Borrower Information Saved Successfully.",
    OWNER_ADD_LINK:"Please use the Application Navigator to complete/review the Owners sub-section.",
    OWNER_NEXT_CLICK:"Please use the Application Navigator to navigate to the next section.",
    OWNER_REQUEST_SAVE_SUCCESS:"Owner Information saved successfully.",
    CARDHOLDER_REQUEST_SAVE_SUCCESS:"Cardholder was added successfully.",
    CARDHOLDER_REQUEST_ADD_LINK: "Please use the \"Add New\" links in the Application Navigator to add a Cardholder (as applicable) or navigate to the Additional Information section.",
    COLLATERAL_REQUEST_SAVE_SUCCESS:"Collateral was added successfully.",
    COLLATERAL_REQUEST_ADD_LINK:"Please use the \"Add New\" links in the Application Navigator to add a Collateral/Cardholder (as applicable) or navigate to the Additional Information section.",

    OWNER_REMOVE_SUCCESS: "Owner was successfully removed.",
    PRODUCT_REMOVE_SUCCESS:"Product was successfully removed.",
    GUARANTOR_REMOVE_SUCCESS:"Guarantor was successfully removed.",
    COLLATERAL_REMOVE_SUCCESS:"Collateral was successfully removed.",
    CARDHOLDER_REMOVE_SUCCESS:"Cardholder was successfully removed.",
    POSTBOX_ERROR_MESSAGE : "As per bank policy, Primary Address cannot have a PO Box address value. Please enter a physical address.",
    GUARANTOR_REMOVE_ERROR: "Guarantor you are trying to delete has ownership tie(s). Please remove the tie(s) before removing the Guarantor from the loan application.",
    PRODUCT_REMOVE_ERROR:"Product you are trying to delete has Guarantor(s). Please remove the tie(s) before removing the Product from the loan application.",
    DISCLOSURE_MESSAGE:"User must click on the \'Disclosures\' link to print and provide disclosures to the customer prior to selecting the \'Submit\' button.",

    MULTIPLE_LOC_ERROR_MESSAGE: "Multiple LOC products not allowed.",
    MULTIPLE_BCC_ERROR_MESSAGE: "Multiple BCC products not allowed.",
    DELETE_CONFIRM: "Do you want to proceed with removal?",

    COLLATERAL_OWNER_ERRROR_MESSAGE: "Please select owner of the collateral.",
    COLLATERAL_PRODUCT_ERRROR_MESSAGE: "Please select one or more product(s).",
    NAVIGATION_CONFIRMATION : "Are you sure you want to navigate away from this page? The changes you made will be lost if you navigate away from this page. Press \"Yes\" to continue, or \"No\" to stay on the current page."

}

export const ADDITIONAL_INFORMATION =
    {
        ADDITIONAL_INFORMATION_HEADER:"Additional Information",
        RECIPIENT_EMAIL_COMMUNICATION :'Recipients of Email Communication',
        ADDITIONAL_RECIPENT_EMAIL_COMMUNICATION:'Additional Recipients of Email Communication',
        PRIMARY_CONTACT:'Primary Contact ',
        PRIMARY_CONTACT_FIRST_NAME : 'First Name',
        PRIMARY_CONTACT_LAST_NAME: 'Last Name',
        PRIMARY_CONTACT_PHONE_NUMBER:'Phone Number',
        PRIMARY_CONTACT_EMAIL_ADDRESS : 'Email Address',
        ENTITY_GENERATES_CASH_FLOW:'Which Entity Generates Cash Flow?',
        LOAN_APP_SPECIAL_INSTRUCTION:'Other Information ',
        SPECIAL_INSTRUCTION:'Special Instructions',
        CREDIT_PULL_AUTHORIZATION:'I have completed documentation for authorization to pull credit reports.',
        APPLICATION_INFORMATION_CONFIRMATION:'The information in this application is correct to the best of my knowledge.',
        WHICH_ENTITIES : 'Which Entity generates cash flow?',
        ADDITIONAL_INFO_SAVE_SUCCESS:"Additional Information was added successfully.",
        ADDITIONAL_PRIMARY_CONTACT: "Additional Business Contact",
        ADDITIONAL_PRIMARY_CONTACT_SUB:"Additional contact to receive customer status emails. Status emails will always go to the Borrower.",
        ADDITIONAL_RECIPIENT_EMAIL_COOMUNICATION: "Internal Email Status Updates",
        ADDITIONAL_RECIPIENT_EMAIL_COOMUNICATION_SUB: "Additional internal status emails go to the following in addition to banker that submitted the deal.",
        
    };

export const CONFIG_KEYS =
    {
        TMFCS_SETUPUSER_GROUP_EMAIL: tmfcsSetupUserGroupEmail
    };

export const ERROR_DETAILS={
    BLANKET_GUARANTOR_ERROR: `The Borrower selected has existing blanket guarantees tied to its CCAS Customer number.'\n' Please contact the Product Support team at <span> <i className="fa fa-phone-square" aria-hidden="true"></i><b>1-866-531-3427</b> </span> to remove the blanket guaranty from the CCAS Customer number prior to starting the loan application.`
};

export const VARIABLE_CONSTANT = {
    BORROWER_OWNER:"BO",
    GUARNATOR_OWNER: "GO",
    GUARNATOR: "G",
    OWNER_SEARCH: "Owner Search",
    GUARANTOR_SEARCH: "Guarantor Search",
    CUSTOMER_SEARCH: "Customer Search",
    BASE_URL: "/LoanApp/LoanApplication/"
};

export const PRODUCT_INTEGRATIONCODE = {
    REAL_ESTATE_CONSTRUCTION:"CONDEVTERM",
    COMMERCIAL_REAL_ESTATE:"TERM",
    ACH:"TM-ACH",
    LINE_OF_CREDIT: "BLOC",
    ARLOC: "ARLOC",
    BUSINESS_REWARDS_MASTERCARD: "MASTERCARD-TRAV",
    BUSINESS_MASTERCARD: "MASTERCARD",
    COMMERCIAL_CARD: "TM-MULTI",
    FOREIGN_EXCHANGE:"DSL",
    LETTER_OF_CREDIT: "INT-LOC-STAND",
    DRAW_NOTE:"DN",
    DRAW_NOTE_GUIDANCE_LINE: "UGL",
    TERM_LOAN:"TN",
    FOREIGNEXCHANGE_FER: "INT-DSL-FCE"
};

export const DISCLOSURE_LINKS ={
    LOC_PRODUCT:'https://sharepoint.info53.com/divisions/50174/Shared%20Documents/Retail%20ILP/Small%20Business%20Lending%20Disclosures/BLOC%20Disclosures%20Print%20Prior%20to%20Submit.docx',
    MASTERCARD_NON_INCREASE: 'https://sharepoint.info53.com/divisions/50174/Shared%20Documents/Retail%20ILP/Small%20Business%20Lending%20Disclosures/Business%20Card%20Disclosures%20Print%20Prior%20to%20Submit.doc',
    REWARD_MASTER_CARD_NON_INCREASE: 'https://sharepoint.info53.com/divisions/50174/Shared%20Documents/Retail%20ILP/Small%20Business%20Lending%20Disclosures/Business%20Rewards%20Card%20Disclosures%20Print%20Prior%20to%20Submit.doc',
    MASTERCARD_INCREASE: 'https://sharepoint.info53.com/divisions/50174/Shared%20Documents/Retail%20ILP/Small%20Business%20Lending%20Disclosures/Business%20Card%20Disclosures%20Print%20Prior%20to%20Submit.doc',
    REWARD_MASTER_CARD_INCREASE: 'https://sharepoint.info53.com/divisions/50174/Shared%20Documents/Retail%20ILP/Small%20Business%20Lending%20Disclosures/Business%20Rewards%20Card%20Disclosures%20Print%20Prior%20to%20Submit.doc'
};


export const API_EXCEPTION_MESSAGE = {
    BAD_REQUEST: "Bad Request: The request could not be understood by the server due to malformed syntax.",
    UN_AUTHORIZED: "Unauthorized access: The request requires user authentication.",
    FORBIDDEN: "Forbidden: The server understood the request, but is refusing to fulfill it.",
    NOT_FOUND: "URL/Resource Not Found: The server has not found anything matching the Request-URI. ",
    METHOD_NOT_ALLOWED: "Method Not Allowed: The method specified in the Request-Line is not allowed for the resource identified by the Request-URI.",
    PROXY_AUTH: "Proxy Authentication Required.",
    REQ_TIMED_OUT: "Request Timeout.",
    CONFLICT: "Conflict: The request could not be completed due to a conflict with the current state of the resource.",
    LENGTH_REQUIRED: "Length Required: The server refuses to accept the request without a defined Content- Length.",
    REQ_ENTITYL_TOO_LARGE: "Request Entity Too Large: The server is refusing to process a request because the request entity is larger than the server is willing or able to process.",
    REQ_URI_TOO_LONG: "Request-URI Too Long: The server is refusing to service the request because the Request-URI is longer than the server is willing to interpret.",
    TOO_MANY_REQ: "Too Many Requests: The user has sent too many requests in a given amount of time.",
    REQ_HEADER_TOO_LARGE: "Request Header Fields Too Large.",
    NOT_IMPLEMENTED: "Not Implemented: The server does not support the functionality required to fulfill the request.",
    BAD_GATEWAY: "Bad Gateway: The server, while acting as a gateway or proxy, received an invalid response from the upstream server it accessed in attempting to fulfill the request.",
    SERVICE_UN_AVAILABLE: "Service Unavailable: The server is currently unable to handle the request due to a temporary overloading or maintenance of the server.",
    GATEWAY_TIMED_OUT: "Gateway TimedOut: The server, while acting as a gateway or proxy, did not receive a timely response from the upstream server specified by the URI (e.g. HTTP, FTP, LDAP) or some other auxiliary server (e.g. DNS) it needed to access in attempting to complete the request.",
    NETWORK_READ_TIMED_OUT: "Network read timeout error.",
    NETWORK_CONN_TIMED_OUT: "Network connect timeout error.",
    NETWORK_AUTH_REQUIRED: "Network Authentication Required."
};