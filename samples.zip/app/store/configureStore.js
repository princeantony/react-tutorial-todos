/*eslint-disable no-undef */
if (IsDevMode=="true") {
    module.exports = require('./configureStore.dev')
} else {
    module.exports = require('./configureStore.prod')
}