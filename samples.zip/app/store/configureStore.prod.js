/* React libraries */
import 'babel-polyfill';
import React from 'react';
import {createStore, applyMiddleware} from 'redux';
import thunk from 'redux-thunk';
import promise from 'redux-promise';

/* Root reducer */
import rootReducer from '../reducers';

export default function configureStore(initialState) {
    const store = createStore(
    rootReducer,
    applyMiddleware(thunk, promise)
    );
    return store
}


