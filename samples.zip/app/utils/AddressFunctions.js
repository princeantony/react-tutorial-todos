import _ from "lodash";

 //compare CCAS & BFNA Address, if no difference return true.
    export function IsAddressesSame (_left, _right){
        return (_.isEqual(_left, _right));
    }
     export function GetLightAddress(_address, _addressType){
        if(_address != null && _address !=  undefined){
            const _typeAddress = _.find(_address,function(o){return o.AddressTypeId === _addressType; });
            if(_typeAddress != null && _typeAddress !=  undefined){
                return{
                    Line1: _typeAddress.Line1,
                    Line2: _typeAddress.Line2,
                    City: _typeAddress.City,
                    ZipCode: _typeAddress.ZipCode,
                    State: _typeAddress.State,
                    Country: _typeAddress.Country,
                    CountryId: _typeAddress.CountryId,
                    IsInternational: _typeAddress.IsInternational    
                };
            }
            
        }
        return null;
     }
        
        export function GetAddressFacility(_address, _addressType){
        if(_address != null && _address !=  undefined){
            const _typeAddress = _.find(_address,function(o){return o.AddressTypeId === _addressType; });
            if(_typeAddress != null && _typeAddress !=  undefined){
                 if(_typeAddress.Facility != undefined)
                return{Facility:  _typeAddress.Facility };
            }
        }
        return null;
        }
export function AddAddress(_entityAddresses, _newAddress,  _addressType)
        {
    // if the address is already saved in the object, we should update it, else create a new address for the type given
            let addressPos =  _.findIndex(_entityAddresses, ['AddressTypeId', _addressType]);
            if((_addressType == "S" || _addressType == "T") && (_newAddress != null && _newAddress != undefined))
            {
                if(addressPos == -1 )
                    addressPos = _.size(_entityAddresses);
                _entityAddresses[addressPos] = _.assign(_entityAddresses[addressPos], {
                    Line1: _newAddress.Line1,
                    Line2: _newAddress.Line2,
                    City:_newAddress.City,
                    ZipCode: _newAddress.ZipCode,
                    State: _newAddress.State,
                    County: _newAddress.County,
                    CountryId: _newAddress.CountryId,
                    AddressTypeId: _addressType,
                    IsInternational: _newAddress.IsInternational    
                });
            }
        }
     
export function AddAddressWithFacility(_entityAddresses, _newAddress, _facility, _addressType)
    {
    // if the address is already saved in the object, we should update it, else create a new address for the type given
        let addressPos =  _.findIndex(_entityAddresses, ['AddressTypeId', _addressType]);
        if((_addressType == "S" || _addressType == "T") && (_newAddress != null && _newAddress != undefined))
        {
        if(addressPos == -1 )
            addressPos = _.size(_entityAddresses);
            _entityAddresses[addressPos] = _.assign(_entityAddresses[addressPos], {
           Line1: _newAddress.Line1,
            Line2: _newAddress.Line2,
            City:_newAddress.City,
            ZipCode: _newAddress.ZipCode,
            State: _newAddress.State,
            Province: "",
            County: _newAddress.County,
            CountryId: _newAddress.CountryId,
            AddressTypeId: _addressType,
            IsInternational: _newAddress.IsInternational    
        });
        }
        if(_facility != null && _facility !=  undefined)
            {
                let _tempFacility= {};
                {_facility.map((data, index) => {
                    _.set(_tempFacility, data.name, data.value);
                })}
                if(addressPos != -1)
                _entityAddresses[addressPos] = _.assign(_entityAddresses[addressPos], {Facility:_tempFacility})
            }
        return _entityAddresses; 
    }
   

