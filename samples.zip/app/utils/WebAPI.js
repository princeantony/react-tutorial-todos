﻿import {URL_CONSTANT} from '../constants/ApplicationConstants'

let WebApi =
{
    submitLoanApplition: function(data){
        let confirmationDetails=null;
        $.ajax(
          {
              async:false,
              type: 'POST',
              url: URL_CONSTANT.SUBMIT_URL,
              data: { 'data': JSON.stringify(data) },
              success: function(result) {

                  confirmationDetails=result;
              },
              error:function(e){
                  confirmationDetails=null;
              }
          });
        return  confirmationDetails;
    }
};

module.exports = WebApi;
