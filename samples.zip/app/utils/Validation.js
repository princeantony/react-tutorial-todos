﻿import  { VALIDATION_CONSTANT} from '../constants/ApplicationConstants';
import { isValidAmount, isValidEmail, isValidLengthOrFormat, isRequired, isMinMaxValid, isEmptyOrUndefined, checkPhoneLength, isValidPOBoxAddress } from './Functions';

/************************/
//isPhoneNumberValid(homePhone, mobilePhone, workPhone)
//Usage : isPhoneNumberValid ("HomePhone", "MobilePhone", "WorkPhone");

//isValidAmount(Value, ComponentName, IsRequired, FormatErrorMessage, ShowToastrOrNot);
//Usage : isValidAmount(value, "", true, VALIDATION_CONSTANT.FORMAT_NOT_VALID, false);

//isMinMaxValid(Value, ComponentName, MinimumValue, MaximumValue, ErrorMessageForMinMaxValue, ShowToastrOrNot);
//Usage : isMinMaxValid(value,"", false, VALIDATION_CONSTANT.GROSS_REVENUE_AMOUNT, VALIDATION_CONSTANT.GROSSREVENUE_MESSAGE, false);

//isRequired(Value, ComponentName, FormatOfValue(EX : number, alphaNumeric)); 
//Usage : isRequired(getElementById(naicsCodeAttribute), "NAICS Code", "number"); 

//isValidLengthOrFormat(Value, ComponentName, LengthOfValue, FormatOfValue, ErrorMessage, ShowToastrOrNot); 
//Usage : isValidLengthOrFormat(getElementById(naicsCodeAttribute), "", 6, "number", VALIDATION_CONSTANT.NAICS_CODE_ERROR, false); 

//isValidEmail(Value, ComponentName, ErrorMessage, ShowToastrOrNot);
//Usage : isValidEmail(getElementById(email), "", VALIDATION_CONSTANT.EMAIL_MESSAGE, false); 
/************************/

let getElementById = (id) =>{
    if(id != null && id != undefined)
        return document.getElementById(id).value;
}

/*Phone number validation on Next Button*/
let isPhoneNumberValid = (initialData, homePhone, mobilePhone, otherPhone) =>{
    let _isValidHome = isEmptyOrUndefined(getElementById(homePhone));
    let _isValidMobile = isEmptyOrUndefined(getElementById(mobilePhone));
    let _isValidwork = isEmptyOrUndefined(getElementById(otherPhone));

    let _homePhoneLength = checkPhoneLength(getElementById(homePhone));
    let _mobilePhoneLength = checkPhoneLength(getElementById(mobilePhone));
    let _workPhoneLength = checkPhoneLength(getElementById(otherPhone));
       
    if((!_isValidHome && !_homePhoneLength && !initialData.HomePhone) || (!_isValidMobile && !_mobilePhoneLength && !initialData.MobilePhone) || (!_isValidwork && !_workPhoneLength && !initialData.OtherPhone))
        return VALIDATION_CONSTANT.PHONE_NUMBER_NOTVALID;
    else
        return null;
}

let checkType = (value) =>{
    return document.getElementById(value).getAttribute("type") != "label";
}

/*Guarantor Search Validation*/
let isSearchCriteriaValid=(ssnTinEin, customerName)=>{
    let _errors ={};
    let _ssnTinError = isValidLengthOrFormat(getElementById(ssnTinEin), "", 9, "number", VALIDATION_CONSTANT.FORMAT_NOT_VALID, false);
    if(_ssnTinError)
        _errors._ssnTinEin = _ssnTinError;
     
    let _isCustomerNameEmpty = isEmptyOrUndefined(getElementById(customerName));
    let _IsSsnTinEmpty = isEmptyOrUndefined(getElementById(ssnTinEin));

    if(_isCustomerNameEmpty && _IsSsnTinEmpty)
        _errors.requiredOneField = VALIDATION_CONSTANT.GUARANTOR_SEARCH_ERROR;

    return  _errors;
}


let validateFields = (props, isOnBlur) =>
{
    let param = props.name;
    if(props.id!=null && props.id!=undefined && (props.type=="textarea" || props.type=="currency" || props.type == "text" || props.type=="select-single"))
        param = props.id;
    let value = (props.type=="date" && isOnBlur) ? props.date : document.getElementById(param).value;
    let errors = {};
    if(props.type=="email"){
        let emailErrorMessage = isValidEmail(value, props.displayText, props.errorMessage, isOnBlur, props.emailFormat);
        if(emailErrorMessage)
            errors[param] = emailErrorMessage;
    }
    /*Validate Numeric Format and Digit Length, Parameters(value, componentName, Length, message,showToastr)*/
    if(props.isNumberFormat || props.isAlphaNumericFormat){
        let format = (props.isNumberFormat ? "number" : (props.isAlphaNumericFormat ? "alphaNumeric":(false)));
        let lengthErrorMessage = isValidLengthOrFormat(value, props.displayText, props.digitLength, format, props.errorMessage, isOnBlur);
        if(lengthErrorMessage)
            errors[param] = lengthErrorMessage;
    }
    /*validate value with min and max values, Parameters - (Value, ComponentName, MinValue, MaxValue, Message, ShowToastr)*/
    if(props.minValue || props.maxValue){
        let LengthErrorMessage = isMinMaxValid(value, props.displayText, props.minValue, props.maxValue, props.errorMessage, isOnBlur);
        if(LengthErrorMessage)
            errors[param] = LengthErrorMessage;
    }
    /*(Properties required to define in each dollar section - isRequired, dollarFormat, minValue, maxValue, errorMessage, ShowToastr)*/
    if(props.dollarFormat){
        let dollarValue = isValidAmount(value, props.displayText, props.isRequired, props.errorMessage, isOnBlur, props.isZeroNotAllowed);
        if(dollarValue)
            errors[param] = dollarValue;
    }
    if(props.isRequired && !props.dollarFormat){ 
        let requiredError = isRequired(value, props.displayText, props.type); 
        if(requiredError)
            errors[param] = requiredError;
    }
    if(props.isPhoneNumber)
    { 
        let _isValidPhone = isEmptyOrUndefined(value);
        let _PhoneLength = checkPhoneLength(value);
        if(!_isValidPhone && !_PhoneLength)
            errors[param] = VALIDATION_CONSTANT.PHONE_NUMBER_NOTVALID;
    }
    return errors;
}
 
export{
    isPhoneNumberValid, isSearchCriteriaValid, validateFields
};