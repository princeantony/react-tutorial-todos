﻿/*eslint-disable no-undef */
import React from "react";

import toastr from "toastr";
import moment from "moment";
import _ from "lodash";



import  {FORMAT_CONSTANT, VALIDATION_CONSTANT, APP_CONSTANT, PRODUCT_INTEGRATIONCODE, API_EXCEPTION_MESSAGE} from "../constants/ApplicationConstants";

import {isEmail, isLength} from "validator";

/*Toastr properties*/
toastr.options = APP_CONSTANT.TOASTR_OPTIONS;

/*Validate numeric values on keyPress*/
let validateNumber = (e) => {
    const regexp = FORMAT_CONSTANT.NUMERIC_CONSTANT;
    if (!regexp.test(e.key)) {
        e.preventDefault();
        showWarning(VALIDATION_CONSTANT.FORMAT_NOT_VALID);
    }
}


/*Validate dollarFormate, Parameters(Value, fieldName, IsRequired, ErrorMessage, ShowToastr) */
let isValidAmount = (fieldValue,fieldName, isRequired, errorMessage, isToastr, isZeroNotAllowed)=>{
    let amountFormat = FORMAT_CONSTANT.AMOUNT_FORMAT_CONSTANT;
    let value  = isEmptyOrUndefined(fieldValue) ? "" : fieldValue.trim();
    value = value.replace(/,/g,"");
    if((value == "") && isRequired)
    {
        if(isNaN(parseInt(value)))
            return "Is Required";
    }
    if(value != "" && !amountFormat.test(value))
    {
        if(isToastr)
            showError("is not valid",fieldName);
        return errorMessage;
    }
    if(value==0 && isZeroNotAllowed){
        if(isToastr)
            showError("should be greater than Zero",fieldName);
        return errorMessage;
    }
}

/*Validate value, Parameters - (FieldValue, fieldName, MinValue, MaxValue, errorMessage, ShowToastr)*/
let isMinMaxValid = (fieldValue, fieldName, minValue, maxValue, errorMessage, isToastr)=>{
    let value  = isEmptyOrUndefined(fieldValue) ? "" : fieldValue.trim();
    value = value.replace(/,/g,"");
    //let min = minValue ? minValue : 0;
    //let max = maxValue ? maxValue : undefined;
    //let range = {min:min,max:max};
    if(value != undefined && value != null && value != "")
    {
        if(!minValue && maxValue && value > maxValue)
        {
            if(isToastr)
                showError(errorMessage, fieldName);
            return errorMessage;
        }
        if(minValue && !maxValue && value < maxValue)
        {
            if(isToastr)
                showError(errorMessage, fieldName);
            return errorMessage;
        }
        if(minValue &&  maxValue  && (value < minValue || value > maxValue))
        {
            if(isToastr)
                showError("Please enter Amount between $"+minValue+" and $"+maxValue, fieldName);
            return errorMessage;
        }
    }
}

/*Validate Email Format, Parameters(value, fieldName, errorMessage, isToastr)*/
let isValidEmail=(fieldValue, fieldName, errorMessage, isToastr, emailFormat) =>{
    if(isEmptyOrUndefined(fieldValue)){
        return;
    }
    if(emailFormat)
    {
        let regExStr =/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@53.com$/;
        if((!regExStr.test(fieldValue.trim().toLowerCase())) && fieldValue!='')
        {
            if(isToastr)
                showError(errorMessage, fieldName);
            return errorMessage;
        }
    }
    else if(!isEmail(fieldValue.trim())){
        if(isToastr)
            showError(errorMessage, fieldName);
        return errorMessage;
    }
}

/*Validate Numeric Format and Digit Length, Parameters(value, fieldName, maxLength, errorMessage,showToastr)*/
let isValidLengthOrFormat=(value, fieldName, digitLength, format, errorMessage, isToastr)=>{
    if(isEmptyOrUndefined(value)){
        return;
    }
    else if(digitLength && (value.trim().length !== digitLength)){
        if(isToastr)
            showError(errorMessage, fieldName);
        return errorMessage;
    }
    else if((!findRegularExpression(format).test(value.trim())) && (value != '')){
        if(isToastr)
            showError(VALIDATION_CONSTANT.FORMAT_NOT_VALID, fieldName);
        return VALIDATION_CONSTANT.FORMAT_NOT_VALID;
    }
    else if(fieldName == "NAICS Code" && value == "000000"){
     if(isToastr)
         showError("can't be 000000", fieldName);
    return errorMessage;
    }
}


/*Get Regular expression according to given format*/
let findRegularExpression = (format) => {
    switch (format)
    {
        case 'number':
            {
                return /^[0-9]+$/;
            }
        case 'alphaNumeric':
            {
                return /^[0-9a-zA-Z]+$/;
            }
    }
}

/*Validate required fields, Parameters(Value, fieldName, Type) */
let isRequired = (fieldValue, fieldName, type) => {
    if(type == "number" || type == "text"|| type=="textarea" || type=="date" || type=="currency" || type=="phone"){
        let value  = isEmptyOrUndefined(fieldValue) ? "" : fieldValue.trim();
        if(value == "")
            return fieldName+" is Required";
        else
            return;
    }
    else if(type == "select-single"){
        if(fieldValue==-1 || fieldValue=="-1" || fieldValue=="" || isEmptyOrUndefined(fieldValue))
            return fieldName+"is Required";
    }
}


/*Phone number validation*/
let checkPhoneLength = (phoneNumber) => {
    let replacedPhoneNumber = phoneNumber.replace(/\D/g,'');
    let range = {min:10,max:10};
    if(isLength(replacedPhoneNumber,range)){
        return true;
    }
    else{
        return false;
    }
}

let isEmptyOrUndefined = (value) => {
    if(value == undefined || value == null || value == "") {
        return true;
    }
    else{
        return false;
    }
}


/*Address PO Box validation*/
let isValidPOBoxAddress=(value, componentName, errorMessage, isToastr) =>{
    let addressPOBox1 = /^ *((#\d+)|((box|bin)[-. \/\\]?\d+)|(.*p[ \.]? ?(o|0)[-. \/\\]? *-?((box|bin)|b|(#|num)?\d+))|(p(ost)? *(o(ff(ice)?)?)? *((box|bin)|b)? *\d+)|(p *-?\/?(o)? *-?box)|post office box|((box|bin)|b) *(number|num|#)? *\d+|(num|number|#) *\d+)/i;
    let addressPOBox2 = /^[B|b][O|o|0][X|x]\b/;
    if(addressPOBox1.test(value) || addressPOBox2.test(value)){
        if(isToastr)
            showError(errorMessage, componentName);
        return errorMessage;
    }
}

let parseBool=(value)=>{
    return ((value=="true")?(true):(false));
}

let getFormattedDate=(date)=>{
    let validatedDate = moment(date);
    return validatedDate.isValid() ? validatedDate.format("MM/DD/YYYY") : "";
}

let getFormattedData = (e) =>
{
    let fielValue=e.target.value;
    if((fielValue=="true" || fielValue=="false") && (e.target.type =="radio" || e.target.type =="checkbox"))
        fielValue = parseBool(fielValue);
    else if(!isNaN(fielValue.replace(/,/g,"")))
    {
        fielValue = fielValue.replace(/,/g,"");
        fielValue= Number(fielValue);
    }
    return fielValue;
}

let isLegalEntityIndividual = (entityStructureCode) => {
    return (entityStructureCode!=null && entityStructureCode!== "I") ? false : true;
}

let getDisplayName = (list, displayNameValue) =>{
    let displayName= _.findIndex(list, ['RelatedEntity.Id', parseInt(displayNameValue)]);

    if(displayNameValue=="add")
    {
        return(list.length);
    }
    else if(displayName==-1)
    {
        return (parseInt(displayNameValue)+1);
    }
    else
    {
        return displayName+1;
    }
}

let showSuccess = (message) => {
    toastr.success(message);
}

let showWarning = (message) => {
    toastr.warning(message, "", {timeOut: 0});
}

let showError = (message, fieldName) => {
    let _fieldName = fieldName == ""?"":fieldName;
    toastr.error(message, _fieldName, {timeOut: 0});
}

let getURLPath = (url) => {
    return _.split(url, '/');
}

let getAffiliate = (affiliateList, _affiliateCode) => {
    return (_affiliateCode == -1 ?({'Code':-1,'Id':-1}):_.find(affiliateList, ['Code', _.toString(_affiliateCode)]));
}

let getDisclosures = (productList) => {
    return _.uniqBy(_.filter(productList, function(o) { return o.ProductId!=0 && (o.IntegrationCode=="BLOC" ||  ((o.IntegrationCode=="MASTERCARD" || o.IntegrationCode=="MASTERCARD-TRAV") && o.LoanType!=3)); }), 'IntegrationCode');
}

let getDisclosureAfterSubmit = (productList) => {
    return _.uniqBy(_.filter(productList, function(o) { return o.ProductId!=0} ), 'IntegrationCode');
}

let getDisclosureUrl = (integrationCode) =>{
    switch(integrationCode)
    {
        case PRODUCT_INTEGRATIONCODE.LINE_OF_CREDIT: return 'https://sharepoint.info53.com/divisions/50174/Shared%20Documents/Retail%20ILP/Small%20Business%20Lending%20Disclosures/BLOC%20Disclosures%20Print%20After%20Submit.docx';
        case PRODUCT_INTEGRATIONCODE.TERM_LOAN: return 'https://sharepoint.info53.com/divisions/50174/Shared%20Documents/Retail%20ILP/Small%20Business%20Lending%20Disclosures/All%20Other%20Disclosures%20Print%20After%20Submit.docx';
        case PRODUCT_INTEGRATIONCODE.LETTER_OF_CREDIT: return 'https://sharepoint.info53.com/divisions/50174/Shared%20Documents/Retail%20ILP/Small%20Business%20Lending%20Disclosures/All%20Other%20Disclosures%20Print%20After%20Submit.docx';
        case PRODUCT_INTEGRATIONCODE.ACH: return 'https://sharepoint.info53.com/divisions/50174/Shared%20Documents/Retail%20ILP/Small%20Business%20Lending%20Disclosures/All%20Other%20Disclosures%20Print%20After%20Submit.docx';
        case PRODUCT_INTEGRATIONCODE.COMMERCIAL_CARD: return 'https://sharepoint.info53.com/divisions/50174/Shared%20Documents/Retail%20ILP/Small%20Business%20Lending%20Disclosures/All%20Other%20Disclosures%20Print%20After%20Submit.docx';
        case PRODUCT_INTEGRATIONCODE.ARLOC:return 'https://sharepoint.info53.com/divisions/50174/Shared%20Documents/Retail%20ILP/Small%20Business%20Lending%20Disclosures/All%20Other%20Disclosures%20Print%20After%20Submit.docx';
        case PRODUCT_INTEGRATIONCODE.FOREIGNEXCHANGE_FER:return 'https://sharepoint.info53.com/divisions/50174/Shared%20Documents/Retail%20ILP/Small%20Business%20Lending%20Disclosures/All%20Other%20Disclosures%20Print%20After%20Submit.docx';
        case PRODUCT_INTEGRATIONCODE.FOREIGN_EXCHANGE:return 'https://sharepoint.info53.com/divisions/50174/Shared%20Documents/Retail%20ILP/Small%20Business%20Lending%20Disclosures/All%20Other%20Disclosures%20Print%20After%20Submit.docx';
        default: return 'https://sharepoint.info53.com/divisions/50174/Shared%20Documents/Retail%20ILP/Small%20Business%20Lending%20Disclosures/All%20Other%20Disclosures%20Print%20After%20Submit.docx';
    }
}

let getPath = (url)=>{
    let _path=_.split(url, '/');
    switch(_path[3])
    {
        case 'Borrower' : return 1;
        case 'BorrowerOwner': return 2;
        case 'productRequest':return 3;
        case 'BorrowerOwnerSearchCriteria': return 4;
        case 'GuarantorSearchCriteriaPage': return 5;
        case 'Guarantor': return 6;
        case 'GuarantorOwnerSearchCriteria': return 7;
        case 'GuarantorOwner': return 8;
        case 'Collateral': return 9;
        case 'CardHolder': return 10;
        case 'AdditionalInformation': return 11;
        default: return 0;
    }
}

let getProductMinValue = (integrationcode) => {
    if(integrationcode==PRODUCT_INTEGRATIONCODE.REAL_ESTATE_CONSTRUCTION || integrationcode==PRODUCT_INTEGRATIONCODE.COMMERCIAL_REAL_ESTATE)
        return 50000;
    else if(integrationcode==PRODUCT_INTEGRATIONCODE.LINE_OF_CREDIT)
        return 10000;
    else if(integrationcode==PRODUCT_INTEGRATIONCODE.BUSINESS_REWARDS_MASTERCARD || integrationcode==PRODUCT_INTEGRATIONCODE.BUSINESS_MASTERCARD)
        return 500;
    else if(integrationcode==PRODUCT_INTEGRATIONCODE.COMMERCIAL_CARD)
        return 40000;
    else if(integrationcode=="ARLOC" || integrationcode==PRODUCT_INTEGRATIONCODE.DRAW_NOTE || integrationcode==PRODUCT_INTEGRATIONCODE.TERM_LOAN || integrationcode==PRODUCT_INTEGRATIONCODE.LETTER_OF_CREDIT)
        return 15000;
    else if(integrationcode==PRODUCT_INTEGRATIONCODE.DRAW_NOTE_GUIDANCE_LINE)
        return 100000;
    else if(integrationcode==PRODUCT_INTEGRATIONCODE.FOREIGN_EXCHANGE || integrationcode=="INT-DSL-FCE")
        return 5000;
    else
        return 0;
}

let getProductMaxValue = (integrationcode) => {
    if(integrationcode == PRODUCT_INTEGRATIONCODE.REAL_ESTATE_CONSTRUCTION || integrationcode == PRODUCT_INTEGRATIONCODE.COMMERCIAL_REAL_ESTATE || integrationcode == PRODUCT_INTEGRATIONCODE.LINE_OF_CREDIT ||integrationcode == PRODUCT_INTEGRATIONCODE.LETTER_OF_CREDIT || integrationcode == PRODUCT_INTEGRATIONCODE.COMMERCIAL_CARD || integrationcode == PRODUCT_INTEGRATIONCODE.DRAW_NOTE || integrationcode == PRODUCT_INTEGRATIONCODE.DRAW_NOTE_GUIDANCE_LINE || integrationcode == PRODUCT_INTEGRATIONCODE.TERM_LOAN || integrationcode==PRODUCT_INTEGRATIONCODE.FOREIGN_EXCHANGE || integrationcode=="INT-DSL-FCE")
        return 1000000;
    else if(integrationcode == "ARLOC")
        return 100000;
    else if(integrationcode == PRODUCT_INTEGRATIONCODE.BUSINESS_REWARDS_MASTERCARD || integrationcode == PRODUCT_INTEGRATIONCODE.BUSINESS_MASTERCARD)
        return 80000;
    else
        return 0;
}

let isEmptyOrNullOrUndefined = (value) => {
    return (_.isUndefined(value) || _.isNull(value) || _.isEmpty(value) || value== " ")?true:false;
}


let reArrangeDisplayNameProperty = (list, name) =>{
    let _sortedList = list;
    _sortedList.map((item, index) => {
        item.DisplayName = name + (index+1);
    });

    return _sortedList;
}

let isUndefinedOrNull = (value) =>{
    return (_.isUndefined(value) || _.isNull(value));
}

let formatData = (fielValue) =>{
    if(fielValue=="true" || fielValue=="false")
        fielValue = parseBool(fielValue);
    /*else if(!isNaN(fielValue.replace(/,/g,"")))
    {
        fielValue = fielValue.replace(/,/g,"");
        fielValue= Number(fielValue);
    }*/
    return fielValue;
}

let getExcetionMessage = (error, details) =>{
    showError("Status Code(" + error.response.status + ") - "  + details);
}

let showDevException = (error) => {
    getExcetionMessage(error, error.response.data.Details);
}

let showProdException = (error) => {
    switch (_.parseInt(error.response.status))
    {
        case 400 :  getExcetionMessage(error, API_EXCEPTION_MESSAGE.BAD_REQUEST); break;
        case 401 : getExcetionMessage(error, API_EXCEPTION_MESSAGE.UN_AUTHORIZED); break;
        case 403 : getExcetionMessage(error, API_EXCEPTION_MESSAGE.FORBIDDEN); break;
        case 404 : getExcetionMessage(error, API_EXCEPTION_MESSAGE.NOT_FOUND); break;
        case 405 : getExcetionMessage(error, API_EXCEPTION_MESSAGE.METHOD_NOT_ALLOWED); break;
        case 407 : getExcetionMessage(error, API_EXCEPTION_MESSAGE.PROXY_AUTH); break;
        case 408 : getExcetionMessage(error, API_EXCEPTION_MESSAGE.REQ_TIMED_OUT); break;
        case 409 : getExcetionMessage(error, API_EXCEPTION_MESSAGE.CONFLICT); break;
        case 411 : getExcetionMessage(error, API_EXCEPTION_MESSAGE.LENGTH_REQUIRED); break;
        case 413 : getExcetionMessage(error, API_EXCEPTION_MESSAGE.REQ_ENTITYL_TOO_LARGE); break;
        case 414 : getExcetionMessage(error, API_EXCEPTION_MESSAGE.REQ_URI_TOO_LONG); break;
        case 429 : getExcetionMessage(error, API_EXCEPTION_MESSAGE.TOO_MANY_REQ); break;
        case 431 : getExcetionMessage(error, API_EXCEPTION_MESSAGE.REQ_HEADER_TOO_LARGE); break;
        case 500 : getExcetionMessage(error, error.response.data.Message); break;
        case 501 : getExcetionMessage(error, API_EXCEPTION_MESSAGE.NOT_IMPLEMENTED); break;
        case 502 : getExcetionMessage(error, API_EXCEPTION_MESSAGE.BAD_GATEWAY); break;
        case 503 : getExcetionMessage(error, API_EXCEPTION_MESSAGE.SERVICE_UN_AVAILABLE); break;
        case 504 : getExcetionMessage(error, API_EXCEPTION_MESSAGE.GATEWAY_TIMED_OUT); break;
        case 598 : getExcetionMessage(error, API_EXCEPTION_MESSAGE.NETWORK_READ_TIMED_OUT); break;
        case 599 : getExcetionMessage(error, API_EXCEPTION_MESSAGE.NETWORK_CONN_TIMED_OUT); break;
        case 511 : getExcetionMessage(error, API_EXCEPTION_MESSAGE.NETWORK_AUTH_REQUIRED); break;
        default : showError("Status Code(" + error.response.status + ") - " +  error.response.statusText + ": " + error.response.data.Message); break;
    }
}

let showExceptionMessage = (error) => {
    if (parseBool(IsDevMode)) {
        showDevException(error);
    } else {
        showProdException(error);
    }
}


export{
    validateNumber, isValidEmail, isValidLengthOrFormat, isValidAmount , isEmptyOrUndefined, checkPhoneLength, isRequired, isValidPOBoxAddress, isMinMaxValid, parseBool, getFormattedDate, getFormattedData, isLegalEntityIndividual, getDisplayName, showSuccess, showWarning, showError, getURLPath, getAffiliate, getDisclosures, getPath, getProductMinValue, getProductMaxValue, isEmptyOrNullOrUndefined, reArrangeDisplayNameProperty, getDisclosureAfterSubmit, getDisclosureUrl, isUndefinedOrNull, formatData, showExceptionMessage
    };

